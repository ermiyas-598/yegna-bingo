import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import { createServer as createHttpServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GameRoom, Player, BingoCard, BingoCell } from './src/types.js';

// Safe __dirname & __filename resolver for both ES Module dev and CommonJS production bundle
const getFilename = () => {
  if (typeof __filename !== 'undefined') return __filename;
  return fileURLToPath((import.meta as any).url);
};
const getDirname = () => {
  if (typeof __dirname !== 'undefined') return __dirname;
  return path.dirname(getFilename());
};

const resolvedFilename = getFilename();
const resolvedDirname = getDirname();

const app = express();
const httpServer = createHttpServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  }
});

let detectedAppUrl = '';

// Middleware to dynamically detect host URL for Telegram bot
app.use((req, res, next) => {
  if (req.headers.host) {
    const host = req.headers.host.toLowerCase();
    const isLocal = host.includes('localhost') || 
                    host.includes('127.0.0.1') || 
                    host.includes('::1') || 
                    host.startsWith('10.') || 
                    host.startsWith('172.') || 
                    host.startsWith('192.168.');
    if (!isLocal) {
      const protocol = req.secure || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
      detectedAppUrl = `${protocol}://${req.headers.host}`;
    } else if (!detectedAppUrl) {
      const protocol = req.secure || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
      detectedAppUrl = `${protocol}://${req.headers.host}`;
    }
  }
  next();
});

const PORT = 3000;

// Simple in-memory storage for user balances to persist across joins/leaves
const coinsDB: { [username: string]: number } = {};

// Simple in-memory storage for registered contacts mapping chatId to contact info
const registeredContacts: { [chatId: number]: { phone: string; name: string; username: string } } = {};
// Simple in-memory storage for pending referrers
const pendingReferrals: { [chatId: number]: number } = {};

// Active game loops per room (timeouts/intervals)
const roomLoops: { [roomId: string]: NodeJS.Timeout | null } = {};
const lobbyTimers: { [roomId: string]: NodeJS.Timeout | null } = {};

// Initialize standard game rooms with requested Birr rates
const initialRooms: { [id: string]: { name: string; cardPrice: number } } = {
  'room10': { name: '🥉 Bronze Hall (10 Birr)', cardPrice: 10 },
  'room30': { name: '🥈 Silver Palace (30 Birr)', cardPrice: 30 },
  'room50': { name: '🥇 Gold Diamond (50 Birr)', cardPrice: 50 },
  'room100': { name: '🏆 Platinum VIP (100 Birr)', cardPrice: 100 },
};

const rooms: { [id: string]: GameRoom } = {};

for (const [id, config] of Object.entries(initialRooms)) {
  rooms[id] = {
    id,
    name: config.name,
    status: 'lobby',
    players: {},
    drawnNumbers: [],
    currentNumber: null,
    countdown: 45, // 45 seconds countdown as requested!
    winners: [],
    nextBallCountdown: 0,
    cardPrice: config.cardPrice,
  };
  roomLoops[id] = null;
}

// Generate valid deterministic 75-Ball Bingo Card based on ticket number (1-90)
function generateDeterministicBingoCard(seedNum: number): BingoCard {
  let rngVal = seedNum * 777; // Simple scaling to vary starting seeds
  const nextRng = () => {
    rngVal = (rngVal * 9301 + 49297) % 233280;
    return rngVal / 233280;
  };

  const getUniqueRandoms = (min: number, max: number, count: number) => {
    const nums = new Set<number>();
    while (nums.size < count) {
      const r = nextRng();
      const val = Math.floor(r * (max - min + 1)) + min;
      nums.add(val);
    }
    return Array.from(nums).sort((a, b) => a - b);
  };

  const bCols = getUniqueRandoms(1, 15, 5);
  const iCols = getUniqueRandoms(16, 30, 5);
  const nCols = getUniqueRandoms(31, 45, 4); // 4 numbers, 1 FREE space in center
  const gCols = getUniqueRandoms(46, 60, 5);
  const oCols = getUniqueRandoms(61, 75, 5);

  const grid: BingoCell[][] = [];
  for (let r = 0; r < 5; r++) {
    const row: BingoCell[] = [];
    row.push({ value: bCols[r], daubed: false });
    row.push({ value: iCols[r], daubed: false });
    if (r === 2) {
      row.push({ value: 'FREE', daubed: true });
    } else {
      const nVal = r < 2 ? nCols[r] : nCols[r - 1];
      row.push({ value: nVal, daubed: false });
    }
    row.push({ value: gCols[r], daubed: false });
    row.push({ value: oCols[r], daubed: false });

    grid.push(row);
  }

  return {
    id: `CARD-${seedNum}`,
    grid,
  };
}

// Generate valid 75-Ball Bingo Card
function generateBingoCard(): BingoCard {
  const getUniqueRandoms = (min: number, max: number, count: number) => {
    const nums = new Set<number>();
    while (nums.size < count) {
      nums.add(Math.floor(Math.random() * (max - min + 1)) + min);
    }
    return Array.from(nums).sort((a, b) => a - b);
  };

  const bCols = getUniqueRandoms(1, 15, 5);
  const iCols = getUniqueRandoms(16, 30, 5);
  const nCols = getUniqueRandoms(31, 45, 4); // 4 numbers, 1 FREE space in center
  const gCols = getUniqueRandoms(46, 60, 5);
  const oCols = getUniqueRandoms(61, 75, 5);

  const grid: BingoCell[][] = [];
  for (let r = 0; r < 5; r++) {
    const row: BingoCell[] = [];
    // Column 0 (B)
    row.push({ value: bCols[r], daubed: false });
    // Column 1 (I)
    row.push({ value: iCols[r], daubed: false });
    // Column 2 (N)
    if (r === 2) {
      row.push({ value: 'FREE', daubed: true });
    } else {
      const nVal = r < 2 ? nCols[r] : nCols[r - 1];
      row.push({ value: nVal, daubed: false });
    }
    // Column 3 (G)
    row.push({ value: gCols[r], daubed: false });
    // Column 4 (O)
    row.push({ value: oCols[r], daubed: false });

    grid.push(row);
  }

  return {
    id: Math.random().toString(36).substring(2, 9).toUpperCase(),
    grid,
  };
}

// Verify patterns on a card against drawn numbers
function verifyWinningPatterns(card: BingoCard, drawnNumbers: number[]): { won: boolean; patterns: string[] } {
  const isMarked = (r: number, c: number) => {
    const cell = card.grid[r][c];
    if (cell.value === 'FREE') return true;
    // For verification, the number must be daubed AND must be in the drawn numbers list
    return cell.daubed && drawnNumbers.includes(cell.value);
  };

  const wonPatterns: string[] = [];

  // 1. Check rows
  for (let r = 0; r < 5; r++) {
    let rowComplete = true;
    for (let c = 0; c < 5; c++) {
      if (!isMarked(r, c)) {
        rowComplete = false;
        break;
      }
    }
    if (rowComplete) wonPatterns.push(`Row ${r + 1} Line`);
  }

  // 2. Check columns
  for (let c = 0; c < 5; c++) {
    let colComplete = true;
    for (let r = 0; r < 5; r++) {
      if (!isMarked(r, c)) {
        colComplete = false;
        break;
      }
    }
    if (colComplete) {
      const colLetter = ['B', 'I', 'N', 'G', 'O'][c];
      wonPatterns.push(`Column ${colLetter} Line`);
    }
  }

  // 3. Check major diagonal (top-left to bottom-right)
  let majorDiag = true;
  for (let i = 0; i < 5; i++) {
    if (!isMarked(i, i)) {
      majorDiag = false;
      break;
    }
  }
  if (majorDiag) wonPatterns.push('Diagonal Line (\\)');

  // 4. Check minor diagonal (top-right to bottom-left)
  let minorDiag = true;
  for (let i = 0; i < 5; i++) {
    if (!isMarked(i, 4 - i)) {
      minorDiag = false;
      break;
    }
  }
  if (minorDiag) wonPatterns.push('Diagonal Line (/)');

  // 5. Check Four Corners
  if (isMarked(0, 0) && isMarked(0, 4) && isMarked(4, 0) && isMarked(4, 4)) {
    wonPatterns.push('Four Corners');
  }

  // 6. Check Full House (Blackout)
  let fullHouse = true;
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 5; c++) {
      if (!isMarked(r, c)) {
        fullHouse = false;
        break;
      }
    }
  }
  if (fullHouse) wonPatterns.push('Full House (Blackout)');

  return {
    won: wonPatterns.length > 0,
    patterns: wonPatterns,
  };
}

// Start Game Loop (Draw Balls)
function startGameLoop(roomId: string) {
  const room = rooms[roomId];
  if (!room || room.status !== 'playing') return;

  room.drawnNumbers = [];
  room.currentNumber = null;
  room.winners = [];

  // Generate ball pool (1-75)
  const ballPool = Array.from({ length: 75 }, (_, i) => i + 1);

  // Shuffle ball pool
  for (let i = ballPool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [ballPool[i], ballPool[j]] = [ballPool[j], ballPool[i]];
  }

  const ballIntervalMs = 4000; // Pacing: 4 seconds
  let nextBallIndex = 0;

  const drawBall = () => {
    if (room.status !== 'playing') {
      if (roomLoops[roomId]) {
        clearInterval(roomLoops[roomId]!);
        roomLoops[roomId] = null;
      }
      return;
    }

    if (nextBallIndex >= 75) {
      // All balls drawn, end game with no winner (draw)
      room.status = 'ended';
      io.to(roomId).emit('game:ended', { winners: [], room });
      resetRoomToLobby(roomId);
      return;
    }

    const ball = ballPool[nextBallIndex++];
    room.currentNumber = ball;
    room.drawnNumbers.push(ball);

    // Automatically daub/select matching numbers on all players' cards in the room
    for (const player of Object.values(room.players)) {
      if (player.cards && player.cards.length > 0) {
        player.cards.forEach(card => {
          card.grid.forEach(row => {
            row.forEach(cell => {
              if (cell.value === ball) {
                cell.daubed = true;
              }
            });
          });
        });
        // Send player state update so their local client stays fully in sync
        io.to(player.id).emit('player:updated', player);
      }
    }

    // Check for automatic winners in the room simultaneously
    const automaticWinners: Array<{ player: Player; patterns: string[] }> = [];
    for (const player of Object.values(room.players)) {
      if (player.cards && player.cards.length > 0) {
        let won = false;
        const matchingPatterns: string[] = [];
        player.cards.forEach(card => {
          const check = verifyWinningPatterns(card, room.drawnNumbers);
          if (check.won) {
            won = true;
            matchingPatterns.push(...check.patterns);
          }
        });
        if (won) {
          automaticWinners.push({
            player,
            patterns: Array.from(new Set(matchingPatterns))
          });
        }
      }
    }

    if (automaticWinners.length > 0) {
      // One or more simultaneous winners!
      room.status = 'ended';

      const totalCardsInRoom = Object.values(room.players).reduce((acc, p) => acc + (p.cardsPurchased || 0), 0);
      const commissionFee = Math.round(room.cardPrice * 0.10);
      const prizePerCard = room.cardPrice - commissionFee;
      const totalPrizePool = totalCardsInRoom * prizePerCard;

      // Divide the prize pool equally among all simultaneous winners
      const count = automaticWinners.length;
      const splitPrize = Math.floor(totalPrizePool / count);

      room.winners = [];

      automaticWinners.forEach(({ player, patterns }) => {
        // Award the split prize to player's coins
        player.coins += splitPrize;
        coinsDB[player.username] = player.coins;

        const winningLog = {
          playerId: player.id,
          username: player.firstName,
          pattern: patterns.join(' & '),
          timestamp: Date.now(),
          prize: splitPrize
        };
        room.winners.push(winningLog);

        // Update player coins for client
        io.to(player.id).emit('player:updated', player);
      });

      // Notify entire room
      io.to(roomId).emit('game:ended', {
        winners: room.winners,
        room,
      });

      // Construct winner announcement chat message
      let announcement = '';
      if (count === 1) {
        announcement = `${automaticWinners[0].player.firstName} hit BINGO with [${automaticWinners[0].patterns.join(', ')}] and won ${splitPrize} Birr/coins!`;
      } else {
        const names = automaticWinners.map(w => w.player.firstName).join(', ');
        announcement = `🏆 Simultaneous Bingo Split! 🏆\n${names} both hit BINGO on number ${ball} and split the ${totalPrizePool} Birr prize pool equally, winning ${splitPrize} Birr/coins each!`;
      }

      io.to(roomId).emit('chat:message', {
        sender: '👑 Winner 👑',
        text: announcement,
        timestamp: Date.now(),
      });

      // Reset the room back to lobby after 10s
      resetRoomToLobby(roomId);
      return;
    }

    io.to(roomId).emit('game:ball', { number: ball, drawnNumbers: room.drawnNumbers });
    io.to(roomId).emit('room:state', room);
  };

  // Draw the first ball immediately
  drawBall();

  // Draw subsequent balls on interval
  roomLoops[roomId] = setInterval(drawBall, ballIntervalMs);
}

function resetRoomToLobby(roomId: string) {
  if (roomLoops[roomId]) {
    clearInterval(roomLoops[roomId]!);
    roomLoops[roomId] = null;
  }

  setTimeout(() => {
    const room = rooms[roomId];
    if (room) {
      room.status = 'lobby';
      room.drawnNumbers = [];
      room.currentNumber = null;
      room.winners = [];
      room.countdown = 45; // 45 seconds countdown as requested!

      // Reset players status but keep their balances/cardsPurchased
      for (const player of Object.values(room.players)) {
        player.isReady = false;
        player.cards = [];
        player.cardsPurchased = 0;
        player.freezeUntil = undefined;
      }
      io.to(roomId).emit('room:state', room);

      // Start the lobby countdown again since there are players!
      if (Object.keys(room.players).length > 0) {
        startLobbyCountdown(roomId);
      }
    }
  }, 10000); // Wait 10 seconds on ended screen before resetting
}

// Start Lobby Countdown Phase where users select cards in real-time
function startLobbyCountdown(roomId: string) {
  const room = rooms[roomId];
  if (!room || room.status !== 'lobby') return;
  if (lobbyTimers[roomId]) return; // Already running

  room.countdown = 45; // 45 seconds countdown!
  io.to(roomId).emit('room:state', room);

  lobbyTimers[roomId] = setInterval(() => {
    const r = rooms[roomId];
    if (!r || r.status !== 'lobby') {
      if (lobbyTimers[roomId]) {
        clearInterval(lobbyTimers[roomId]!);
        lobbyTimers[roomId] = null;
      }
      return;
    }

    const playerIds = Object.keys(r.players);
    if (playerIds.length === 0) {
      clearInterval(lobbyTimers[roomId]!);
      lobbyTimers[roomId] = null;
      r.countdown = 45;
      return;
    }

    r.countdown--;
    io.to(roomId).emit('room:state', r);

    if (r.countdown <= 0) {
      clearInterval(lobbyTimers[roomId]!);
      lobbyTimers[roomId] = null;

      // Lock in cards, deduct coins and start playing phase!
      r.status = 'playing';
      r.drawnNumbers = [];
      r.currentNumber = null;
      r.winners = [];

      for (const p of Object.values(r.players)) {
        if (!p.isReady || p.cards.length === 0) {
          // Player did not select/purchase cards, remove them from the game
          delete r.players[p.id];
          io.to(p.id).emit('room:kicked_no_cards');
        } else {
          io.to(p.id).emit('player:updated', p);
        }
      }

      const activePlayerIds = Object.keys(r.players);
      if (activePlayerIds.length === 0) {
        r.status = 'lobby';
        r.countdown = 45;
        io.to(roomId).emit('room:state', r);
        return;
      }

      io.to(roomId).emit('room:state', r);
      startGameLoop(roomId);
    }
  }, 1000);
}

// Start Countdown Phase
function startRoomCountdown(roomId: string) {
  const room = rooms[roomId];
  if (!room || room.status !== 'lobby') return;

  room.status = 'countdown';
  room.countdown = 45; // 45 seconds countdown as requested!

  io.to(roomId).emit('room:state', room);

  const countdownInterval = setInterval(() => {
    const r = rooms[roomId];
    if (!r || r.status !== 'countdown') {
      clearInterval(countdownInterval);
      return;
    }

    r.countdown--;
    io.to(roomId).emit('room:state', r);

    if (r.countdown <= 0) {
      clearInterval(countdownInterval);
      // Start the game!
      r.status = 'playing';
      // Ensure all players have cards. If they haven't purchased any, automatically buy 1 card
      for (const p of Object.values(r.players)) {
        if (p.cards.length === 0) {
          p.cardsPurchased = 1;
          p.cards = [generateBingoCard()];
          // Deduct from coins: ticket price
          const baseCost = r.cardPrice;
          p.coins = Math.max(0, p.coins - baseCost);
          coinsDB[p.username] = p.coins;
          io.to(p.id).emit('player:updated', p);
        }
      }
      io.to(roomId).emit('room:state', r);
      startGameLoop(roomId);
    }
  }, 1000);
}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', activeRooms: Object.keys(rooms).length });
});

// Serve balance retrieval helper
app.get('/api/balance/:username', (req, res) => {
  const { username } = req.params;
  const coins = coinsDB[username] !== undefined ? coinsDB[username] : 1000;
  res.json({ username, coins });
});

// Serve dynamic, real-time leaderboard sorted by current balances
app.get('/api/leaderboard', (req, res) => {
  const leaderboardList = Object.entries(coinsDB).map(([username, coins]) => ({
    username,
    coins
  })).sort((a, b) => b.coins - a.coins);
  res.json({ leaderboard: leaderboardList });
});

// Serve registered Telegram contact retrieval helper
app.get('/api/telegram/user/:chatIdOrUsername', (req, res) => {
  const { chatIdOrUsername } = req.params;
  
  // Search by username
  let reg = Object.values(registeredContacts).find(
    c => c.username && c.username.toLowerCase() === chatIdOrUsername.toLowerCase()
  );
  
  if (!reg) {
    const chatIdNum = parseInt(chatIdOrUsername, 10);
    if (!isNaN(chatIdNum)) {
      reg = registeredContacts[chatIdNum];
    }
  }
  
  if (reg) {
    res.json({ registered: true, contact: reg });
  } else {
    res.json({ registered: false });
  }
});

// Socket logic
io.on('connection', (socket) => {
  let currentPlayer: Player | null = null;
  let currentRoomId: string | null = null;

  socket.on('lobby:join', ({ username, firstName, avatarUrl, coins }) => {
    // Set or retrieve player balance
    const sanitizedUsername = username || `Player_${socket.id.substring(0, 5)}`;
    if (coinsDB[sanitizedUsername] === undefined) {
      coinsDB[sanitizedUsername] = coins || 1000; // Gift standard 1000 coins on first join, or custom welcome bonus coins
    }

    currentPlayer = {
      id: socket.id,
      username: sanitizedUsername,
      firstName: firstName || 'Anonymous',
      avatarUrl: avatarUrl,
      coins: coinsDB[sanitizedUsername],
      cards: [],
      isReady: false,
      cardsPurchased: 0,
    };

    currentRoomId = null;

    // Send updated player state
    socket.emit('player:updated', currentPlayer);

    // Send all room states so the client room list receives the current room metadata and player counts
    Object.keys(rooms).forEach((roomId) => {
      socket.emit('room:state', rooms[roomId]);
    });
  });

  // Switch rooms / Join room manually
  socket.on('room:join', (targetRoomId: string) => {
    if (!rooms[targetRoomId]) {
      socket.emit('game:error', 'Selected room does not exist.');
      return;
    }

    // Leave current room if already in one
    if (currentRoomId && currentPlayer) {
      const prevRoom = rooms[currentRoomId];
      if (prevRoom) {
        delete prevRoom.players[socket.id];
        socket.leave(currentRoomId);
        io.to(currentRoomId).emit('room:state', prevRoom);

        // Notify previous room
        io.to(currentRoomId).emit('chat:message', {
          sender: 'System 🤖',
          text: `${currentPlayer.firstName} has left the room.`,
          timestamp: Date.now(),
        });

        // Clean up empty room in playing/countdown state
        if (Object.keys(prevRoom.players).length === 0) {
          if (roomLoops[currentRoomId]) {
            clearInterval(roomLoops[currentRoomId]!);
            roomLoops[currentRoomId] = null;
          }
          prevRoom.status = 'lobby';
          prevRoom.drawnNumbers = [];
          prevRoom.currentNumber = null;
          prevRoom.winners = [];
        }
      }
    }

    if (currentPlayer) {
      // Join new room
      currentRoomId = targetRoomId;
      socket.join(targetRoomId);

      const targetRoom = rooms[targetRoomId];
      // Reset ready & cards for the new room
      currentPlayer.isReady = false;
      currentPlayer.cards = [];
      currentPlayer.cardsPurchased = 0;
      currentPlayer.freezeUntil = undefined;
      // Fetch latest coins DB
      currentPlayer.coins = coinsDB[currentPlayer.username] || 1000;

      targetRoom.players[socket.id] = currentPlayer;

      socket.emit('player:updated', currentPlayer);
      io.to(targetRoomId).emit('room:state', targetRoom);

      if (targetRoom.status === 'lobby') {
        startLobbyCountdown(targetRoomId);
      }

      io.to(targetRoomId).emit('chat:message', {
        sender: 'System 🤖',
        text: `${currentPlayer.firstName} has entered ${targetRoom.name}!`,
        timestamp: Date.now(),
      });
    }
  });

  socket.on('room:select_cards', (cardNumbers: number[]) => {
    if (!currentRoomId || !currentPlayer) return;
    const room = rooms[currentRoomId];
    if (!room || room.status !== 'lobby') return;

    if (cardNumbers.length > 4) {
      socket.emit('game:error', 'You can select up to 4 cards max.');
      return;
    }

    // Server-side verification for duplicate cards in the lobby
    const alreadyTaken = new Set<number>();
    Object.values(room.players).forEach(p => {
      if (p.id === currentPlayer!.id) return;
      p.cards.forEach(c => {
        const match = c.id.match(/^CARD-(\d+)$/);
        if (match) {
          alreadyTaken.add(parseInt(match[1], 10));
        }
      });
    });

    const hasDuplicate = cardNumbers.some(n => alreadyTaken.has(n));
    if (hasDuplicate) {
      socket.emit('game:error', 'One or more of the selected card numbers are already taken by another player in this lobby. Please choose different cards.');
      return;
    }

    // Set player's selected cards in real-time
    currentPlayer.cards = cardNumbers.map(seed => generateDeterministicBingoCard(seed));
    currentPlayer.cardsPurchased = cardNumbers.length;

    socket.emit('player:updated', currentPlayer);
    io.to(currentRoomId).emit('room:state', room);
  });

  socket.on('room:buy_cards', (arg: number | number[]) => {
    if (!currentRoomId || !currentPlayer) return;
    const room = rooms[currentRoomId];
    if (!room || room.status !== 'lobby') {
      socket.emit('game:error', 'Can only buy cards during Lobby phase.');
      return;
    }

    const cardNumbers = Array.isArray(arg) ? arg : [];
    const count = Array.isArray(arg) ? arg.length : arg;

    if (count < 1 || count > 4) {
      socket.emit('game:error', 'You can buy between 1 and 4 cards.');
      return;
    }

    // Server-side verification for duplicate cards in the lobby
    if (cardNumbers.length > 0) {
      const alreadyTaken = new Set<number>();
      Object.values(room.players).forEach(p => {
        if (p.id === currentPlayer.id) return;
        p.cards.forEach(c => {
          const match = c.id.match(/^CARD-(\d+)$/);
          if (match) {
            alreadyTaken.add(parseInt(match[1], 10));
          }
        });
      });

      const hasDuplicate = cardNumbers.some(n => alreadyTaken.has(n));
      if (hasDuplicate) {
        socket.emit('game:error', 'One or more of the selected ticket numbers are already taken by another player in this lobby. Please choose different cards.');
        return;
      }
    }

    const cost = count * room.cardPrice;
    const commission = Math.round(cost * 0.10);
    if (currentPlayer.coins < cost) {
      socket.emit('game:error', `Insufficient coins to purchase these cards. Total cost is ${cost} Birr.`);
      return;
    }

    // Deduct cost and save
    currentPlayer.coins -= cost;
    coinsDB[currentPlayer.username] = currentPlayer.coins;
    currentPlayer.cardsPurchased = count;

    // Generate Bingo Cards
    if (cardNumbers.length > 0) {
      currentPlayer.cards = cardNumbers.map(seed => generateDeterministicBingoCard(seed));
    } else {
      currentPlayer.cards = Array.from({ length: count }, () => generateBingoCard());
    }

    // Automatically ready up when buying cards
    currentPlayer.isReady = true;

    socket.emit('player:updated', currentPlayer);
    io.to(currentRoomId).emit('room:state', room);

    socket.emit('notification', {
      type: 'success',
      message: `Purchased ${count} Bingo Ticket(s) for ${cost} Birr (includes 10% commission cut of ${commission} Birr)!`,
    });
  });

  socket.on('room:ready', () => {
    if (!currentRoomId || !currentPlayer) return;
    const room = rooms[currentRoomId];
    if (!room || room.status !== 'lobby') return;

    if (currentPlayer.cardsPurchased === 0) {
      // Force purchase of 1 card
      const cost = room.cardPrice;
      if (currentPlayer.coins < cost) {
        socket.emit('game:error', `Insufficient coins to play. Total cost is ${cost} Birr. Spin the lucky wheel or request daily free coins!`);
        return;
      }
      currentPlayer.coins -= cost;
      coinsDB[currentPlayer.username] = currentPlayer.coins;
      currentPlayer.cardsPurchased = 1;
      currentPlayer.cards = [generateDeterministicBingoCard(1)];
    }

    currentPlayer.isReady = true;
    socket.emit('player:updated', currentPlayer);
    io.to(currentRoomId).emit('room:state', room);
  });

  // Toggle daub state for a number on the ticket
  socket.on('game:daub', ({ cardId, rowIndex, colIndex }) => {
    if (!currentPlayer || !currentRoomId) return;
    const room = rooms[currentRoomId];
    if (!room || room.status !== 'playing') return;

    const card = currentPlayer.cards.find(c => c.id === cardId);
    if (!card) return;

    const cell = card.grid[rowIndex][colIndex];
    if (cell.value === 'FREE') return; // FREE is always marked

    // Prevent daubing/touching if the number has not been drawn/called yet
    if (!room.drawnNumbers.includes(cell.value as number)) {
      return;
    }

    // Toggle daub
    cell.daubed = !cell.daubed;

    socket.emit('player:updated', currentPlayer);
    // Broadcast room to sync everyone
    io.to(currentRoomId).emit('room:state', room);
  });

  // Claim Bingo!
  socket.on('game:claim_bingo', () => {
    if (!currentPlayer || !currentRoomId) return;
    const room = rooms[currentRoomId];
    if (!room || room.status !== 'playing') return;

    // Check penalty
    const now = Date.now();
    if (currentPlayer.freezeUntil && now < currentPlayer.freezeUntil) {
      const waitSec = Math.ceil((currentPlayer.freezeUntil - now) / 1000);
      socket.emit('game:penalty', { seconds: waitSec });
      socket.emit('notification', {
        type: 'error',
        message: `Card Frozen! Wait ${waitSec} seconds before claiming Bingo again.`,
      });
      return;
    }

    // Check all player cards for any winning patterns
    let validBingo = false;
    const matchingPatterns: string[] = [];

    for (const card of currentPlayer.cards) {
      const check = verifyWinningPatterns(card, room.drawnNumbers);
      if (check.won) {
        validBingo = true;
        matchingPatterns.push(...check.patterns);
      }
    }

    if (validBingo) {
      // Winning Claim!
      const finalPatterns = Array.from(new Set(matchingPatterns));
      const totalCardsInRoom = Object.values(room.players).reduce((acc, p) => acc + (p.cardsPurchased || 0), 0);
      const commissionFee = Math.round(room.cardPrice * 0.10);
      const prizePerCard = room.cardPrice - commissionFee;
      const prize = totalCardsInRoom * prizePerCard;

      // Award coins
      currentPlayer.coins += prize;
      coinsDB[currentPlayer.username] = currentPlayer.coins;

      const winningLog = {
        playerId: currentPlayer.id,
        username: currentPlayer.firstName,
        pattern: finalPatterns.join(' & '),
        timestamp: Date.now(),
        prize: prize
      };

      room.winners.push(winningLog);
      room.status = 'ended';

      // Update coins for client
      socket.emit('player:updated', currentPlayer);

      // Notify entire room
      io.to(currentRoomId).emit('game:ended', {
        winners: room.winners,
        room,
      });

      io.to(currentRoomId).emit('chat:message', {
        sender: '👑 Winner 👑',
        text: `${currentPlayer.firstName} hit BINGO with [${finalPatterns.join(', ')}] and won ${prize} coins!`,
        timestamp: Date.now(),
      });

      // Reset the room back to lobby after 10s
      resetRoomToLobby(currentRoomId);
    } else {
      // False Bingo Penalty! Freeze card for 10 seconds
      currentPlayer.freezeUntil = Date.now() + 10000;
      socket.emit('game:penalty', { seconds: 10 });
      socket.emit('notification', {
        type: 'error',
        message: 'FALSE BINGO! Your cards are frozen for 10 seconds.',
      });

      io.to(currentRoomId).emit('chat:message', {
        sender: 'System 🤖',
        text: `${currentPlayer.firstName} called false Bingo! Cards frozen. ❄️`,
        timestamp: Date.now(),
      });

      socket.emit('player:updated', currentPlayer);
      io.to(currentRoomId).emit('room:state', room);
    }
  });

  // Client sent daily wheel spin / free coins request
  socket.on('player:claim_free_coins', () => {
    if (!currentPlayer) return;
    const reward = 250;
    currentPlayer.coins += reward;
    coinsDB[currentPlayer.username] = currentPlayer.coins;

    socket.emit('player:updated', currentPlayer);
    socket.emit('notification', {
      type: 'success',
      message: `Spin Success! Received ${reward} FREE coins! 🪙`,
    });

    if (currentRoomId) {
      io.to(currentRoomId).emit('room:state', rooms[currentRoomId]);
    }
  });

  // Client sent solo coins update to sync balance
  socket.on('player:update_coins_solo', (newCoins: number) => {
    if (!currentPlayer) return;
    currentPlayer.coins = newCoins;
    coinsDB[currentPlayer.username] = newCoins;
    socket.emit('player:updated', currentPlayer);
  });

  // Client updated profile info (display name & avatar)
  socket.on('player:update_profile', ({ firstName, avatarUrl }) => {
    if (!currentPlayer) return;
    currentPlayer.firstName = firstName;
    currentPlayer.avatarUrl = avatarUrl;
    if (currentRoomId) {
      const r = rooms[currentRoomId];
      if (r && r.players[socket.id]) {
        r.players[socket.id].firstName = firstName;
        r.players[socket.id].avatarUrl = avatarUrl;
        io.to(currentRoomId).emit('room:state', r);
      }
    }
    socket.emit('player:updated', currentPlayer);
  });

  // Chat message sending
  socket.on('chat:send', (text: string) => {
    if (!currentPlayer || !currentRoomId) return;
    if (!text || text.trim() === '') return;

    io.to(currentRoomId).emit('chat:message', {
      sender: currentPlayer.firstName,
      text: text.substring(0, 100).trim(),
      timestamp: Date.now(),
    });
  });

  // Disconnect handling
  socket.on('disconnect', () => {
    if (currentRoomId && currentPlayer) {
      const room = rooms[currentRoomId];
      if (room) {
        delete room.players[socket.id];
        io.to(currentRoomId).emit('room:state', room);

        io.to(currentRoomId).emit('chat:message', {
          sender: 'System 🤖',
          text: `${currentPlayer.firstName} has disconnected.`,
          timestamp: Date.now(),
        });

        // Clean up empty room
        if (Object.keys(room.players).length === 0) {
          if (roomLoops[currentRoomId]) {
            clearInterval(roomLoops[currentRoomId]!);
            roomLoops[currentRoomId] = null;
          }
          room.status = 'lobby';
          room.drawnNumbers = [];
          room.currentNumber = null;
          room.winners = [];
        }
      }
    }
  });

  socket.on('lobby:leave', () => {
    if (currentRoomId && currentPlayer) {
      const room = rooms[currentRoomId];
      if (room) {
        delete room.players[socket.id];
        socket.leave(currentRoomId);
        io.to(currentRoomId).emit('room:state', room);

        io.to(currentRoomId).emit('chat:message', {
          sender: 'System 🤖',
          text: `${currentPlayer.firstName} has left the room.`,
          timestamp: Date.now(),
        });

        // Clean up empty room
        if (Object.keys(room.players).length === 0) {
          if (roomLoops[currentRoomId]) {
            clearInterval(roomLoops[currentRoomId]!);
            roomLoops[currentRoomId] = null;
          }
          room.status = 'lobby';
          room.drawnNumbers = [];
          room.currentNumber = null;
          room.winners = [];
        }
      }
      currentRoomId = null;
    }
  });
});

// Start the full-stack server async to prevent top-level await in CommonJS output
async function startServer() {
  // Vite middleware configuration for Development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Listen on exactly Port 3000 & Host 0.0.0.0
  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Bingo Multi-User Server listening on http://0.0.0.0:${PORT}`);
    // Start the Telegram Bot after the server successfully listens
    initTelegramBot();
  });
}

// --- TELEGRAM BOT INTEGRATION ---
async function sendTelegramMessage(chatId: number, text: string, replyMarkup: any, token: string) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        reply_markup: replyMarkup
      })
    });
    const resData: any = await response.json();
    if (!resData.ok) {
      console.error('[Telegram Bot] Send message failed:', resData);
    }
  } catch (err) {
    console.error('[Telegram Bot] Error sending message:', err);
  }
}

async function editTelegramMessage(chatId: number, messageId: number, text: string, replyMarkup: any, token: string) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/editMessageText`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId,
        text,
        parse_mode: 'HTML',
        reply_markup: replyMarkup
      })
    });
    const resData: any = await response.json();
    if (!resData.ok) {
      console.error('[Telegram Bot] Edit message failed:', resData);
    }
  } catch (err) {
    console.error('[Telegram Bot] Error editing message:', err);
  }
}

function getRegisterKeyboardMarkup() {
  return {
    keyboard: [
      [
        {
          text: '📱 ስልክ ቁጥርዎን ያጋሩ (Share Contact)',
          request_contact: true
        }
      ]
    ],
    resize_keyboard: true,
    one_time_keyboard: true
  };
}

function getPublicAppUrl() {
  let appUrl = process.env.APP_URL || detectedAppUrl || 'http://localhost:3000';
  if (appUrl.includes('ais-dev-')) {
    appUrl = appUrl.replace('ais-dev-', 'ais-pre-');
  }
  return appUrl;
}

function getMainMenuMarkup() {
  const appUrl = getPublicAppUrl();
  return {
    keyboard: [
      [
        {
          text: '🎮 ይጫወቱ',
          web_app: { url: appUrl }
        }
      ],
      [
        { text: '💰 ሂሳብ' },
        { text: '📥 ገቢ ለማድረግ' }
      ],
      [
        { text: '📤 ወጪ ለማድረግ' },
        { text: '🔗 ጋብዝ & አግኝ' }
      ],
      [
        { text: '💎 VIP ክፍል' },
        { text: '🌟 Special Promoter' }
      ],
      [
        { text: '🆘 እርዳታ' },
        { text: '📜 ደንቦች' }
      ],
      [
        { text: '🎁 የሽልማት ማዕከል' }
      ]
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  };
}

async function handleTelegramUpdate(update: any, token: string) {
  if (update.message) {
    const chatId = update.message.chat.id;
    const text = (update.message.text || '').trim();
    const username = update.message.from.username || '';
    const firstName = update.message.from.first_name || 'Player';

    // Handle Shared Contact Registration
    if (update.message.contact) {
      const contact = update.message.contact;
      const phone = contact.phone_number;
      const name = contact.first_name || firstName;
      const dbUsername = username ? username.toLowerCase() : `user_${chatId}`;
      
      registeredContacts[chatId] = {
        phone: phone,
        name: name,
        username: dbUsername
      };
      
      coinsDB[dbUsername] = 10; // Registration Welcome Bonus of 10 Birr/Coins!
      
      // Process pending referral reward if any!
      const refChatId = pendingReferrals[chatId];
      if (refChatId) {
        const refUsername = `user_${refChatId}`;
        if (coinsDB[refUsername] !== undefined) {
          coinsDB[refUsername] += 5;
        } else {
          coinsDB[refUsername] = 15; // 10 base + 5 bonus
        }
        console.log(`[Referral] User ${chatId} registered via referral. Awarding 5 Birr to referrer ${refChatId}.`);
        try {
          await sendTelegramMessage(refChatId, `🎉 <b>አዲስ ግብዣ!</b> ጓደኛዎ @${username || name} ስልኩን አጋርቶ ተመዝግቧል። <b>+5 Birr/ሳንቲም</b> ወደ ሂሳብዎ ገብቷል!`, getMainMenuMarkup(), token);
        } catch (e) {}
        delete pendingReferrals[chatId];
      }
      
      const successText = `🎉 <b>እንኳን ደስ አለዎት! ስልክ ቁጥርዎ በተሳካ ሁኔታ ተመዝግቧል!</b> 🇪🇹🏆\n\n` +
        `📱 <b>ስልክ ቁጥር፡</b> <code>${phone}</code>\n` +
        `👤 <b>የተጫዋች ስም፡</b> <code>${name}</code>\n` +
        `🎁 <b>የምዝገባ ጉርሻ፡</b> <b>10 Birr/ሳንቲም</b> በነፃ ወደ ሂሳብዎ ተጨምሯል!\n\n` +
        `👇 ጨዋታውን ለመጀመር አሁኑኑ ከታች ያለውን <b>🎮 ይጫወቱ</b> የሚለውን ትልቅ ቁልፍ ይጫኑ!`;
        
      await sendTelegramMessage(chatId, successText, getMainMenuMarkup(), token);
      return;
    }

    const isRegistered = registeredContacts[chatId] !== undefined;

    if (!isRegistered) {
      // Check for referral code first in start command before registration prompt
      if (text.startsWith('/start')) {
        const parts = text.split(' ');
        if (parts.length > 1 && parts[1].startsWith('ref_')) {
          const referrerId = parts[1].replace('ref_', '');
          const refChatId = parseInt(referrerId, 10);
          if (!isNaN(refChatId) && refChatId !== chatId) {
            pendingReferrals[chatId] = refChatId;
          }
        }
      }

      const welcomeRegText = `👋 <b>ሰላም ${firstName}! እንኳን ወደ የኛ ቢንጎ (Yegna Bingo) በደህና መጡ!</b> 🇪🇹🏆\n\n` +
        `በኢትዮጵያ የመጀመሪያው እና ትልቁ የሁለገብ ተጫዋቾች (Multiplayer) የቢንጎ መጫወቻ ቦታ።\n\n` +
        `⚠️ <b>ለመጫወት እባክዎ መጀመሪያ ይመዝገቡ!</b>\n` +
        `የ <b>10 Birr/ሳንቲም</b> ነፃ የምዝገባ ጉርሻ ለመቀበል ከታች ያለውን <b>📱 ስልክ ቁጥርዎን ያጋሩ (Share Contact)</b> የሚለውን አረንጓዴ ቁልፍ ይጫኑ።`;
        
      await sendTelegramMessage(chatId, welcomeRegText, getRegisterKeyboardMarkup(), token);
      return;
    }

    // Check for referral code in start command e.g. /start ref_12345
    if (text.startsWith('/start')) {
      const parts = text.split(' ');
      if (parts.length > 1 && parts[1].startsWith('ref_')) {
        const referrerId = parts[1].replace('ref_', '');
        const refChatId = parseInt(referrerId, 10);
        if (!isNaN(refChatId) && refChatId !== chatId) {
          // Reward the referrer with 5 bonus Birr!
          const refUsername = `user_${refChatId}`;
          if (coinsDB[refUsername] !== undefined) {
            coinsDB[refUsername] += 5;
          } else {
            coinsDB[refUsername] = 15; // 10 base + 5 bonus
          }
          console.log(`[Referral] User ${chatId} was referred by ${refChatId}. Awarding 5 Birr to referrer.`);
          // Notify referrer
          try {
            await sendTelegramMessage(refChatId, `🎉 <b>አዲስ ግብዣ!</b> ጓደኛዎ @${username || firstName} የእርስዎን ግብዣ ሊንክ በመጠቀም ጨዋታውን ተቀላቅሏል። <b>+5 Birr/ሳንቲም</b> ወደ ሂሳብዎ ገብቷል!`, getMainMenuMarkup(), token);
          } catch (e) {}
        }
      }

      const welcomeText = `👋 <b>ሰላም ${firstName}! እንኳን ወደ የኛ ቢንጎ (Yegna Bingo) በደህና መጡ!</b> 🇪🇹🏆\n\n` +
        `በኢትዮጵያ የመጀመሪያው እና ትልቁ የሁለገብ ተጫዋቾች (Multiplayer) የቢንጎ መጫወቻ ቦታ።\n\n` +
        `• በቀጥታ ከእውነተኛ ተጫዋቾች ጋር ይወዳደሩ!\n` +
        `• 10% የቤት ኮሚሽን ብቻ በመቀነስ 90% የተሰበሰበውን ሙሉ ሽልማት ይውሰዱ!\n` +
        `• ለጀማሪዎች <b>10 Birr/ሳንቲም</b> በነፃ ተዘጋጅቷል!\n\n` +
        `👇 ጨዋታውን ለመጀመር ከታች ያለውን <b>🎮 ይጫወቱ</b> የሚለውን ትልቅ ቁልፍ ይጫኑ!`;

      await sendTelegramMessage(chatId, welcomeText, getMainMenuMarkup(), token);
    } 
    else if (text === '💰 ሂሳብ' || text.startsWith('/balance')) {
      const dbUsername = username ? username.toLowerCase() : `user_${chatId}`;
      const coins = coinsDB[dbUsername] !== undefined ? coinsDB[dbUsername] : 10;
      const balText = `💰 <b>የሂሳብ መግለጫ (Account Balance)</b>\n\n` +
        `👤 <b>ተጫዋች:</b> @${username || firstName}\n` +
        `🆔 <b>የመለያ ቁጥር:</b> <code>${chatId}</code>\n` +
        `💵 <b>ያለዎት ቀሪ ሂሳብ:</b> <code>${coins.toLocaleString()} Birr / ሳንቲም</code>\n\n` +
        `ተጨማሪ ሳንቲም ለማግኘት ዕለታዊ ሽልማትን ያሽከርክሩ ወይም ጓደኛዎን ይጋብዙ!`;
      await sendTelegramMessage(chatId, balText, getMainMenuMarkup(), token);
    } 
    else if (text === '📥 ገቢ ለማድረግ' || text.startsWith('/deposit')) {
      const depText = `📥 <b>ገንዘብ ማስገቢያ መንገዶች (Deposit Options)</b>\n\n` +
        `የኛ ቢንጎን በብር ለመጫወት በተመረጡ የኢትዮጵያ የክፍያ አማራጮች ሂሳብዎን መሙላት ይችላሉ።\n\n` +
        `1️⃣ <b>Telebirr (ቴሌብር):</b>\n` +
        `👉 የቴሌብር ቁጥር፡ <code>0923512415</code>\n` +
        `👉 ስም፡ <i>Abdu M.</i>\n\n` +
        `2️⃣ <b>CBE (የኢትዮጵያ ንግድ ባንክ):</b>\n` +
        `👉 የባንክ ሂሳብ ቁጥር፡ <code>1000342938456</code>\n` +
        `👉 ስም፡ <i>Abdu M.</i>\n\n` +
        `⚠️ <b>ማሳሰቢያ:</b> ገንዘቡን ካስገቡ በኋላ የደረሰኝ ስክሪንሹት (Screenshot) ለሊግ ድጋፍ ሰጪ @YegnaBingoSupport በመላክ በ5 ደቂቃ ውስጥ እንዲሞላልዎ ያድርጉ።`;
      await sendTelegramMessage(chatId, depText, getMainMenuMarkup(), token);
    } 
    else if (text === '📤 ወጪ ለማድረግ' || text.startsWith('/withdraw')) {
      const withText = `📤 <b>ያሸነፉትን ገንዘብ ማውጫ (Withdraw)</b>\n\n` +
        `በጨዋታው ያሸነፉትን ሳንቲሞች/ብር በቀጥታ ወደ ቴሌብር (Telebirr) ወይም ወደ ባንክ ሂሳብዎ ማውጣት ይችላሉ።\n\n` +
        `📌 <b>ዝቅተኛ የማውጫ መጠን:</b> 100 Birr\n` +
        `⚡️ <b>የማውጫ ጊዜ:</b> ከ5 - 15 ደቂቃዎች\n\n` +
        `👉 ገንዘብ ለማውጣት እባክዎን የቴሌብር ቁጥርዎን እና ማውጣት የሚፈልጉትን የብር መጠን ለደንበኞች አገልግሎት @YegnaBingoSupport ይላኩ።`;
      await sendTelegramMessage(chatId, withText, getMainMenuMarkup(), token);
    } 
    else if (text === '🔗 ጋብዝ & አግኝ' || text.startsWith('/referral')) {
      const refText = `🔗 <b>የግብዣ እና ማግኛ ማዕከል (Referral Program)</b>\n\n` +
        `ጓደኞችዎን በመጋበዝ ተጨማሪ ነፃ ሳንቲሞችን/ብር ያግኙ! ለእያንዳንዱ የእርስዎን የግብዣ ሊንክ ተጠቅሞ ለሚመዘገብ ጓደኛዎ <b>5 Birr/ሳንቲም</b> በነፃ ወደ ሂሳብዎ ይገባል::\n\n` +
        `👉 <b>የእርስዎ መጋበዣ ሊንክ:</b>\n` +
        `https://t.me/YegnaBingoPlayBot?start=ref_${chatId}\n\n` +
        `ይህን ሊንክ ለጓደኞችዎ በማጋራት አብረው ይጫወቱ! 🥳`;
      await sendTelegramMessage(chatId, refText, getMainMenuMarkup(), token);
    } 
    else if (text === '💎 VIP ክፍል' || text.startsWith('/vip')) {
      const vipText = `💎 <b>የ VIP ክፍል ልዩ ጨዋታዎች (VIP Bingo)</b>\n\n` +
        `ከፍተኛ ሽልማት የሚያስገኙ ባለ ከፍተኛ ስቴክ የቢንጎ ክፍሎች! \n\n` +
        `• <b>VIP Platinum:</b> ካርድ በ 100 Birr\n` +
        `• <b>VIP Diamond:</b> ካርድ በ 250 Birr\n\n` +
        `🔥 10 ተጫዋቾች በ 250 Birr ቢጫወቱ፣ 10% ተቀንሶ <b>2,250 Birr</b> የአንድ ጊዜ አሸናፊ ሽልማት ያገኛሉ!\n\n` +
        `VIP ክፍል ለመቀላቀል እና ከፍተኛ ተወራራሾችን ለማግኘት አሁኑኑ ይጫወቱ!`;
      await sendTelegramMessage(chatId, vipText, getMainMenuMarkup(), token);
    } 
    else if (text === '🌟 Special Promoter' || text.startsWith('/promoter')) {
      const promoText = `🌟 <b>ልዩ አስተዋዋቂ (Special Promoter)</b>\n\n` +
        `የኛ ቢንጎን ለብዙ ሰዎች በማስተዋወቅ በየሳምንቱ ቋሚ ኮሚሽን ማግኘት ይፈልጋሉ?\n\n` +
        `• ከ 50 በላይ ንቁ ተጫዋቾችን ለጋበዙ ልዩ ደሞዝ እና ኮሚሽን ይከፈላል።\n` +
        `• ማስታወቂያዎችን በቴሌግራም ቻናልዎ ላይ በመጫን ገቢ ያግኙ።\n\n` +
        `👉 አስተዋዋቂ ለመሆን እና ለመመዝገብ ለዋናው ድጋፍ ሰጪ @YegnaBingoSupport በመላክ ይመዝገቡ።`;
      await sendTelegramMessage(chatId, promoText, getMainMenuMarkup(), token);
    } 
    else if (text === '🆘 እርዳታ' || text.startsWith('/help')) {
      const helpText = `🆘 <b>የእርዳታ ማዕከል (Support Center)</b>\n\n` +
        `ለማንኛውም አይነት ጥያቄ፣ የገንዘብ ማስገባት ወይም ማውጣት መዘግየት ካጋጠመዎት 24/7 እኛን ማግኘት ይችላሉ።\n\n` +
        `💬 <b>የቴሌግራም ድጋፍ፡</b> @YegnaBingoSupport\n` +
        `📞 <b>ስልክ ቁጥር፡</b> 0923512415\n\n` +
        `<i>እባክዎን የደረሰኝ ስክሪንሹት መላክዎን አይርሱ!</i>`;
      await sendTelegramMessage(chatId, helpText, getMainMenuMarkup(), token);
    } 
    else if (text === '📜 ደንቦች' || text.startsWith('/rules')) {
      const rulesText = `📜 <b>የጨዋታው ደንቦች እና መመሪያዎች (Rules)</b>\n\n` +
        `1️⃣ እያንዳንዱ ተጫዋች ከ 1 እስከ 6 የቢንጎ ካርዶችን መግዛት ይችላል።\n` +
        `2️⃣ ቁጥሮች ከ 1 እስከ 75 በዘፈቀደ ይወጣሉ። የገዙት ካርድ ላይ ያሉት ቁጥሮች ሲወጡ በፍጥነት ምልክት (Daub) ያድርጉ።\n` +
        `3️⃣ አሸናፊ የሚሆነው የመጀመሪያውን የቢንጎ ህግጋት (Full Line, Corner, Horizontal, Diagonal) የሞላ ተጫዋች ነው።\n` +
        `4️⃣ <b>ሽልማት፡</b> የሁሉም ተጫዋቾች የተሰበሰበው የካርድ መግዣ ብር ተደምሮ 10% የቤት ኮሚሽን ተቀንሶ ቀሪው 90% ሙሉ በሙሉ ለአሸናፊው ይሰጣል።\n\n` +
        `<i>ምሳሌ፡ 10 ተጫዋቾች 10 ብር ቢወራረዱ 9 * 10 = 90 ብር አሸናፊው ይወስዳል!</i>`;
      await sendTelegramMessage(chatId, rulesText, getMainMenuMarkup(), token);
    } 
    else if (text === '🎁 የሽልማት ማዕከል' || text.startsWith('/rewards')) {
      const rewardsText = `🎁 <b>የሽልማት ማዕከል (Reward Center)</b>\n\n` +
        `ለታማኝ ተጫዋቾቻችን የተዘጋጁ ልዩ ሽልማቶች! \n\n` +
        `• <b>ዕለታዊ ሽልማት (Daily Bonus):</b> በየቀኑ መተግበሪያውን ሲከፍቱ የዕድል መንኮራኩር (Lucky Wheel) በማሽከርከር ነፃ ብር ያግኙ!\n` +
        `• <b>የመጀመሪያ ተቀማጭ ጉርሻ (Deposit Bonus):</b> ለመጀመሪያ ጊዜ ገንዘብ ሲያስገቡ የ 20% ተጨማሪ ነፃ ጉርሻ ያገኛሉ።\n\n` +
        `አሁኑኑ ይጫወቱ እና የእድልዎን ኮከብ ይሞክሩ!`;
      await sendTelegramMessage(chatId, rewardsText, getMainMenuMarkup(), token);
    } 
    else {
      // General feedback with custom menu
      const defaultText = `❓ <b>ይቅርታ፣ ያልታወቀ ትዕዛዝ ነው።</b>\n\nእባክዎ ጨዋታ ለመጀመር ከታች ያለውን <b>🎮 ይጫወቱ</b> ቁልፍን ይጫኑ ወይም ሌሎች አማራጮችን ይምረጡ።`;
      await sendTelegramMessage(chatId, defaultText, getMainMenuMarkup(), token);
    }
  } else if (update.callback_query) {
    const cbQuery = update.callback_query;
    const chatId = cbQuery.message.chat.id;
    const messageId = cbQuery.message.message_id;
    const data = cbQuery.data;
    const username = cbQuery.from.username || '';
    const firstName = cbQuery.from.first_name || 'Player';

    // Acknowledge callback query
    try {
      await fetch(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ callback_query_id: cbQuery.id })
      });
    } catch (e) {}

    if (data === 'check_balance') {
      const dbUsername = username ? username.toLowerCase() : `user_${chatId}`;
      const coins = coinsDB[dbUsername] !== undefined ? coinsDB[dbUsername] : 1000;
      const balText = `💰 <b>የሂሳብ መግለጫ (Account Balance)</b>\n\n` +
        `👤 <b>ተጫዋች:</b> @${username || firstName}\n` +
        `🆔 <b>የመለያ ቁጥር:</b> <code>${chatId}</code>\n` +
        `💵 <b>ያለዎት ቀሪ ሂሳብ:</b> <code>${coins.toLocaleString()} Birr / ሳንቲም</code>\n\n` +
        `ተጨማሪ ሳንቲም ለማግኘት ዕለታዊ ሽልማትን ያሽከርክሩ ወይም ጓደኛዎን ይጋብዙ!`;
      await sendTelegramMessage(chatId, balText, getMainMenuMarkup(), token);
    } else if (data === 'how_to_play') {
      const rulesText = `📜 <b>የጨዋታው ደንቦች እና መመሪያዎች (Rules)</b>\n\n` +
        `1️⃣ እያንዳንዱ ተጫዋች ከ 1 እስከ 6 የቢንጎ ካርዶችን መግዛት ይችላል።\n` +
        `2️⃣ ቁጥሮች ከ 1 እስከ 75 በዘፈቀደ ይወጣሉ። የገዙት ካርድ ላይ ያሉት ቁጥሮች ሲወጡ በፍጥነት ምልክት (Daub) ያድርጉ።\n` +
        `3️⃣ አሸናፊ የሚሆነው የመጀመሪያውን የቢንጎ ህግጋት (Full Line, Corner, Horizontal, Diagonal) የሞላ ተጫዋች ነው።\n` +
        `4️⃣ <b>ሽልማት፡</b> የሁሉም ተጫዋቾች የተሰበሰበው የካርድ መግዣ ብር ተደምሮ 10% የቤት ኮሚሽን ተቀንሶ ቀሪው 90% ሙሉ በሙሉ ለአሸናፊው ይሰጣል።\n\n` +
        `<i>ምሳሌ፡ 10 ተጫዋቾች 10 ብር ቢወራረዱ 9 * 10 = 90 ብር አሸናፊው ይወስዳል!</i>`;
      await sendTelegramMessage(chatId, rulesText, getMainMenuMarkup(), token);
    } else if (data === 'back_to_main') {
      const welcomeText = `👋 <b>ሰላም ${firstName}! እንኳን ወደ የኛ ቢንጎ (Yegna Bingo) በደህና መጡ!</b> 🇪🇹🏆\n\n` +
        `በኢትዮጵያ የመጀመሪያው እና ትልቁ የሁለገብ ተጫዋቾች (Multiplayer) የቢንጎ መጫወቻ ቦታ።\n\n` +
        `👇 ጨዋታውን ለመጀመር ከታች ያለውን <b>🎮 ይጫወቱ</b> የሚለውን ትልቅ ቁልፍ ይጫኑ!`;
      await sendTelegramMessage(chatId, welcomeText, getMainMenuMarkup(), token);
    }
  }
}

async function initTelegramBot() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token || token === "YOUR_TELEGRAM_BOT_TOKEN") {
    console.log('[Telegram Bot] TELEGRAM_BOT_TOKEN is not configured or set to placeholder. Polling bot is disabled.');
    console.log('[Telegram Bot] Configure your TELEGRAM_BOT_TOKEN via the Secrets panel to activate your bot!');
    return;
  }

  console.log('[Telegram Bot] Initializing polling bot with token:', token.substring(0, 6) + '...');
  
  // Clear any existing webhooks to prevent 409 Conflict errors
  try {
    console.log('[Telegram Bot] Clearing any existing webhooks to enable long-polling...');
    const deleteWebhookRes = await fetch(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=true`);
    const deleteResult: any = await deleteWebhookRes.json();
    console.log('[Telegram Bot] Delete webhook result:', deleteResult);
  } catch (err: any) {
    console.error('[Telegram Bot] Failed to delete webhook during startup:', err.message || err);
  }

  let offset = 0;

  const poll = async () => {
    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/getUpdates?offset=${offset}&timeout=30`);
      if (!response.ok) {
        if (response.status === 409) {
          console.warn('[Telegram Bot] ⚠️ Conflict (409): Another instance of this bot is already running or polling. Retrying in 15 seconds...');
          await new Promise(resolve => setTimeout(resolve, 15000));
          setTimeout(poll, 200);
          return;
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: any = await response.json();
      if (data.ok && data.result && data.result.length > 0) {
        for (const update of data.result) {
          offset = update.update_id + 1;
          await handleTelegramUpdate(update, token);
        }
      }
    } catch (err: any) {
      console.error('[Telegram Bot] Polling error:', err.message || err);
      // Wait before retrying
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
    // Continue polling
    setTimeout(poll, 200);
  };

  poll();
}

startServer();
