/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BingoCell {
  value: number | 'FREE';
  daubed: boolean;
}

export interface BingoCard {
  id: string;
  grid: BingoCell[][]; // 5x5 matrix (row-major: 5 rows, 5 columns)
}

export interface Player {
  id: string; // Socket ID
  username: string;
  firstName: string;
  avatarUrl?: string;
  coins: number;
  cards: BingoCard[];
  isReady: boolean;
  cardsPurchased: number;
  freezeUntil?: number; // timestamp when frozen penalty expires
}

export interface GameRoom {
  id: string;
  name: string;
  status: 'lobby' | 'countdown' | 'playing' | 'ended';
  players: { [id: string]: Player };
  drawnNumbers: number[];
  currentNumber: number | null;
  countdown: number; // seconds remaining in lobby/countdown phase
  winners: Array<{
    playerId: string;
    username: string;
    pattern: string;
    timestamp: number;
    prize?: number;
  }>;
  nextBallCountdown: number; // ms remaining to next ball
  cardPrice: number; // Cost per card
}

export interface HistoricalGame {
  id: string;
  roomName: string;
  date: string;
  patterns: string[];
  winners: string[];
  cardsPlayed: number;
  coinsEarned: number;
}

export type WinningPatternType = 'Line' | 'Four Corners' | 'Full House';

// Socket Communication Events
export interface ServerToClientEvents {
  'room:state': (room: GameRoom) => void;
  'game:ball': (data: { number: number; drawnNumbers: number[] }) => void;
  'game:ended': (data: { winners: Array<{ playerId: string; username: string; pattern: string; timestamp: number }>; room: GameRoom }) => void;
  'player:updated': (player: Player) => void;
  'player:coins': (coins: number) => void;
  'chat:message': (msg: { sender: string; text: string; timestamp: number }) => void;
  'game:penalty': (data: { seconds: number }) => void;
  'game:error': (msg: string) => void;
  'notification': (data: { type: 'success' | 'error' | 'info'; message: string }) => void;
}

export interface ClientToServerEvents {
  'lobby:join': (data: { username: string; firstName: string; avatarUrl?: string }) => void;
  'room:buy_cards': (count: number) => void;
  'room:ready': () => void;
  'game:daub': (data: { cardId: string; rowIndex: number; colIndex: number }) => void;
  'game:claim_bingo': () => void;
  'chat:send': (text: string) => void;
  'lobby:leave': () => void;
}
