import { BingoCard, BingoCell } from './types';

// Seeded deterministic pseudo-random generator
export function getSeededRandom(seed: number) {
  // Simple LCG or trig seed
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

// Generate valid deterministic 75-Ball Bingo Card based on ticket number (1-90)
export function generateDeterministicBingoCard(seedNum: number): BingoCard {
  let rngVal = seedNum * 777; // Simple scaling to vary starting seeds
  const nextRng = () => {
    rngVal = (rngVal * 9301 + 49297) % 233280;
    return rngVal / 233280;
  };

  const getUniqueRandoms = (min: number, max: number, count: number) => {
    const nums = new Set<number>();
    while (nums.size < count) {
      const r = nextRng();
      const val = Math.floor(r * (max - min + 1)) + min;
      nums.add(val);
    }
    return Array.from(nums).sort((a, b) => a - b);
  };

  const bCols = getUniqueRandoms(1, 15, 5);
  const iCols = getUniqueRandoms(16, 30, 5);
  const nCols = getUniqueRandoms(31, 45, 4); // 4 numbers, 1 FREE space in center
  const gCols = getUniqueRandoms(46, 60, 5);
  const oCols = getUniqueRandoms(61, 75, 5);

  const grid: BingoCell[][] = [];
  for (let r = 0; r < 5; r++) {
    const row: BingoCell[] = [];
    // Column 0 (B)
    row.push({ value: bCols[r], daubed: false });
    // Column 1 (I)
    row.push({ value: iCols[r], daubed: false });
    // Column 2 (N)
    if (r === 2) {
      row.push({ value: 'FREE', daubed: true });
    } else {
      const nVal = r < 2 ? nCols[r] : nCols[r - 1];
      row.push({ value: nVal, daubed: false });
    }
    // Column 3 (G)
    row.push({ value: gCols[r], daubed: false });
    // Column 4 (O)
    row.push({ value: oCols[r], daubed: false });

    grid.push(row);
  }

  return {
    id: `CARD-${seedNum}`,
    grid,
  };
}

// Verify patterns on a card against drawn numbers
export function verifyWinningPatterns(card: BingoCard, drawnNumbers: number[]): { won: boolean; patterns: string[] } {
  const isMarked = (r: number, c: number) => {
    const cell = card.grid[r][c];
    if (cell.value === 'FREE') return true;
    // For client-side simulation, the number must be daubed AND must be in the drawn numbers list
    return cell.daubed && drawnNumbers.includes(cell.value as number);
  };

  const wonPatterns: string[] = [];

  // 1. Check rows
  for (let r = 0; r < 5; r++) {
    let rowComplete = true;
    for (let c = 0; c < 5; c++) {
      if (!isMarked(r, c)) {
        rowComplete = false;
        break;
      }
    }
    if (rowComplete) wonPatterns.push(`Row ${r + 1} Line`);
  }

  // 2. Check columns
  for (let c = 0; c < 5; c++) {
    let colComplete = true;
    for (let r = 0; r < 5; r++) {
      if (!isMarked(r, c)) {
        colComplete = false;
        break;
      }
    }
    if (colComplete) {
      const colLetter = ['B', 'I', 'N', 'G', 'O'][c];
      wonPatterns.push(`Column ${colLetter} Line`);
    }
  }

  // 3. Check major diagonal (top-left to bottom-right)
  let majorDiag = true;
  for (let i = 0; i < 5; i++) {
    if (!isMarked(i, i)) {
      majorDiag = false;
      break;
    }
  }
  if (majorDiag) wonPatterns.push('Diagonal Line (\\)');

  // 4. Check minor diagonal (top-right to bottom-left)
  let minorDiag = true;
  for (let i = 0; i < 5; i++) {
    if (!isMarked(i, 4 - i)) {
      minorDiag = false;
      break;
    }
  }
  if (minorDiag) wonPatterns.push('Diagonal Line (/)');

  // 5. Check Four Corners
  if (isMarked(0, 0) && isMarked(0, 4) && isMarked(4, 0) && isMarked(4, 4)) {
    wonPatterns.push('Four Corners');
  }

  // 6. Check Full House (Blackout)
  let fullHouse = true;
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 5; c++) {
      if (!isMarked(r, c)) {
        fullHouse = false;
        break;
      }
    }
  }
  if (fullHouse) wonPatterns.push('Full House (Blackout)');

  return {
    won: wonPatterns.length > 0,
    patterns: wonPatterns,
  };
}

// Persist and increment real player gameplay statistics (eliminating mock values)
export function recordGameplay(won: boolean): void {
  if (typeof window === 'undefined') return;
  const localStats = localStorage.getItem('habesha_bingo_stats');
  let stats = {
    gamesPlayed: 0,
    gamesWon: 0,
    bestWinningStreak: 0,
    currentStreak: 0,
    joinDate: 'July 2026'
  };
  if (localStats) {
    try {
      stats = { ...stats, ...JSON.parse(localStats) };
    } catch (e) {}
  }
  stats.gamesPlayed += 1;
  if (won) {
    stats.gamesWon += 1;
    // Handle optional currentStreak support
    const current = (stats.currentStreak || 0) + 1;
    stats.currentStreak = current;
    stats.bestWinningStreak = Math.max(stats.bestWinningStreak || 0, current);
  } else {
    stats.currentStreak = 0;
  }
  localStorage.setItem('habesha_bingo_stats', JSON.stringify(stats));
}

