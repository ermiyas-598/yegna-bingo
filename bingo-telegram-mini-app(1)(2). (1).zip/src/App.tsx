/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { GameRoom, Player } from './types';
import BingoRoomList from './components/BingoRoomList';
import BingoGameView from './components/BingoGameView';
import UserProfile from './components/UserProfile';
import UserWallet from './components/UserWallet';
import BingoRankList from './components/BingoRankList';
import WelcomeScreen from './components/WelcomeScreen';
import { 
  Trophy, Coins, Volume2, Sparkles, HelpCircle, 
  Layers, Flame, Compass, RefreshCw, X, User, Wallet,
  Home, Ticket, Music
} from 'lucide-react';
import { soundManager } from './utils/soundManager';
import { recordGameplay } from './utils';
import { YegnaLogo } from './components/YegnaLogo';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

// Synchronously load profile state on first mount to skip any login welcome screen if already registered!
const getInitialPlayer = (): Player | null => {
  const saved = localStorage.getItem('habesha_bingo_profile');
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      return {
        id: 'local_player',
        username: parsed.username,
        firstName: parsed.firstName,
        avatarUrl: parsed.avatarUrl || '🦁',
        coins: Number(localStorage.getItem('habesha_bingo_coins') || '1000'),
        cards: [],
        isReady: false,
        cardsPurchased: 0,
      };
    } catch (e) {}
  }
  return null;
};

export default function App() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isJoined, setIsJoined] = useState(() => localStorage.getItem('habesha_bingo_profile') !== null);
  const [player, setPlayer] = useState<Player | null>(() => getInitialPlayer());
  const [room, setRoom] = useState<GameRoom | null>(null);
  const [allRooms, setAllRooms] = useState<{ [id: string]: GameRoom }>({
    'room10': { id: 'room10', name: 'Bronze Hall (10 Birr)', status: 'lobby', players: {}, drawnNumbers: [], currentNumber: null, countdown: 6, winners: [], nextBallCountdown: 0, cardPrice: 10 },
    'room30': { id: 'room30', name: 'Silver Palace (30 Birr)', status: 'lobby', players: {}, drawnNumbers: [], currentNumber: null, countdown: 6, winners: [], nextBallCountdown: 0, cardPrice: 30 },
    'room50': { id: 'room50', name: 'Gold Diamond (50 Birr)', status: 'lobby', players: {}, drawnNumbers: [], currentNumber: null, countdown: 6, winners: [], nextBallCountdown: 0, cardPrice: 50 },
    'room100': { id: 'room100', name: 'Platinum VIP (100 Birr)', status: 'lobby', players: {}, drawnNumbers: [], currentNumber: null, countdown: 6, winners: [], nextBallCountdown: 0, cardPrice: 100 },
  });
  
  // Navigation: 'play' | 'ticket' | 'wallet' | 'rank' | 'profile'
  const [activeTab, setActiveTab] = useState<'play' | 'ticket' | 'wallet' | 'rank' | 'profile'>('play');
  const [toasts, setToasts] = useState<Toast[]>([]);

  const playerRef = useRef(player);
  useEffect(() => {
    playerRef.current = player;
  }, [player]);

  // Sound States & Toggles
  const [bgmEnabled, setBgmEnabled] = useState(() => soundManager.getBgmEnabled());
  const [sfxEnabled, setSfxEnabled] = useState(() => soundManager.getSfxEnabled());
  const [showSoundMenu, setShowSoundMenu] = useState(false);

  // Initialize and clean up BGM
  useEffect(() => {
    if (isJoined) {
      soundManager.initialize();
    }
    return () => {
      soundManager.stopBGM();
    };
  }, [isJoined]);

  // Click interceptor to initialize AudioContext upon first interaction
  useEffect(() => {
    const handleFirstInteraction = () => {
      soundManager.initialize();
      window.removeEventListener('click', handleFirstInteraction);
    };
    window.addEventListener('click', handleFirstInteraction);
    return () => {
      window.removeEventListener('click', handleFirstInteraction);
    };
  }, []);

  const handleToggleBgm = () => {
    const newVal = soundManager.toggleBGM();
    setBgmEnabled(newVal);
    showToast(
      newVal 
        ? 'የጀርባ ሙዚቃ በርቷል 🎵 (Background Music Enabled)' 
        : 'የጀርባ ሙዚቃ ጠፍቷል 🔇 (Background Music Disabled)', 
      'info'
    );
  };

  const handleToggleSfx = () => {
    const newVal = soundManager.toggleSFX();
    setSfxEnabled(newVal);
    if (newVal) {
      soundManager.playDaub();
    }
    showToast(
      newVal 
        ? 'የጨዋታ ድምፅ ውጤቶች በርተዋል 🔊 (Sound Effects Enabled)' 
        : 'የጨዋታ ድምፅ ውጤቶች ጠፍተዋል 🔇 (Sound Effects Disabled)', 
      'info'
    );
  };

  // Handle Toast dismissals
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3500);
  };

  // Socket initialization & automatic registration on mount
  useEffect(() => {
    const currentProfile = {
      username: player?.username || 'anonymous',
      firstName: player?.firstName || 'Anonymous',
      avatarUrl: player?.avatarUrl || '🦁'
    };

    const newSocket = io(window.location.origin, {
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 5,
    });

    setSocket(newSocket);

    // Register general socket events
    newSocket.on('connect', () => {
      newSocket.emit('lobby:join', currentProfile);
      showToast('Connected to TON Bingo Hall! 🇪🇹', 'success');
    });

    newSocket.on('connect_error', () => {
      showToast('Running in local practice mode', 'info');
    });

    newSocket.on('player:updated', (updatedPlayer: Player) => {
      setPlayer(updatedPlayer);
      localStorage.setItem('habesha_bingo_coins', String(updatedPlayer.coins));
    });

    newSocket.on('room:state', (updatedRoom: GameRoom) => {
      let joinedSuccess = false;
      setRoom(prev => {
        const isMeInRoom = (newSocket.id && updatedRoom.players[newSocket.id]) ||
                           Object.values(updatedRoom.players).some(p => p.username === playerRef.current?.username);

        if (prev && prev.id === updatedRoom.id) {
          if (!isMeInRoom && updatedRoom.status === 'playing') {
            return null; // Go back to foyer since they did not purchase tickets
          }
          return updatedRoom;
        }
        if (!prev && isMeInRoom) {
          joinedSuccess = true;
          return updatedRoom;
        }
        return prev;
      });

      setAllRooms(prev => ({
        ...prev,
        [updatedRoom.id]: updatedRoom
      }));
    });

    newSocket.on('game:ball', (ballData: { number: number; drawnNumbers: number[] }) => {
      soundManager.playBall(ballData.number);
    });

    newSocket.on('game:ended', (endedData: { winners: any[]; room: GameRoom }) => {
      setRoom(endedData.room);
      
      const isMeWinner = endedData.winners.some(w => w.playerId === newSocket.id);

      // If we participated in this room and had tickets, increment our real stats!
      const savedProfile = localStorage.getItem('habesha_bingo_profile');
      if (savedProfile) {
        try {
          const parsed = JSON.parse(savedProfile);
          const myUsername = parsed.username || '';
          const meInRoom = endedData.room.players[myUsername];
          if (meInRoom && meInRoom.cards && meInRoom.cards.length > 0) {
            recordGameplay(isMeWinner);
          }
        } catch (e) {}
      }
      
      if (isMeWinner) {
        soundManager.playWin();
        showToast('🎉 እንኳን ደስ አሎት! አሸንፈዋል! You Won!', 'success');
      } else {
        soundManager.playLoss();
        showToast(
          endedData.winners.length > 0 
            ? `ክብሩ ተጠናቋል! አሸናፊው: ${endedData.winners[0].username} (Round ended! Winner: ${endedData.winners[0].username})` 
            : 'ያለ አሸናፊ ጨዋታው ተጠናቋል። (Round completed with no winner.)',
          'info'
        );
      }
    });

    newSocket.on('room:kicked_no_cards', () => {
      setRoom(null);
      showToast('Returned to foyer: please select and buy at least 1 card to participate.', 'info');
    });

    newSocket.on('notification', (notif: { type: 'success' | 'error' | 'info'; message: string }) => {
      showToast(notif.message, notif.type);
    });

    newSocket.on('game:error', (errorMsg: string) => {
      showToast(errorMsg, 'error');
    });

    return () => {
      newSocket.disconnect();
    };
  }, []);

  // Cleanup socket on unmount
  useEffect(() => {
    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, [socket]);

  const handleJoinRoom = (roomId: string) => {
    if (socket) {
      socket.emit('room:join', roomId);
      setRoom(null);
      showToast(`Entering hall room...`, 'info');
    }
  };

  const handleLeaveCurrentRoom = () => {
    if (socket) {
      socket.emit('lobby:leave');
      setRoom(null);
      showToast('Returned to main foyer', 'info');
    }
  };

  const handleUpdateCoinsSolo = (newCoins: number) => {
    setPlayer(prev => {
      if (!prev) return null;
      localStorage.setItem('habesha_bingo_coins', String(newCoins));
      return { ...prev, coins: newCoins };
    });
    if (socket) {
      socket.emit('player:update_coins_solo', newCoins);
    }
  };

  const handleUpdateProfile = (firstName: string, avatarUrl: string) => {
    setPlayer(prev => {
      if (!prev) return null;
      localStorage.setItem('habesha_bingo_profile', JSON.stringify({
        username: prev.username,
        firstName,
        avatarUrl
      }));
      return { ...prev, firstName, avatarUrl };
    });
    if (socket) {
      socket.emit('player:update_profile', { firstName, avatarUrl });
    }
    showToast('Identity updated successfully! 🎭', 'success');
  };

  const handleWelcomeJoin = (data: { username: string; firstName: string; avatarUrl: string; customCoins?: number }) => {
    const initialCoins = data.customCoins || 1000;
    const newPlayer: Player = {
      id: socket ? socket.id : 'local_player',
      username: data.username,
      firstName: data.firstName,
      avatarUrl: data.avatarUrl,
      coins: initialCoins,
      cards: [],
      isReady: false,
      cardsPurchased: 0,
    };

    localStorage.setItem('habesha_bingo_profile', JSON.stringify({
      username: data.username,
      firstName: data.firstName,
      avatarUrl: data.avatarUrl
    }));
    localStorage.setItem('habesha_bingo_coins', String(initialCoins));

    setPlayer(newPlayer);
    setIsJoined(true);

    if (socket) {
      socket.emit('lobby:join', {
        username: data.username,
        firstName: data.firstName,
        avatarUrl: data.avatarUrl,
        coins: initialCoins
      });
    }
    showToast(`እንኳን ደህና መጡ ${data.firstName}! ${data.customCoins ? '🎁 50% Welcome Bonus Applied!' : '🎉'}`, 'success');
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans antialiased text-slate-100" id="main_app_wrapper">
      {/* Floating Toast Notification Console */}
      <div className="fixed top-4 right-4 z-50 space-y-2 pointer-events-none" id="toast_console">
        {toasts.map(t => (
          <div 
            key={t.id} 
            className={`pointer-events-auto px-4 py-3 rounded-xl border shadow-lg text-xs font-black uppercase tracking-wider flex items-center justify-between gap-3 animate-fade-in ${
              t.type === 'success' 
                ? 'bg-emerald-950 border-emerald-500 text-emerald-400' 
                : t.type === 'error'
                ? 'bg-rose-950 border-rose-500 text-rose-400'
                : 'bg-indigo-950 border-indigo-500 text-indigo-400'
            }`}
          >
            <span>{t.message}</span>
            <button 
              onClick={() => setToasts(prev => prev.filter(item => item.id !== t.id))}
              className="hover:opacity-80 transition-opacity"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Main Container Core - Expanded to Max-W-5xl for Full Screen Experience */}
      <div className="w-full max-w-5xl mx-auto min-h-screen flex flex-col justify-between bg-slate-950 shadow-2xl border-x border-slate-900" id="app_viewport">
        
        {/* Header Display */}
        {isJoined && player && (
          <header className="sticky top-0 bg-slate-900/90 backdrop-blur-md border-b border-slate-850 px-6 py-4 flex justify-between items-center z-30 shadow-md">
            <div className="flex items-center gap-4">
              <YegnaLogo size={46} className="flex-shrink-0" />
              <div className="flex items-center gap-2.5">
                <div className="space-y-0.5">
                  <span className="text-[8px] uppercase tracking-wider font-extrabold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full inline-block leading-none">Dauber</span>
                  <span className="text-sm font-black text-slate-100 block truncate max-w-[150px]">
                    {player.firstName}
                  </span>
                </div>
              </div>
            </div>

            {/* Premium Desktop Navigation Tabs */}
            <div className="hidden md:flex items-center bg-slate-950/80 p-1.5 rounded-2xl border border-slate-850" id="desktop_header_tabs">
              <button
                onClick={() => setActiveTab('play')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                  activeTab === 'play'
                    ? 'bg-emerald-500 text-slate-950 shadow-lg border border-emerald-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
                }`}
              >
                <Home className="w-4 h-4" />
                <span>Home</span>
              </button>

              <button
                onClick={() => setActiveTab('ticket')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                  activeTab === 'ticket'
                    ? 'bg-emerald-500 text-slate-950 shadow-lg border border-emerald-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
                }`}
              >
                <Ticket className="w-4 h-4" />
                <span>Ticket</span>
              </button>

              <button
                onClick={() => setActiveTab('wallet')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                  activeTab === 'wallet'
                    ? 'bg-emerald-500 text-slate-950 shadow-lg border border-emerald-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
                }`}
              >
                <Wallet className="w-4 h-4" />
                <span>Wallet</span>
              </button>

              <button
                onClick={() => setActiveTab('rank')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                  activeTab === 'rank'
                    ? 'bg-emerald-500 text-slate-950 shadow-lg border border-emerald-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
                }`}
              >
                <Trophy className="w-4 h-4" />
                <span>Rank</span>
              </button>

              <button
                onClick={() => setActiveTab('profile')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 ${
                  activeTab === 'profile'
                    ? 'bg-emerald-500 text-slate-950 shadow-lg border border-emerald-400'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Profile</span>
              </button>
            </div>

            <div className="flex items-center gap-2" id="header_controls_group">
              {/* Quick Wallet Bank Tracker */}
              <button 
                onClick={() => setActiveTab('wallet')}
                className="flex items-center gap-2 px-3.5 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 transition-all rounded-xl border border-indigo-500/30 group text-left"
              >
                <Coins className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform" />
                <div className="flex flex-col">
                  <span className="text-[8px] uppercase tracking-wider text-slate-500 font-extrabold block leading-none">Wallet</span>
                  <span className="text-xs font-black text-indigo-300 font-mono">
                    {player.coins.toLocaleString()} ETB
                  </span>
                </div>
              </button>

              {/* Audio Settings Dropdown (Amharic) */}
              <div className="relative" id="sound_settings_popover">
                <button
                  onClick={() => {
                    soundManager.playClick();
                    setShowSoundMenu(!showSoundMenu);
                  }}
                  className={`p-2 rounded-xl border transition-all flex items-center justify-center gap-1.5 ${
                    showSoundMenu 
                      ? 'bg-indigo-500 text-white border-indigo-400 shadow-md shadow-indigo-500/20' 
                      : 'bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                  title="የድምፅ ቅንብሮች (Audio Settings)"
                >
                  {sfxEnabled ? <Volume2 className="w-4 h-4 text-indigo-400" /> : <Volume2 className="w-4 h-4 text-slate-500" />}
                  <span className="text-[10px] uppercase font-extrabold tracking-wide hidden sm:inline-block">የድምፅ ቅንብሮች</span>
                </button>

                {showSoundMenu && (
                  <>
                    {/* Backdrop closer */}
                    <div className="fixed inset-0 z-40" onClick={() => setShowSoundMenu(false)} />
                    
                    {/* Dropdown Card */}
                    <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-2xl z-50 animate-fade-in space-y-3.5" id="sound_menu_dropdown">
                      <div className="border-b border-slate-800 pb-2 flex justify-between items-center">
                        <span className="text-xs font-black text-slate-100 uppercase tracking-wide flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                          የድምፅ ማስተካከያ (Audio)
                        </span>
                        <button 
                          onClick={() => setShowSoundMenu(false)}
                          className="text-slate-500 hover:text-slate-300 transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* BGM Toggle Row */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-[11px] font-extrabold text-slate-300">የጀርባ ሙዚቃ (BGM)</span>
                          <span className={`text-[10px] font-black px-1.5 py-0.5 rounded uppercase ${bgmEnabled ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-950 text-slate-500 border border-slate-850'}`}>
                            {bgmEnabled ? 'በርቷል (On)' : 'ጠፍቷል (Off)'}
                          </span>
                        </div>
                        <button
                          onClick={handleToggleBgm}
                          className={`w-full py-2 px-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 border ${
                            bgmEnabled 
                              ? 'bg-indigo-500 hover:bg-indigo-400 text-white border-indigo-400 shadow-sm' 
                              : 'bg-slate-950 hover:bg-slate-900 text-slate-400 border-slate-850'
                          }`}
                        >
                          <Music className="w-3.5 h-3.5" />
                          {bgmEnabled ? 'የጀርባ ሙዚቃን አጥፋ (Mute)' : 'የጀርባ ሙዚቃን አብራ (Play)'}
                        </button>
                      </div>

                      {/* SFX Toggle Row */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-[11px] font-extrabold text-slate-300">የጨዋታ ድምፆች (SFX)</span>
                          <span className={`text-[10px] font-black px-1.5 py-0.5 rounded uppercase ${sfxEnabled ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-950 text-slate-500 border border-slate-850'}`}>
                            {sfxEnabled ? 'በርቷል (On)' : 'ጠፍቷል (Off)'}
                          </span>
                        </div>
                        <button
                          onClick={handleToggleSfx}
                          className={`w-full py-2 px-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 border ${
                            sfxEnabled 
                              ? 'bg-indigo-500 hover:bg-indigo-400 text-white border-indigo-400 shadow-sm' 
                              : 'bg-slate-950 hover:bg-slate-900 text-slate-400 border-slate-850'
                          }`}
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          {sfxEnabled ? 'የጨዋታ ድምፅ አጥፋ (Mute)' : 'የጨዋታ ድምፅ አብራ (Unmute)'}
                        </button>
                      </div>

                      {/* Test Audio Synthesizer Controls */}
                      <div className="pt-2 border-t border-slate-800 space-y-1.5">
                        <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500 block">ድምፅ ለመሞከር (Test SFX)</span>
                        <div className="grid grid-cols-2 gap-1.5">
                          <button
                            onClick={() => {
                              soundManager.initialize();
                              soundManager.playDaub();
                            }}
                            className="py-1.5 px-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 hover:border-slate-800 text-[10px] font-bold rounded-lg text-slate-300 flex items-center justify-center gap-1"
                          >
                            📍 ዳብ (Daub)
                          </button>
                          <button
                            onClick={() => {
                              soundManager.initialize();
                              soundManager.playWin();
                            }}
                            className="py-1.5 px-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 hover:border-slate-800 text-[10px] font-bold rounded-lg text-slate-300 flex items-center justify-center gap-1"
                          >
                            🏆 ማሸነፍ (Win)
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </header>
        )}

        {/* Content Router Arena */}
        <main className="flex-1 p-4 pb-28 md:pb-8" id="main_content_arena">
          {!isJoined ? (
            <WelcomeScreen onJoin={handleWelcomeJoin} />
          ) : activeTab === 'play' ? (
            room ? (
              <BingoGameView 
                room={room} 
                currentPlayer={player} 
                socket={socket}
                onLeaveRoom={handleLeaveCurrentRoom}
                gameMode="multi"
              />
            ) : (
              <BingoRoomList 
                rooms={allRooms} 
                currentRoomId={room ? room.id : null}
                onJoinRoom={handleJoinRoom}
                playerCoins={player ? player.coins : 0}
              />
            )
          ) : activeTab === 'ticket' ? (
            room ? (
              <BingoGameView 
                room={room} 
                currentPlayer={player} 
                socket={socket}
                onLeaveRoom={handleLeaveCurrentRoom}
                gameMode="multi"
              />
            ) : (
              <div className="bg-slate-900 border border-slate-850 rounded-3xl p-8 text-center space-y-6 max-w-sm mx-auto my-12 shadow-xl animate-fade-in" id="ticket_empty_tab">
                <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-md">
                  <Ticket className="w-8 h-8" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-black text-slate-100">የሚገኙ ካርታዎች የሉም</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    You are not currently in a room. Join a premium Bingo room from the Home tab to select and buy your winning tickets.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('play')}
                  className="w-full py-3 px-5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all shadow-md"
                >
                  በመጫወቻ አዳራሽ ይግቡ
                </button>
              </div>
            )
          ) : activeTab === 'rank' ? (
            <BingoRankList 
              playerCoins={player ? player.coins : 1000}
              playerUsername={player ? player.firstName : 'Money 💸'}
              playerAvatar={player ? player.avatarUrl || '🦁' : '👤'}
            />
          ) : activeTab === 'profile' ? (
            <UserProfile 
              player={player}
              onUpdateProfile={handleUpdateProfile}
            />
          ) : activeTab === 'wallet' ? (
            <UserWallet 
              currentBalance={player ? player.coins : 0}
              onUpdateCoins={handleUpdateCoinsSolo}
              showToast={showToast}
            />
          ) : null}
        </main>

        {/* Premium Bottom Navigation Bar - Aligned to max-w-5xl */}
        {isJoined && (
          <nav className="md:hidden fixed bottom-0 left-0 right-0 max-w-5xl mx-auto bg-slate-900/95 backdrop-blur-md border-t border-slate-850 px-4 py-3.5 flex justify-around items-center z-40 shadow-2xl rounded-t-2xl">
            {/* Tab 1: Home */}
            <button
              onClick={() => setActiveTab('play')}
              className={`flex flex-col items-center gap-1 transition-all ${
                activeTab === 'play'
                  ? 'text-emerald-400 scale-105 font-black'
                  : 'text-slate-500 hover:text-slate-300 font-bold'
              }`}
            >
              <div className={`p-1 rounded-full ${activeTab === 'play' ? 'bg-emerald-500/10' : ''}`}>
                <Home className="w-5 h-5" />
              </div>
              <span className="text-[9px] uppercase tracking-wider">Home</span>
            </button>

            {/* Tab 2: Ticket */}
            <button
              onClick={() => {
                // If in a room, it opens the active board/selector, else routes cleanly
                setActiveTab('ticket');
              }}
              className={`flex flex-col items-center gap-1 transition-all relative ${
                activeTab === 'ticket'
                  ? 'text-emerald-400 scale-105 font-black'
                  : 'text-slate-500 hover:text-slate-300 font-bold'
              }`}
            >
              <div className={`p-1 rounded-full ${activeTab === 'ticket' ? 'bg-emerald-500/10' : ''}`}>
                <Ticket className="w-5 h-5" />
              </div>
              <span className="text-[9px] uppercase tracking-wider">Ticket</span>
              {room && (
                <span className="absolute top-1 right-2 w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
              )}
            </button>

            {/* Tab 3: Wallet */}
            <button
              onClick={() => setActiveTab('wallet')}
              className={`flex flex-col items-center gap-1 transition-all ${
                activeTab === 'wallet'
                  ? 'text-emerald-400 scale-105 font-black'
                  : 'text-slate-500 hover:text-slate-300 font-bold'
              }`}
            >
              <div className={`p-1 rounded-full ${activeTab === 'wallet' ? 'bg-emerald-500/10' : ''}`}>
                <Wallet className="w-5 h-5" />
              </div>
              <span className="text-[9px] uppercase tracking-wider">Wallet</span>
            </button>

            {/* Tab 4: Rank */}
            <button
              onClick={() => setActiveTab('rank')}
              className={`flex flex-col items-center gap-1 transition-all ${
                activeTab === 'rank'
                  ? 'text-emerald-400 scale-105 font-black'
                  : 'text-slate-500 hover:text-slate-300 font-bold'
              }`}
            >
              <div className={`p-1 rounded-full ${activeTab === 'rank' ? 'bg-emerald-500/10' : ''}`}>
                <Trophy className="w-5 h-5" />
              </div>
              <span className="text-[9px] uppercase tracking-wider">Rank</span>
            </button>

            {/* Tab 5: Profile */}
            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center gap-1 transition-all ${
                activeTab === 'profile'
                  ? 'text-emerald-400 scale-105 font-black'
                  : 'text-slate-500 hover:text-slate-300 font-bold'
              }`}
            >
              <div className={`p-1 rounded-full ${activeTab === 'profile' ? 'bg-emerald-500/10' : ''}`}>
                <User className="w-5 h-5" />
              </div>
              <span className="text-[9px] uppercase tracking-wider">Profile</span>
            </button>
          </nav>
        )}
      </div>

    </div>
  );
}
