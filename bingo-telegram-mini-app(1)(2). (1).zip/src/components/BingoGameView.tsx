/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { GameRoom, Player, BingoCard, BingoCell } from '../types.js';
import { 
  Users, Coins, Check, Timer, 
  Sparkles, ShieldAlert, Send, Volume2, VolumeX, Trophy, Play, X
} from 'lucide-react';
import CardSelector from './CardSelector';
import { generateDeterministicBingoCard, verifyWinningPatterns, recordGameplay } from '../utils';
import { soundManager } from '../utils/soundManager';
import { YegnaLogo } from './YegnaLogo';

interface BingoGameViewProps {
  room: GameRoom;
  currentPlayer: Player | null;
  socket: any;
  onLeaveRoom: () => void;
  gameMode: 'multi' | 'solo';
  onUpdateCoins?: (coins: number) => void;
}

export default function BingoGameView({ 
  room, 
  currentPlayer, 
  socket, 
  onLeaveRoom,
  gameMode,
  onUpdateCoins
}: BingoGameViewProps) {
  const [ticketCount, setTicketCount] = useState(1);
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [chatMessage, setChatMessage] = useState('');
  const [chatLog, setChatLog] = useState<Array<{ sender: string; text: string; timestamp: number }>>([]);
  const [soundEnabled, setSoundEnabled] = useState(() => soundManager.getSfxEnabled());
  const [penaltySeconds, setPenaltySeconds] = useState<number | null>(null);

  // --- LOCAL SOLO MODE STATE ---
  const [localRoom, setLocalRoom] = useState<GameRoom>({
    id: room.id,
    name: room.name,
    status: 'lobby',
    players: {
      'me': {
        id: 'me',
        username: currentPlayer?.username || 'player',
        firstName: currentPlayer?.firstName || 'Anonymous',
        avatarUrl: currentPlayer?.avatarUrl || '',
        coins: currentPlayer?.coins || 1000,
        cards: [],
        isReady: false,
        cardsPurchased: 0,
      },
      'comp1': {
        id: 'comp1',
        username: 'abebe',
        firstName: 'Abebe',
        avatarUrl: '',
        coins: 500,
        cards: [12, 45].map(n => generateDeterministicBingoCard(n)),
        isReady: true,
        cardsPurchased: 2,
      },
      'comp2': {
        id: 'comp2',
        username: 'kebede',
        firstName: 'Kebede',
        avatarUrl: '',
        coins: 800,
        cards: [67].map(n => generateDeterministicBingoCard(n)),
        isReady: true,
        cardsPurchased: 1,
      },
      'comp3': {
        id: 'comp3',
        username: 'chala',
        firstName: 'Chala',
        avatarUrl: '',
        coins: 1200,
        cards: [3, 29, 88].map(n => generateDeterministicBingoCard(n)),
        isReady: true,
        cardsPurchased: 3,
      }
    },
    drawnNumbers: [],
    currentNumber: null,
    countdown: 45,
    winners: [],
    nextBallCountdown: 0,
    cardPrice: room.cardPrice,
  });

  const chatEndRef = useRef<HTMLDivElement>(null);

  const handleToggleLocalSound = () => {
    const newVal = soundManager.toggleSFX();
    setSoundEnabled(newVal);
  };

  // Unified getters to switch seamlessly between multiplayer and local solo states
  const activeRoom = gameMode === 'solo' ? localRoom : room;
  const activePlayer = gameMode === 'solo' ? localRoom.players['me'] : currentPlayer;

  const isMeWinner = activeRoom.winners?.some(
    w => w.playerId === (gameMode === 'solo' ? 'me' : (socket?.id || ''))
  );

  // Dynamic prize pool: total cards in room * (cardPrice - 10% commission cut)
  const totalCardsPurchasedInRoom = Object.values(activeRoom.players || {}).reduce(
    (acc: number, p: any) => acc + (p.cardsPurchased || 0), 
    0
  ) as number;
  const commissionPerCardInRoom = Math.round(activeRoom.cardPrice * 0.10);
  const prizePerCardInRoom = activeRoom.cardPrice - commissionPerCardInRoom;
  const currentPrizePoolAmount = totalCardsPurchasedInRoom * prizePerCardInRoom;

  // Sync penalty when player state changes
  useEffect(() => {
    if (activePlayer?.freezeUntil) {
      const remaining = Math.ceil((activePlayer.freezeUntil - Date.now()) / 1000);
      if (remaining > 0) {
        setPenaltySeconds(remaining);
      }
    } else {
      setPenaltySeconds(null);
    }
  }, [activePlayer, gameMode]);

  // Handle active penalty ticking down
  useEffect(() => {
    if (penaltySeconds && penaltySeconds > 0) {
      const timer = setTimeout(() => {
        setPenaltySeconds(penaltySeconds - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (penaltySeconds === 0) {
      setPenaltySeconds(null);
    }
  }, [penaltySeconds]);

  // Scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatLog]);

  // Auto-tick matching numbers when called (drawn)
  useEffect(() => {
    if (activeRoom.status !== 'playing' || !activeRoom.currentNumber) return;
    const currentNum = activeRoom.currentNumber;
    if (activePlayer && activePlayer.cards && activePlayer.cards.length > 0) {
      activePlayer.cards.forEach(card => {
        card.grid.forEach((row, rIdx) => {
          row.forEach((cell, cIdx) => {
            if (cell.value === currentNum && !cell.daubed) {
              handleDaub(card.id, rIdx, cIdx);
            }
          });
        });
      });
    }
  }, [activeRoom.currentNumber, activeRoom.status]);

  // Automatic Bingo check and claim
  useEffect(() => {
    if (activeRoom.status !== 'playing') return;
    if (penaltySeconds && penaltySeconds > 0) return;
    if (!activePlayer || !activePlayer.cards || activePlayer.cards.length === 0) return;

    let hasWinner = false;
    activePlayer.cards.forEach(card => {
      const check = verifyWinningPatterns(card, activeRoom.drawnNumbers);
      if (check.won) {
        hasWinner = true;
      }
    });

    if (hasWinner) {
      handleClaimBingo();
    }
  }, [activeRoom.drawnNumbers, activeRoom.status, activePlayer?.cards, penaltySeconds]);

  // --- MULTIPLAYER SOCKET EVENTS ---
  useEffect(() => {
    if (gameMode !== 'multi' || !socket) return;

    const handleChat = (msg: { sender: string; text: string; timestamp: number }) => {
      setChatLog(prev => [...prev, msg].slice(-40)); // keep last 40
      playCallBeep();
    };

    const handlePenalty = (data: { seconds: number }) => {
      setPenaltySeconds(data.seconds);
    };

    socket.on('chat:message', handleChat);
    socket.on('game:penalty', handlePenalty);

    return () => {
      socket.off('chat:message', handleChat);
      socket.off('game:penalty', handlePenalty);
    };
  }, [socket, soundEnabled, gameMode]);

  // --- SOLO MODE EVENT ENGINE ---

  // Ticks local lobby countdown for Solo Mode
  useEffect(() => {
    if (gameMode !== 'solo') return;

    let lobbyTimer: NodeJS.Timeout | null = null;

    if (localRoom.status === 'lobby') {
      lobbyTimer = setInterval(() => {
        setLocalRoom(prev => {
          if (prev.countdown <= 1) {
            const players = { ...prev.players };
            const me = players['me'];
            
            // If the player hasn't locked in their selection yet, keep them in the lobby
            if (me && !me.isReady) {
              addLocalChatMessage('System 🤖', me.cards.length === 0 ? 'Please select and buy at least 1 card to start!' : 'Please click "Buy" to confirm your card selection!');
              return {
                ...prev,
                countdown: 45
              };
            }

            if (lobbyTimer) clearInterval(lobbyTimer);

            // Always assign computer players' cards when game starts
            const comp1Cards = [12, 45].map(n => generateDeterministicBingoCard(n));
            const comp2Cards = [67].map(n => generateDeterministicBingoCard(n));
            const comp3Cards = [3, 29, 88].map(n => generateDeterministicBingoCard(n));

            // Setup comp1
            if (players['comp1']) {
              players['comp1'].cards = comp1Cards;
              players['comp1'].cardsPurchased = comp1Cards.length;
              players['comp1'].isReady = true;
            }
            // Setup comp2
            if (players['comp2']) {
              players['comp2'].cards = comp2Cards;
              players['comp2'].cardsPurchased = comp2Cards.length;
              players['comp2'].isReady = true;
            }
            // Setup comp3
            if (players['comp3']) {
              players['comp3'].cards = comp3Cards;
              players['comp3'].cardsPurchased = comp3Cards.length;
              players['comp3'].isReady = true;
            }

            return {
              ...prev,
              players,
              status: 'playing',
              countdown: 0
            };
          }
          return {
            ...prev,
            countdown: prev.countdown - 1
          };
        });
      }, 1000);
    }

    return () => {
      if (lobbyTimer) clearInterval(lobbyTimer);
    };
  }, [gameMode, localRoom.status]);

  // Handle solo ball caller & Computer Auto-Daubing
  useEffect(() => {
    if (gameMode !== 'solo' || localRoom.status !== 'playing') return;

    // Generate drawing pool
    const ballPool = Array.from({ length: 75 }, (_, i) => i + 1);
    for (let i = ballPool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [ballPool[i], ballPool[j]] = [ballPool[j], ballPool[i]];
    }

    let nextBallIdx = 0;
    let drawnList: number[] = [];

    const drawBall = () => {
      if (nextBallIdx >= 75) {
        setLocalRoom(prev => ({ ...prev, status: 'ended' }));
        addLocalChatMessage('System 🤖', 'All 75 balls drawn! The practice round is a DRAW.');
        scheduleSoloReset();
        return;
      }

      const ball = ballPool[nextBallIdx++];
      drawnList.push(ball);

      // Play ball draw sound
      soundManager.playBall(ball);

      setLocalRoom(prev => {
        const updatedDrawn = [...prev.drawnNumbers, ball];
        const updatedPlayers = { ...prev.players };

        // Automatically daub human player's ('me') cards when a ball is drawn
        const me = updatedPlayers['me'];
        if (me) {
          me.cards.forEach(card => {
            card.grid.forEach(row => {
              row.forEach(cell => {
                if (cell.value === ball) {
                  cell.daubed = true;
                }
              });
            });
          });
        }

        // Daub computer players cards
        ['comp1', 'comp2', 'comp3'].forEach(id => {
          const comp = updatedPlayers[id];
          if (!comp) return;

          comp.cards.forEach(card => {
            card.grid.forEach(row => {
              row.forEach(cell => {
                if (cell.value === ball) {
                  cell.daubed = true;
                }
              });
            });
          });
        });

        // Check ALL players (including human 'me' and computers) for winning patterns simultaneously
        const soloWinners: Array<{ player: Player; patterns: string[]; isHuman: boolean }> = [];

        // Check human player 'me'
        const humanPlayer = updatedPlayers['me'];
        if (humanPlayer && humanPlayer.cards && humanPlayer.cards.length > 0) {
          let won = false;
          const matchingPatterns: string[] = [];
          humanPlayer.cards.forEach(card => {
            const check = verifyWinningPatterns(card, updatedDrawn);
            if (check.won) {
              won = true;
              matchingPatterns.push(...check.patterns);
            }
          });
          if (won) {
            soloWinners.push({
              player: humanPlayer,
              patterns: Array.from(new Set(matchingPatterns)),
              isHuman: true
            });
          }
        }

        // Check computer players
        ['comp1', 'comp2', 'comp3'].forEach(id => {
          const comp = updatedPlayers[id];
          if (comp && comp.cards && comp.cards.length > 0) {
            let won = false;
            const matchingPatterns: string[] = [];
            comp.cards.forEach(card => {
              const check = verifyWinningPatterns(card, updatedDrawn);
              if (check.won) {
                won = true;
                matchingPatterns.push(...check.patterns);
              }
            });
            if (won) {
              soloWinners.push({
                player: comp,
                patterns: Array.from(new Set(matchingPatterns)),
                isHuman: false
              });
            }
          }
        });

        if (soloWinners.length > 0) {
          // One or more simultaneous winners!
          const totalCards = Object.values(updatedPlayers).reduce((acc: number, p: any) => acc + (p.cardsPurchased || 0), 0) as number;
          const commissionPerCard = Math.round(prev.cardPrice * 0.10);
          const prizePerCard = prev.cardPrice - commissionPerCard;
          const totalPrizePool = totalCards * prizePerCard;

          // Divide the prize pool equally among all simultaneous winners
          const count = soloWinners.length;
          const splitPrize = Math.floor(totalPrizePool / count);

          const winLogs: any[] = [];
          let isMeWinner = false;

          soloWinners.forEach(({ player, patterns, isHuman }) => {
            if (isHuman) {
              isMeWinner = true;
            }
            // Award split prize
            player.coins += splitPrize;

            winLogs.push({
              playerId: player.id,
              username: player.firstName,
              pattern: patterns.join(' & '),
              timestamp: Date.now(),
              prize: splitPrize
            });
          });

          // Play appropriate sound based on if the human won
          if (isMeWinner) {
            soundManager.playWin();
          } else {
            soundManager.playLoss();
          }

          if (onUpdateCoins && isMeWinner) {
            onUpdateCoins(updatedPlayers['me'].coins);
          }

          // Construct winner announcement chat message
          let announcement = '';
          if (count === 1) {
            const winner = soloWinners[0];
            announcement = `${winner.player.firstName} hit BINGO with [${winner.patterns.join(', ')}] and won ${splitPrize} Birr!`;
          } else {
            const names = soloWinners.map(w => w.player.firstName).join(', ');
            announcement = `🏆 Simultaneous Bingo Split! 🏆\n${names} hit BINGO on number ${ball} and split the ${totalPrizePool} Birr prize pool equally, winning ${splitPrize} Birr each!`;
          }

          addLocalChatMessage('👑 Winner 👑', announcement);
          recordGameplay(isMeWinner);
          scheduleSoloReset();

          return {
            ...prev,
            drawnNumbers: updatedDrawn,
            currentNumber: ball,
            status: 'ended',
            winners: winLogs,
            players: updatedPlayers
          };
        }

        return {
          ...prev,
          drawnNumbers: updatedDrawn,
          currentNumber: ball,
          players: updatedPlayers
        };
      });
    };

    // Draw first ball immediately
    drawBall();

    const ballTimer = setInterval(drawBall, 4000); // 4-second paced draw

    return () => {
      clearInterval(ballTimer);
    };
  }, [gameMode, localRoom.status]);

  const playCallBeep = () => {
    soundManager.playClick();
  };

  const addLocalChatMessage = (sender: string, text: string) => {
    setChatLog(prev => [...prev, { sender, text, timestamp: Date.now() }].slice(-40));
  };

  const scheduleSoloReset = () => {
    setTimeout(() => {
      setLocalRoom(prev => {
        const resetPlayers = { ...prev.players };
        resetPlayers['me'] = {
          ...resetPlayers['me'],
          isReady: false,
          cards: [],
          cardsPurchased: 0,
          freezeUntil: undefined
        };
        resetPlayers['comp1'] = {
          ...resetPlayers['comp1'],
          isReady: true,
          cards: [12, 45].map(n => generateDeterministicBingoCard(n)),
          cardsPurchased: 2,
          freezeUntil: undefined
        };
        resetPlayers['comp2'] = {
          ...resetPlayers['comp2'],
          isReady: true,
          cards: [67].map(n => generateDeterministicBingoCard(n)),
          cardsPurchased: 1,
          freezeUntil: undefined
        };
        resetPlayers['comp3'] = {
          ...resetPlayers['comp3'],
          isReady: true,
          cards: [3, 29, 88].map(n => generateDeterministicBingoCard(n)),
          cardsPurchased: 3,
          freezeUntil: undefined
        };

        return {
          ...prev,
          status: 'lobby',
          drawnNumbers: [],
          currentNumber: null,
          winners: [],
          countdown: 45,
          players: resetPlayers
        };
      });
      setChatLog([]);
    }, 10000);
  };

  // --- HANDLERS DISPATCHER ---

  const handleBuyTickets = (selectedCards: number[]) => {
    if (gameMode === 'solo') {
      const cost = selectedCards.length * localRoom.cardPrice;
      const commissionFee = Math.round(cost * 0.10);
      if (activePlayer && activePlayer.coins < cost) return;

      const userCards = selectedCards.map(n => generateDeterministicBingoCard(n));

      setLocalRoom(prev => {
        const players = { ...prev.players };
        // Me
        players['me'] = {
          ...players['me'],
          coins: players['me'].coins - cost,
          cards: userCards,
          isReady: true,
          cardsPurchased: selectedCards.length
        };

        if (onUpdateCoins) {
          onUpdateCoins(players['me'].coins);
        }

        return {
          ...prev,
          players
        };
      });

      addLocalChatMessage('System 🤖', `Tickets confirmed! Stakes of ${cost} Birr deducted (includes 10% commission cut of ${commissionFee} Birr). Waiting for countdown to end...`);
    } else {
      // Multiplayer Room buy tickets (sends card array to server)
      if (socket) {
        socket.emit('room:buy_cards', selectedCards);
      }
    }
  };

  const handleDaub = (cardId: string, rIdx: number, cIdx: number) => {
    if (penaltySeconds && penaltySeconds > 0) return;

    if (gameMode === 'solo') {
      setLocalRoom(prev => {
        const players = { ...prev.players };
        const me = players['me'];
        if (me) {
          const card = me.cards.find(c => c.id === cardId);
          if (card) {
            const cell = card.grid[rIdx][cIdx];
            if (cell.value !== 'FREE') {
              // Only allow touching if the number has already been drawn/called
              if (!prev.drawnNumbers.includes(cell.value as number)) {
                return prev;
              }
              cell.daubed = !cell.daubed;
            }
          }
        }
        return { ...prev, players };
      });
    } else {
      if (socket) {
        // Only allow touching if the number has already been drawn/called
        const me = activeRoom.players[currentPlayer?.username || ''];
        if (me) {
          const card = me.cards.find(c => c.id === cardId);
          if (card) {
            const cell = card.grid[rIdx][cIdx];
            if (cell.value !== 'FREE' && !activeRoom.drawnNumbers.includes(cell.value as number)) {
              return; // Ignore touch
            }
          }
        }
        socket.emit('game:daub', { cardId, rowIndex: rIdx, colIndex: cIdx });
      }
    }
  };

  const handleClaimBingo = () => {
    const currentStatus = gameMode === 'solo' ? localRoom.status : activeRoom.status;
    if (currentStatus !== 'playing') return;
    if (penaltySeconds && penaltySeconds > 0) return;

    if (gameMode === 'solo') {
      const me = localRoom.players['me'];
      if (!me || me.cards.length === 0) return;

      let won = false;
      const wonPatterns: string[] = [];

      me.cards.forEach(card => {
        const check = verifyWinningPatterns(card, localRoom.drawnNumbers);
        if (check.won) {
          won = true;
          wonPatterns.push(...check.patterns);
        }
      });

      if (won) {
        const finalPatterns = Array.from(new Set(wonPatterns));
        const totalCards = Object.values(localRoom.players).reduce((acc: number, p: any) => acc + (p.cardsPurchased || 0), 0) as number;
        const commissionPerCard = Math.round(localRoom.cardPrice * 0.10);
        const prizePerCard = localRoom.cardPrice - commissionPerCard;
        const prize = totalCards * prizePerCard;

        setLocalRoom(prev => {
          const players = { ...prev.players };
          players['me'].coins += prize;

          if (onUpdateCoins) {
            onUpdateCoins(players['me'].coins);
          }

          const winLog = {
            playerId: 'me',
            username: players['me'].firstName,
            pattern: finalPatterns.join(' & '),
            timestamp: Date.now(),
            prize: prize
          };

          return {
            ...prev,
            status: 'ended',
            winners: [winLog],
            players
          };
        });

        soundManager.playWin();
        addLocalChatMessage('🏆 YEGNA BINGO 🏆', `Outstanding! You hit BINGO with [${finalPatterns.join(', ')}] and won ${prize} Birr!`);
        recordGameplay(true);
        scheduleSoloReset();
      } else {
        // Penalty for False claim
        soundManager.playPenalty();
        setPenaltySeconds(10);
        addLocalChatMessage('System 🤖', 'FALSE BINGO! Your cards are frozen for 10 seconds.');
      }
    } else {
      if (socket) {
        socket.emit('game:claim_bingo');
      }
    }
  };

  const handleSendChat = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatMessage.trim()) return;

    if (gameMode === 'solo') {
      addLocalChatMessage(activePlayer?.firstName || 'Anonymous', chatMessage.trim());
      setChatMessage('');

      // Auto reply simulation after 1.5 seconds from a random bot
      setTimeout(() => {
        const botReplies = [
          'Nice! Keep going!',
          'Where is B-12? 😂',
          'Let’s get this card marked!',
          'I am so close to a diagonal line',
          'Good luck everyone!'
        ];
        const randomBot = ['Abebe', 'Kebede', 'Chala'][Math.floor(Math.random() * 3)];
        const randomMsg = botReplies[Math.floor(Math.random() * botReplies.length)];
        addLocalChatMessage(randomBot, randomMsg);
      }, 1500);
    } else {
      if (socket) {
        socket.emit('chat:send', chatMessage.trim());
        setChatMessage('');
      }
    }
  };

  const sendQuickReaction = (text: string) => {
    if (gameMode === 'solo') {
      addLocalChatMessage(activePlayer?.firstName || 'Anonymous', text);
    } else {
      if (socket) {
        socket.emit('chat:send', text);
      }
    }
  };

  const handleSkipCountdown = () => {
    if (gameMode !== 'solo') return;
    setLocalRoom(prev => ({
      ...prev,
      status: 'playing',
      countdown: 0
    }));
    addLocalChatMessage('System 🤖', 'Practice round countdown skipped! Game started.');
  };

  const getBallPrefix = (num: number) => {
    if (num >= 1 && num <= 15) return 'B';
    if (num >= 16 && num <= 30) return 'I';
    if (num >= 31 && num <= 45) return 'N';
    if (num >= 46 && num <= 60) return 'G';
    if (num >= 61 && num <= 75) return 'O';
    return '';
  };

  const getBallColor = (num: number) => {
    if (num >= 1 && num <= 15) return 'bg-rose-500 border-rose-600';
    if (num >= 16 && num <= 30) return 'bg-amber-500 border-amber-600';
    if (num >= 31 && num <= 45) return 'bg-indigo-500 border-indigo-600';
    if (num >= 46 && num <= 60) return 'bg-emerald-500 border-emerald-600';
    if (num >= 61 && num <= 75) return 'bg-pink-500 border-pink-600';
    return 'bg-slate-600';
  };

  // Find all card numbers already purchased in this room by OTHER players
  const takenCards = (Object.values(activeRoom.players) as Player[])
    .filter(p => p.id !== activePlayer?.id)
    .flatMap(p => 
      p.cards.map(c => {
        const match = c.id.match(/^CARD-(\d+)$/);
        return match ? parseInt(match[1], 10) : null;
      })
    ).filter((val): val is number => val !== null);

  return (
    <div className={`${activeRoom.status === 'playing' ? 'space-y-2' : 'space-y-6'} animate-fade-in text-slate-100`} id="game_view_main">
      {/* Top Hall Header Banner */}
      {activeRoom.status !== 'playing' && (
        <div className="flex items-center justify-between p-4 bg-slate-900 text-white rounded-2xl shadow-xl border border-slate-800">
          <div className="space-y-0.5">
            <span className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-400">
              {gameMode === 'solo' ? '👤 Solo Practice Mode' : '👥 Multiplayer Arena'}
            </span>
            <h2 className="text-base font-black text-slate-100">{activeRoom.name}</h2>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={handleToggleLocalSound}
              className="p-2 text-slate-300 hover:text-white rounded-xl bg-slate-950/80 border border-slate-800 transition-colors"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-indigo-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>
            <button 
              onClick={onLeaveRoom}
              className="px-3.5 py-1.5 text-xs bg-red-950/80 border border-red-800 text-red-200 font-extrabold rounded-xl transition-all"
            >
              Leave
            </button>
          </div>
        </div>
      )}

      {/* Lobby Phase Controls - Visual 1-90 Card Selection */}
      {activeRoom.status === 'lobby' && (
        <CardSelector 
          cardPrice={activeRoom.cardPrice} 
          playerCoins={activePlayer ? activePlayer.coins : 0}
          onConfirmSelection={handleBuyTickets}
          onBack={onLeaveRoom}
          takenCards={takenCards}
          lobbyCountdown={activeRoom.countdown}
          players={activeRoom.players}
          onSelectCardsChange={(selectedCards) => {
            if (gameMode === 'solo') {
              // Update local state with selected cards in real-time
              const userCards = selectedCards.map(n => generateDeterministicBingoCard(n));
              setLocalRoom(prev => {
                const players = { ...prev.players };
                if (players['me']) {
                  players['me'].cards = userCards;
                  players['me'].cardsPurchased = selectedCards.length;
                }
                return {
                  ...prev,
                  players
                };
              });
            } else {
              // Emit selected cards to the server in real-time
              if (socket) {
                socket.emit('room:select_cards', selectedCards);
              }
            }
          }}
        />
      )}

      {/* Countdown Phase Banner */}
      {activeRoom.status === 'countdown' && (
        <div className="bg-indigo-950/20 border border-indigo-900 rounded-2xl p-8 text-center space-y-5 animate-pulse">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-500 text-white shadow-lg shadow-indigo-500/20">
            <Timer className="w-8 h-8 animate-spin" />
          </div>
          <div className="space-y-1">
            <h3 className="text-xl font-black text-slate-100 uppercase tracking-wide">Locked & Starting!</h3>
            <p className="text-xs text-indigo-400 font-medium">
              Generating valid Bingo cards on the server. Get ready!
            </p>
          </div>
          <div className="text-5xl font-black text-indigo-300 font-mono tracking-wider">
            {activeRoom.countdown}s
          </div>

          {gameMode === 'solo' && (
            <button
              onClick={handleSkipCountdown}
              className="py-2.5 px-5 bg-indigo-500 hover:bg-indigo-400 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all shadow-md mt-2"
            >
              🚀 Skip Countdown (Fast Start)
            </button>
          )}
        </div>
      )}

      {/* Active Playing Game Phase */}
      {activeRoom.status === 'playing' && (
        <div className="space-y-2 animate-fade-in text-slate-100 flex flex-col justify-between max-h-[82vh]" id="active_play_phase">
          {/* Habesha Custom Header Bar */}
          <div className="flex items-center justify-between px-3 py-2 bg-slate-950/40 rounded-xl border border-slate-850/60 text-slate-100" id="gameplay_header">
            <button 
              onClick={onLeaveRoom} 
              className="p-1 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5 text-slate-400" />
            </button>
            <div className="flex items-center gap-2 font-black text-xs sm:text-sm tracking-wider uppercase">
              <YegnaLogo size={28} className="flex-shrink-0" />
              <span>YEGNA BINGO / የኛ ቢንጎ 🎱</span>
              <span className="text-slate-500 text-[10px]">▼</span>
            </div>
            <button className="p-1 text-slate-400 hover:text-white transition-colors">
              <div className="flex flex-col gap-0.5 items-center justify-center w-5 h-5">
                <span className="w-1 h-1 bg-slate-400 rounded-full"></span>
                <span className="w-1 h-1 bg-slate-400 rounded-full"></span>
                <span className="w-1 h-1 bg-slate-400 rounded-full"></span>
              </div>
            </button>
          </div>

          {/* Habesha Style Premium Header Stats badges */}
          <div className="grid grid-cols-4 gap-1.5" id="habesha_header_stats">
            {/* Slot 1: Round ID */}
            <div className="bg-slate-950/80 border border-slate-850/80 p-1.5 sm:p-2 rounded-xl text-center flex flex-col justify-center min-w-0">
              <span className="text-[7px] sm:text-[9px] text-slate-500 font-extrabold uppercase tracking-tight block truncate">#HC (Round)</span>
              <span className="text-xs font-black text-slate-200 mt-0.5 font-mono truncate">#{activeRoom.id.replace('room_', 'R')}</span>
            </div>

            {/* Slot 2: Card Price / Stake */}
            <div className="bg-slate-950/80 border border-slate-850/80 p-1.5 sm:p-2 rounded-xl text-center flex flex-col justify-center min-w-0">
              <span className="text-[7px] sm:text-[9px] text-slate-500 font-extrabold uppercase tracking-tight block truncate">መጫረቻ</span>
              <span className="text-xs font-black text-slate-200 mt-0.5 font-mono truncate">{activeRoom.cardPrice.toFixed(2)}</span>
            </div>

            {/* Slot 3: Premium Prize (High Contrast Cyan Badge as in screenshot) */}
            <div className="bg-cyan-950/10 border border-cyan-500 p-1.5 sm:p-2 rounded-xl text-center flex flex-col justify-center ring-1 ring-cyan-500/20 shadow-[0_0_10px_rgba(6,182,212,0.15)] min-w-0">
              <span className="text-[7px] sm:text-[9px] text-cyan-400 font-extrabold uppercase tracking-tight block truncate">ሽልማት (Prize)</span>
              <span className="text-xs font-black text-cyan-400 mt-0.5 font-mono truncate">
                {currentPrizePoolAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            {/* Slot 4: Balls Count */}
            <div className="bg-slate-950/80 border border-slate-850/80 p-1.5 sm:p-2 rounded-xl text-center flex flex-col justify-center min-w-0">
              <span className="text-[7px] sm:text-[9px] text-slate-500 font-extrabold uppercase tracking-tight block truncate">እጣ (Balls)</span>
              <span className="text-xs font-black text-slate-200 mt-0.5 font-mono truncate">{activeRoom.drawnNumbers.length}/75</span>
            </div>
          </div>

          {/* Horizontal Called Balls History Drawer (Circular green outlines as in screenshot) */}
          <div className="bg-slate-955/40 border border-slate-900/60 p-1.5 rounded-xl">
            <div className="flex gap-1.5 overflow-x-auto pb-0.5 pt-0.5 px-1 scrollbar-none justify-center">
              {activeRoom.drawnNumbers.slice().reverse().slice(0, 10).map((num, idx) => (
                <div 
                  key={idx} 
                  className={`flex-shrink-0 w-8 h-8 rounded-full border border-emerald-500 text-[10px] font-black flex flex-col items-center justify-center transition-all bg-slate-950 ${
                    idx === 0 
                      ? 'bg-yellow-500/15 text-yellow-400 border-yellow-400 scale-105 shadow-[0_0_8px_rgba(234,179,8,0.4)]'
                      : 'text-emerald-400'
                  }`}
                >
                  <span className={`text-[7px] leading-none uppercase ${idx === 0 ? 'text-yellow-400 font-bold' : 'text-slate-450'}`}>{getBallPrefix(num)}-{num}</span>
                </div>
              ))}
              {activeRoom.drawnNumbers.length === 0 && (
                <span className="text-[10px] text-slate-600 italic py-1">Cage warming up...</span>
              )}
            </div>
          </div>

          {/* Split Multi-Column Grid Dashboard */}
          <div className="grid grid-cols-12 gap-2 flex-1 min-h-0" id="gameplay_dashboard_columns">
            
            {/* Left Column: 75-Ball Master Grid Board (col-span-7) */}
            <div className="col-span-7 bg-slate-900/40 border border-slate-850 p-1.5 sm:p-2.5 rounded-xl flex flex-col justify-between min-h-0" id="master_75_board">
              <div className="flex flex-col gap-1 h-full justify-between">
                {/* Column Headers B I N G O */}
                <div className="grid grid-cols-5 text-center gap-[2px] mb-0.5">
                  {['B', 'I', 'N', 'G', 'O'].map((letter, idx) => (
                    <div 
                      key={idx} 
                      className={`py-0.5 rounded font-black text-[11px] sm:text-xs ${
                        idx === 0 ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                        idx === 1 ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' :
                        idx === 2 ? 'bg-fuchsia-500/10 text-fuchsia-400 border border-fuchsia-500/20' :
                        idx === 3 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        'bg-orange-500/10 text-orange-400 border border-orange-500/20'
                      }`}
                    >
                      {letter}
                    </div>
                  ))}
                </div>

                {/* 15 Rows of 5 Columns */}
                <div className="grid grid-cols-5 gap-[2px] h-full" id="master_board_body">
                  {Array.from({ length: 15 }).map((_, rowIdx) => {
                    return ['B', 'I', 'N', 'G', 'O'].map((colLetter, colIdx) => {
                      const num = rowIdx + 1 + (colIdx * 15);
                      const isDrawn = activeRoom.drawnNumbers.includes(num);
                      const isCurrent = activeRoom.currentNumber === num;

                      // Color scheme according to column from the screenshot
                      const getColumnColorClass = () => {
                        if (isCurrent) {
                          return 'border-2 border-yellow-400 bg-yellow-400/20 text-yellow-300 font-black shadow-[0_0_12px_rgba(234,179,8,0.85)] z-10 scale-105 animate-pulse';
                        }
                        if (isDrawn) {
                          switch (colIdx) {
                            case 0: return 'bg-blue-500/20 border border-blue-500/50 text-blue-300 font-black';
                            case 1: return 'bg-indigo-500/20 border border-indigo-500/50 text-indigo-300 font-black';
                            case 2: return 'bg-fuchsia-500/20 border border-fuchsia-500/50 text-fuchsia-300 font-black';
                            case 3: return 'bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 font-black';
                            case 4: return 'bg-orange-500/20 border border-orange-500/50 text-orange-300 font-black';
                            default: return 'bg-slate-500/20 border border-slate-500/50 text-slate-300 font-black';
                          }
                        }
                        
                        switch (colIdx) {
                          case 0: return 'text-blue-500'; // B is blue
                          case 1: return 'text-indigo-400'; // I is purple/indigo
                          case 2: return 'text-fuchsia-400'; // N is pink/magenta
                          case 3: return 'text-emerald-500'; // G is green
                          case 4: return 'text-orange-500'; // O is orange
                          default: return 'text-slate-600';
                        }
                      };

                      return (
                        <div
                          key={`${rowIdx}-${colIdx}`}
                          className={`h-4.5 sm:h-5.5 rounded flex items-center justify-center font-mono font-bold text-[9px] sm:text-[11px] select-none bg-slate-950/60 border border-slate-900/40 transition-all ${getColumnColorClass()}`}
                        >
                          <span>{num}</span>
                        </div>
                      );
                    });
                  })}
                </div>
              </div>
            </div>

            {/* Right Column: Caller visual, My Ticket, Jackpot badge (col-span-5) */}
            <div className="col-span-5 flex flex-col gap-1.5 min-h-0" id="gameplay_player_desk">
              
              {/* Top Row: Current Called Ball Visualizer Circle & Controls */}
              <div className="bg-slate-900/40 border border-slate-850 p-1.5 rounded-xl flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {activeRoom.currentNumber ? (
                    <div className="relative">
                      <div className="absolute inset-0 rounded-full bg-yellow-500/30 animate-ping"></div>
                      <div className="w-10 h-10 rounded-full border border-yellow-400 bg-yellow-400 text-slate-950 flex items-center justify-center font-black text-[11px] sm:text-xs shadow-[0_0_10px_rgba(234,179,8,0.4)]">
                        <span>{getBallPrefix(activeRoom.currentNumber)}-{activeRoom.currentNumber}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-full border border-dashed border-slate-800 bg-slate-950 flex items-center justify-center text-slate-600 font-bold text-[8px] sm:text-[10px]">
                      WAITING
                    </div>
                  )}
                  <div className="space-y-0.5">
                    <h4 className="text-[7px] sm:text-[8px] font-extrabold uppercase text-slate-500 tracking-wider">ተረኛ ቁጥር</h4>
                    <p className="text-[10px] sm:text-xs font-black text-yellow-400">
                      {activeRoom.currentNumber 
                        ? `${getBallPrefix(activeRoom.currentNumber)}-${activeRoom.currentNumber}` 
                        : 'ወረፋ...'
                      }
                    </p>
                  </div>
                </div>

                {/* Control buttons stack */}
                <div className="flex flex-col gap-1">
                  <button 
                    onClick={handleToggleLocalSound}
                    className="p-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-emerald-400 transition-colors flex items-center justify-center w-6 h-6"
                    title="Toggle Sound"
                  >
                    {soundEnabled ? <Volume2 className="w-3 h-3 text-emerald-400" /> : <VolumeX className="w-3 h-3 text-slate-500" />}
                  </button>
                  <button 
                    onClick={handleClaimBingo}
                    disabled={(penaltySeconds !== null && penaltySeconds > 0) || !activePlayer || !activePlayer.cards || activePlayer.cards.length === 0}
                    className="p-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white transition-all flex items-center justify-center w-6 h-6 shadow-[0_0_8px_rgba(239,68,68,0.3)] active:scale-95 disabled:opacity-50"
                    title={activePlayer && activePlayer.cards && activePlayer.cards.length > 0 ? "Claim Bingo" : "Spectator Mode"}
                  >
                    <span>🎯</span>
                  </button>
                </div>
              </div>

              {/* Middle Row: Active Ticket 5x5 card paper */}
              <div className="bg-slate-900/60 border border-slate-850 p-2 rounded-xl flex-1 flex flex-col justify-between min-h-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[9px] sm:text-xs font-black uppercase text-emerald-400">
                    {activePlayer && activePlayer.cards && activePlayer.cards.length >= 2 
                      ? 'የእኔ ካርታዎች (My Tickets - Showing All)' 
                      : activePlayer && activePlayer.cards && activePlayer.cards.length === 1 
                      ? 'የእኔ ካርታ (My Ticket)'
                      : 'የተመልካች ሰሌዳ (Spectator Panel)'}
                  </span>
                </div>

                {/* Ticket grid(s) */}
                {activePlayer && activePlayer.cards && activePlayer.cards.length > 0 ? (
                  <div className="relative flex-1 flex flex-col justify-center min-h-0" id="ticket_grid_wrapper">
                    {/* Visual Freeze Penalty Overlay */}
                    {penaltySeconds !== null && penaltySeconds > 0 && (
                      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-[1px] rounded-xl z-20 flex flex-col items-center justify-center text-white p-2">
                        <span className="text-xs font-black text-red-400 font-mono">
                          Frozen {penaltySeconds}s
                        </span>
                      </div>
                    )}

                    {activePlayer.cards.length >= 2 ? (
                      /* Show all cards in a grid layout */
                      <div className="grid grid-cols-2 gap-1.5 w-full h-full overflow-y-auto max-h-[38vh] scrollbar-none" id="multi_cards_grid">
                        {activePlayer.cards.map((card, cardIdx) => (
                          <div key={card.id} className="bg-slate-950/70 border border-slate-850/80 p-1 rounded-lg flex flex-col justify-between">
                            <div className="flex justify-between items-center text-[7px] font-mono font-bold text-slate-500 mb-0.5">
                              <span>CARD #{cardIdx + 1}</span>
                              <span>ID: #{card.id}</span>
                            </div>
                            <div className="grid grid-cols-5 gap-[1px]" id={`ticket_grid_${card.id}`}>
                              {card.grid.map((row, rIdx) => 
                                row.map((cell, cIdx) => {
                                  const isFree = cell.value === 'FREE';
                                  const isDrawn = !isFree && activeRoom.drawnNumbers.includes(cell.value as number);
                                  const isHighlight = isDrawn && !cell.daubed;

                                  return (
                                    <button
                                      key={`${rIdx}-${cIdx}`}
                                      disabled={isFree || (penaltySeconds !== null && penaltySeconds > 0)}
                                      onClick={() => handleDaub(card.id, rIdx, cIdx)}
                                      className={`aspect-square rounded-[3px] border flex flex-col items-center justify-center relative font-mono font-bold select-none transition-all text-[8px] sm:text-[9px] ${
                                        isFree
                                          ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400 cursor-default'
                                          : cell.daubed
                                          ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-black cursor-pointer'
                                          : isHighlight
                                          ? 'bg-amber-500/20 border-amber-500 text-slate-100 animate-pulse font-extrabold cursor-pointer hover:bg-amber-500/30'
                                          : isDrawn
                                          ? 'bg-slate-950 border-slate-850 text-slate-300 hover:bg-slate-900 cursor-pointer'
                                          : 'bg-slate-950/40 border-slate-900/60 text-slate-600 cursor-not-allowed'
                                      }`}
                                    >
                                      {isFree ? (
                                        <span className="text-[4px] uppercase tracking-wider font-extrabold text-indigo-400 scale-[0.8]">FREE</span>
                                      ) : (
                                        <span className="leading-none">{cell.value}</span>
                                      )}
                                    </button>
                                  );
                                })
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      /* Show single card full size layout as before */
                      <>
                        <div className="grid grid-cols-5 gap-0.5 sm:gap-1" id="ticket_grid">
                          {activePlayer.cards[activeCardIndex]?.grid.map((row, rIdx) => 
                            row.map((cell, cIdx) => {
                              const isFree = cell.value === 'FREE';
                              const isDrawn = !isFree && activeRoom.drawnNumbers.includes(cell.value as number);
                              const isHighlight = isDrawn && !cell.daubed;

                              return (
                                <button
                                  key={`${rIdx}-${cIdx}`}
                                  disabled={isFree || (penaltySeconds !== null && penaltySeconds > 0)}
                                  onClick={() => handleDaub(activePlayer.cards[activeCardIndex].id, rIdx, cIdx)}
                                  className={`aspect-square rounded border flex flex-col items-center justify-center relative font-mono font-bold select-none transition-all text-[10px] sm:text-xs ${
                                    isFree
                                      ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400 cursor-default'
                                      : cell.daubed
                                      ? 'bg-emerald-500 border-emerald-400 text-slate-950 font-black cursor-pointer'
                                      : isHighlight
                                      ? 'bg-amber-500/20 border-amber-500 text-slate-100 animate-pulse font-extrabold cursor-pointer hover:bg-amber-500/30'
                                      : isDrawn
                                      ? 'bg-slate-950 border-slate-850 text-slate-300 hover:bg-slate-900 cursor-pointer'
                                      : 'bg-slate-950/40 border-slate-900/60 text-slate-600 cursor-not-allowed'
                                  }`}
                                >
                                  {isFree ? (
                                    <span className="text-[6px] uppercase tracking-wider font-extrabold text-indigo-400">FREE</span>
                                  ) : (
                                    <span className="leading-none">{cell.value}</span>
                                  )}
                                </button>
                              );
                            })
                          )}
                        </div>
                        <div className="text-center text-[7px] text-slate-500 font-bold font-mono mt-1">
                          CARD ID: #{activePlayer.cards[activeCardIndex]?.id}
                        </div>
                      </>
                    )}
                  </div>
                ) : (
                  <div className="p-3 sm:p-4 text-center bg-slate-950/70 border border-slate-850 rounded-xl space-y-3.5 flex flex-col items-center justify-center flex-1 min-h-[180px]" id="spectator_info_view">
                    <div className="w-10 h-10 rounded-full bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 animate-pulse">
                      <Users className="w-5 h-5" />
                    </div>
                    <div className="space-y-1 max-w-[210px]">
                      <span className="inline-block px-2 py-0.5 text-[8px] sm:text-[9px] uppercase font-black tracking-wider bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 rounded-full animate-pulse">
                        👀 ተመልካች (Spectator Mode)
                      </span>
                      <h4 className="text-[11px] sm:text-xs font-black text-slate-200">
                        የጀመረው ጨዋታ እስኪያልቅ እየታዘቡ ነው
                      </h4>
                      <p className="text-[9px] sm:text-[10px] text-slate-400 leading-relaxed font-medium">
                        የጀመረው ጨዋታ ሲያልቅ ቀጣዩን ዙር ቲኬት በመግዛት መጫወት ይችላሉ። እስከዛ ግን ሌሎች የሚጫወቱትን በቀጥታ ይመልከቱ።
                      </p>
                      <p className="text-[8px] text-slate-500 italic font-bold">
                        (Current game is in progress. You are spectating and will join the next round!)
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Row: Circular Neon Live Jackpot Ring */}
              <div className="flex flex-col items-center justify-center pt-1" id="live_jackpot_card">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-cyan-500 flex flex-col items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.3)] bg-slate-950">
                  <span className="text-[7px] sm:text-[8px] font-extrabold uppercase text-rose-500 flex items-center gap-0.5 tracking-wider leading-none mb-0.5">
                    <span className="inline-block w-1 h-1 rounded-full bg-rose-500 animate-ping"></span>
                    LIVE
                  </span>
                  <span className="text-[7px] sm:text-[8px] font-black uppercase text-slate-400 tracking-wider">ድራፍት</span>
                  <span className="text-[10px] sm:text-xs font-black text-cyan-400 font-mono tracking-tight leading-none mt-0.5">
                    {currentPrizePoolAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className="text-[6px] sm:text-[7px] font-extrabold text-slate-500 uppercase tracking-widest mt-0.5">ETB</span>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* Ended Results Phase Screen */}
      {activeRoom.status === 'ended' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-6 space-y-6 animate-fade-in" id="ended_phase">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-14 h-14 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-2xl mb-1">
              <Trophy className="w-8 h-8 animate-bounce text-indigo-400" />
            </div>
            <h3 className="text-xl font-black text-slate-100 uppercase tracking-wide">Round Completed!</h3>
            <p className="text-xs text-slate-400">
              The round ended. Final winning receipts verified by server.
            </p>
          </div>

          <div className="space-y-4" id="winners_leaderboard">
            <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-widest">Winners List</h4>
            
            {activeRoom.winners && activeRoom.winners.length > 0 ? (
              <div className="space-y-2">
                {activeRoom.winners.map((winner, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-center justify-between p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl"
                  >
                    <div className="flex items-center gap-3">
                      <span>🥇</span>
                      <div className="space-y-0.5">
                        <span className="text-sm font-black text-slate-100">{winner.username}</span>
                        <span className="block text-[10px] text-indigo-400 font-extrabold uppercase tracking-wider">
                          Pattern: {winner.pattern}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="block text-sm font-black text-indigo-300">
                        +{winner.prize || currentPrizePoolAmount} Birr
                      </span>
                      <span className="text-[9px] text-slate-500 font-mono">
                        {new Date(winner.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 bg-slate-950 border border-slate-850 text-slate-500 rounded-xl text-center text-xs">
                No winners this round. Let's start the next one!
              </div>
            )}
          </div>

          <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl text-center space-y-1">
            <span className="text-xs text-slate-500 font-extrabold uppercase tracking-wider">New Game Starting In</span>
            <div className="text-xl font-black text-slate-200 font-mono animate-pulse">
              Lobby resetting soon...
            </div>
          </div>
        </div>
      )}

      {/* Celebratory Winner Modal Overlay */}
      {activeRoom.status === 'ended' && isMeWinner && (
        <div className="fixed inset-0 bg-slate-950/95 z-50 flex flex-col items-center justify-center p-6 text-center space-y-4 animate-fade-in" id="winner_popup_overlay">
          <div className="relative">
            <Trophy className="w-20 h-20 text-yellow-400 animate-bounce mx-auto filter drop-shadow-[0_0_15px_rgba(250,204,21,0.6)]" />
            <Sparkles className="w-8 h-8 text-amber-300 absolute -top-2 -right-2 animate-pulse" />
          </div>
          <h2 className="text-3xl font-black text-amber-300 tracking-wider uppercase animate-pulse">
            🏆 BINGO WINNER! 🏆
          </h2>
          <p className="text-sm text-slate-300 max-w-xs">
            እንኳን ደስ አሎት! You hit the winning pattern and claimed the jackpot prize!
          </p>
          <div className="bg-amber-500/10 border-2 border-amber-500/30 px-6 py-3 rounded-2xl">
            <span className="block text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">Winnings Awarded</span>
            <span className="text-2xl font-black text-amber-400 font-mono">+{activeRoom.winners?.find(w => w.playerId === (gameMode === 'solo' ? 'me' : (socket?.id || '')))?.prize || currentPrizePoolAmount} Birr</span>
          </div>
          <div className="text-[10px] text-slate-500 font-bold font-mono">
            New round starts in a few seconds...
          </div>
        </div>
      )}

    </div>
  );
}
