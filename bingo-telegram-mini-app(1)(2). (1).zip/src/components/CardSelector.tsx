/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ArrowLeft, Check, Play, Hourglass, ShieldAlert, Sparkles, X } from 'lucide-react';
import { generateDeterministicBingoCard } from '../utils';
import { YegnaLogo } from './YegnaLogo';

interface CardSelectorProps {
  cardPrice: number;
  playerCoins: number;
  onConfirmSelection: (selectedCards: number[]) => void;
  onBack?: () => void;
  takenCards?: number[];
  lobbyCountdown?: number; // Optional countdown passed from room
  onSelectCardsChange?: (selectedCards: number[]) => void;
  players?: any; // Live players directory from the room
}

export default function CardSelector({ 
  cardPrice, 
  playerCoins, 
  onConfirmSelection, 
  onBack,
  takenCards = [],
  lobbyCountdown = 6,
  onSelectCardsChange,
  players = {}
}: CardSelectorProps) {
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [previewCardNum, setPreviewCardNum] = useState<number>(22); // Default preview to #22 like screenshot!
  const [language, setLanguage] = useState<'AM' | 'EN'>('AM');

  const onSelectCardsChangeRef = React.useRef(onSelectCardsChange);
  useEffect(() => {
    onSelectCardsChangeRef.current = onSelectCardsChange;
  }, [onSelectCardsChange]);

  useEffect(() => {
    if (onSelectCardsChangeRef.current) {
      onSelectCardsChangeRef.current(selectedCards);
    }
  }, [selectedCards]);

  const toggleCardSelection = (num: number) => {
    if (takenCards.includes(num)) return;
    setPreviewCardNum(num);
    if (selectedCards.includes(num)) {
      setSelectedCards(prev => prev.filter(c => c !== num));
    } else {
      if (selectedCards.length >= 4) {
        // Limit to 4 cards max
        return;
      }
      setSelectedCards(prev => [...prev, num]);
    }
  };

  const handleConfirm = () => {
    if (selectedCards.length === 0) return;
    onConfirmSelection(selectedCards);
  };

  const totalCost = selectedCards.length * cardPrice;
  const commissionFee = Math.round(totalCost * 0.10);
  const netStake = totalCost - commissionFee;
  const canAfford = playerCoins >= totalCost;

  // Generate deterministic grid preview
  const previewCard = generateDeterministicBingoCard(previewCardNum);

  // Amharic and English translation tables
  const dict = {
    AM: {
      title: 'የኛ ቢንጎ 🎱',
      playWallet: 'PLAY WALLET',
      mainWallet: 'MAIN WALLET',
      branding: 'የኛ ቢንጎ',
      brandingSub: 'YEGNA BINGO',
      gameStarting: 'ጨዋታው ሊጀምር ነው',
      draft: 'ድራፍት',
      bonusSoon: 'የደረሱዎት ቦነስ በቅርቡ ይመጣሉ',
      selectCard: 'ካርታ ይምረጡ',
      selectedText: 'የመረጧቸው ካርታዎች',
      confirmBuy: 'ይግዙ',
      insufficient: 'በቂ ሳንቲም የለም',
      back: 'ተመለስ',
      free: 'ነጻ',
      sold: 'የተሸጠ',
    },
    EN: {
      title: 'YEGNA BINGO 🎱',
      playWallet: 'PLAY WALLET',
      mainWallet: 'MAIN WALLET',
      branding: 'YEGNA BINGO',
      brandingSub: 'ETHIOPIA\'S PREMIER BINGO',
      gameStarting: 'Game Starting',
      draft: 'Jackpot Draft',
      bonusSoon: 'Bonuses Arriving Soon',
      selectCard: 'Select Card',
      selectedText: 'Selected Cards',
      confirmBuy: 'Confirm & Buy',
      insufficient: 'Insufficient Coins',
      back: 'Back',
      free: 'Free',
      sold: 'Sold',
    }
  };

  const t = dict[language];

  // Formatting countdown like 00:36
  const formatCountdown = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4 animate-fade-in bg-[#080b11] p-4 sm:p-5 rounded-2xl border border-slate-900 shadow-2xl max-w-lg mx-auto text-slate-100" id="habesha_lobby_view">
      
      {/* 1. Habesha Custom Header Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-950/40 rounded-xl border border-slate-850/60 text-slate-100" id="lobby_header">
        <button 
          onClick={onBack} 
          className="p-1 text-slate-400 hover:text-white transition-colors"
          title={t.back}
        >
          <X className="w-5 h-5 text-slate-400" />
        </button>
        <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm tracking-wider uppercase">
          <span>{t.branding} 🎱</span>
          <span className="text-slate-500 text-[10px]">▼</span>
        </div>
        
        {/* Language Toggle Selector */}
        <div className="flex items-center bg-slate-900/90 border border-emerald-500/40 rounded-full p-0.5" id="language_toggle">
          <button
            onClick={() => setLanguage('AM')}
            className={`px-2 py-0.5 rounded-full text-[9px] font-black transition-all ${
              language === 'AM'
                ? 'bg-emerald-500 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            AM
          </button>
          <button
            onClick={() => setLanguage('EN')}
            className={`px-2 py-0.5 rounded-full text-[9px] font-black transition-all ${
              language === 'EN'
                ? 'bg-emerald-500 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            EN
          </button>
        </div>
      </div>

      {/* 2. User Profile and Stacked Wallet Badges Row */}
      <div className="bg-slate-900/40 border border-slate-850/60 p-2 rounded-xl flex items-center justify-between gap-2 shadow-md" id="user_profile_section">
        {/* Profile */}
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 text-white font-bold flex items-center justify-center shadow-md border border-indigo-400/20 text-xs flex-shrink-0">
            👤
          </div>
          <div className="space-y-0.5 min-w-0">
            <span className="text-[10px] font-black text-slate-100 block truncate">
              Money 💸
            </span>
            <span className="text-[8px] text-slate-400 font-bold block font-mono">
              0721369895
            </span>
          </div>
        </div>

        {/* Stacked Wallet pill status displays */}
        <div className="flex flex-col gap-0.5 flex-shrink-0 text-right">
          <div className="bg-slate-950/85 border border-emerald-500/20 rounded-md px-2 py-0.5 flex items-center justify-between gap-3">
            <span className="text-[7px] font-black tracking-wider text-emerald-400">{t.playWallet}</span>
            <span className="text-[10px] font-black text-emerald-400 font-mono">
              {playerCoins.toFixed(2)}
            </span>
          </div>
          <div className="bg-slate-950/85 border border-amber-500/20 rounded-md px-2 py-0.5 flex items-center justify-between gap-3">
            <span className="text-[7px] font-black tracking-wider text-amber-400">{t.mainWallet}</span>
            <span className="text-[10px] font-black text-amber-400 font-mono">0.00</span>
          </div>
        </div>
      </div>

      {/* 3. Immersive Central Logo Header */}
      <div className="text-center py-2 flex flex-col items-center justify-center" id="central_branding_row">
        <YegnaLogo size={150} className="mb-1" />
        <h2 className="text-xl font-black tracking-wider bg-gradient-to-r from-emerald-400 via-white to-red-400 bg-clip-text text-transparent filter drop-shadow">
          {dict[language].branding}
        </h2>
        <span className="text-[8px] font-extrabold uppercase text-slate-500 tracking-widest block font-mono">
          {dict[language].brandingSub}
        </span>
      </div>

      {/* 4. Stat Cards Row (Three beautiful rounded cards) */}
      <div className="grid grid-cols-3 gap-2" id="habesha_lobby_stats">
        {/* Card 1: Game Countdown (Green Border) */}
        <div className="bg-slate-900/50 border border-emerald-500/30 p-2 rounded-xl text-center flex flex-col justify-between shadow-sm min-h-[72px]">
          <span className="text-[8px] sm:text-[9px] text-slate-400 font-extrabold leading-tight line-clamp-2">
            {t.gameStarting}
          </span>
          <span className="text-sm sm:text-base font-black text-emerald-400 font-mono mt-1">
            {formatCountdown(lobbyCountdown)}
          </span>
        </div>

        {/* Card 2: Draft Jackpot (Blue Border) */}
        <div className="bg-slate-900/50 border border-cyan-500/30 p-2 rounded-xl text-center flex flex-col justify-between shadow-sm min-h-[72px]">
          <span className="text-[8px] sm:text-[9px] text-slate-400 font-extrabold leading-tight">
            {t.draft}
          </span>
          <span className="text-xs sm:text-sm font-black text-cyan-400 font-mono mt-1 block leading-tight">
            {(gameModeJackpot(cardPrice)).toFixed(2)}
            <span className="text-[8px] text-slate-500 font-extrabold block">ETB</span>
          </span>
        </div>

        {/* Card 3: Bonus Spinner (Yellow Border) */}
        <div className="bg-slate-900/50 border border-amber-500/30 p-2 rounded-xl text-center flex flex-col justify-between shadow-sm min-h-[72px] items-center">
          <span className="text-[8px] sm:text-[9px] text-slate-400 font-extrabold leading-tight line-clamp-2">
            {t.bonusSoon}
          </span>
          <div className="mt-1 flex items-center justify-center">
            <Hourglass className="w-4 h-4 text-amber-400 animate-spin" />
          </div>
        </div>
      </div>

      {/* Real-time Registered Users / Online Daubers list section */}
      <div className="bg-slate-950/45 border border-slate-900 p-2.5 rounded-2xl space-y-2 shadow-inner" id="active_daubers_lobby">
        <div className="flex justify-between items-center text-[10px]">
          <span className="font-black uppercase tracking-wider text-slate-400">
            👥 Online Daubers ({Object.keys(players || {}).length} registered)
          </span>
          <span className="font-extrabold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full text-[8px] border border-emerald-500/20">
            Real-Time
          </span>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 pt-1 scrollbar-none" id="lobby_daubers_list">
          {Object.values(players || {}).map((p: any) => {
            const hasPurchased = p.cardsPurchased > 0;
            return (
              <div key={p.id} className="flex-shrink-0 flex items-center gap-2 bg-slate-900/80 border border-slate-850 px-2.5 py-1.5 rounded-xl shadow-sm hover:border-slate-800 transition-all">
                <div className="text-sm w-6.5 h-6.5 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center flex-shrink-0 text-slate-400 font-bold">
                  👤
                </div>
                <div className="space-y-0.5 text-left min-w-[70px] max-w-[100px]">
                  <span className="block text-[9px] font-black text-slate-100 truncate">{p.firstName || p.username}</span>
                  <span className={`block text-[7px] font-black uppercase tracking-wide ${hasPurchased ? 'text-emerald-400 font-bold' : 'text-amber-500 animate-pulse'}`}>
                    {hasPurchased ? `🎟️ ${p.cardsPurchased} Tickets` : '🟡 Selecting...'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Subtitle & Multi-card indicator */}
      <div className="flex justify-between items-center pt-1" id="selection_status_label">
        <h3 className="text-xs font-black text-slate-200">
          {t.selectCard} ({cardPrice} ብር)
        </h3>
        <span className="text-[10px] font-black text-emerald-400 font-mono bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
          {selectedCards.length} / 4
        </span>
      </div>

      {/* 6. High Fidelity 1-90 Numbers Grid Board */}
      <div className="bg-slate-950/80 border border-slate-900 p-2.5 rounded-2xl shadow-inner relative overflow-hidden" id="cards_selector_grid_box">
        <div className="grid grid-cols-10 gap-1 sm:gap-1.5" id="grid_1_90">
          {Array.from({ length: 90 }, (_, i) => i + 1).map((num) => {
            const isSelected = selectedCards.includes(num);
            const isPreviewing = previewCardNum === num;
            const isTaken = takenCards.includes(num);

            // If a ticket is sold/taken, we render it as dimmed and line-through to meet user's request!
            if (isTaken) {
               return (
                 <div 
                   key={num} 
                   className="aspect-square bg-slate-950/40 border border-slate-900/40 rounded-lg flex items-center justify-center text-slate-600/40 font-mono text-[11px] sm:text-xs font-bold line-through select-none cursor-not-allowed"
                 >
                   {num}
                 </div>
               );
            }

            return (
              <button
                key={num}
                type="button"
                onClick={() => toggleCardSelection(num)}
                className={`aspect-square rounded-lg flex items-center justify-center text-[11px] sm:text-xs font-black transition-all font-mono select-none ${
                  isSelected
                    ? 'bg-[#00e676] text-slate-950 font-black border-[#00e676] shadow-[0_0_12px_rgba(0,230,118,0.7)] scale-105 z-10'
                    : isPreviewing
                    ? 'bg-slate-800 border border-indigo-500/40 text-indigo-300'
                    : 'bg-slate-900/80 border border-slate-850 hover:border-slate-700 text-slate-350'
                }`}
              >
                {num}
              </button>
            );
          })}
        </div>
      </div>

      {/* 7. Neon Divider Line with current Selection Data */}
      <div className="border-t border-slate-800/80 pt-3 flex items-start justify-between text-xs" id="neon_divider_section">
        <div className="space-y-0.5">
          <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide block">
            {t.selectedText}
          </span>
          <span className="text-xs font-black text-slate-200 block font-mono">
            {selectedCards.length > 0 
              ? selectedCards.map(n => `#${n}`).join(', ') 
              : '#--'}
          </span>
        </div>

        <div className="flex gap-4 text-right">
          <div>
            <span className="text-[9px] text-[#ffb300] font-extrabold uppercase tracking-wide block">
              FEE (10%) / ኮሚሽን
            </span>
            <span className="text-xs font-bold text-[#ffb300] font-mono">
              {commissionFee} ETB
            </span>
          </div>
          <div>
            <span className="text-[9px] text-indigo-400 font-extrabold uppercase tracking-wide block">
              FOR GAME / ለጨዋታው
            </span>
            <span className="text-xs font-bold text-indigo-400 font-mono">
              {netStake} ETB
            </span>
          </div>
          <div className="border-l border-slate-800 pl-4">
            <span className="text-[9px] text-emerald-400 font-extrabold uppercase tracking-wide block">
              TOTAL / ጠቅላላ
            </span>
            <span className="text-sm font-black text-[#00e676] font-mono">
              {totalCost} ETB
            </span>
          </div>
        </div>
      </div>

      {/* 8. Elegant Card Preview Thumbnail (Single or Multi card visualizer) */}
      <div className="bg-slate-900/50 border border-slate-850 p-2.5 rounded-2xl" id="preview_selected_container">
        {selectedCards.length >= 2 ? (
          <div className="grid grid-cols-2 gap-2 w-full max-h-[220px] overflow-y-auto scrollbar-none" id="preview_cards_grid">
            {selectedCards.map((num) => {
              const card = generateDeterministicBingoCard(num);
              return (
                <div key={num} className="bg-slate-950 rounded-xl border border-slate-800 p-1.5 space-y-1 shadow-md">
                  <div className="flex justify-between items-center px-1 border-b border-slate-900 pb-0.5 text-[6px]">
                    <span className="text-emerald-400 font-black font-mono">ID: #{num}</span>
                    <span className="text-slate-500 font-extrabold font-mono">SELECTED</span>
                  </div>
                  {/* Letter heads B I N G O */}
                  <div className="grid grid-cols-5 text-center gap-0.5">
                    {['B', 'I', 'N', 'G', 'O'].map((col, idx) => (
                      <span 
                        key={col} 
                        className={`text-[6px] font-black rounded py-0.2 ${
                          idx === 0 ? 'bg-rose-500/10 text-rose-400' :
                          idx === 1 ? 'bg-amber-500/10 text-amber-400' :
                          idx === 2 ? 'bg-indigo-500/10 text-indigo-400' :
                          idx === 3 ? 'bg-emerald-500/10 text-emerald-400' :
                          'bg-pink-500/10 text-pink-400'
                        }`}
                      >
                        {col}
                      </span>
                    ))}
                  </div>
                  {/* Miniature cells layout */}
                  <div className="grid grid-cols-5 gap-0.5 text-center">
                    {card.grid.map((row, rIdx) => (
                      row.map((cell, cIdx) => {
                        const isFree = cell.value === 'FREE';
                        return (
                          <div
                            key={`${rIdx}-${cIdx}`}
                            className={`aspect-square flex items-center justify-center rounded-[2px] text-[6px] font-bold border ${
                              isFree
                                ? 'bg-indigo-500/20 border-indigo-500/30 text-indigo-400'
                                : 'bg-slate-900 border-slate-850 text-slate-350'
                            }`}
                          >
                            {isFree ? '⭐' : cell.value}
                          </div>
                        );
                      })
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* Miniature Ticket layout paper preview (Single) */
          <div className="bg-slate-950 rounded-xl border border-slate-800 p-2 max-w-[210px] mx-auto space-y-1.5 shadow-md">
            {/* Header */}
            <div className="flex justify-between items-center px-1 border-b border-slate-900 pb-1">
              <span className="text-[8px] text-emerald-400 font-black tracking-wide font-mono">
                CARD ID: #{selectedCards.length === 1 ? selectedCards[0] : previewCardNum}
              </span>
              <span className="text-[7px] text-slate-500 font-extrabold font-mono">
                PREVIEW
              </span>
            </div>

            {/* Letter heads B I N G O */}
            <div className="grid grid-cols-5 text-center gap-0.5">
              {['B', 'I', 'N', 'G', 'O'].map((col, idx) => (
                <span 
                  key={col} 
                  className={`text-[8px] font-black rounded py-0.5 ${
                    idx === 0 ? 'bg-rose-500/10 text-rose-400' :
                    idx === 1 ? 'bg-amber-500/10 text-amber-400' :
                    idx === 2 ? 'bg-indigo-500/10 text-indigo-400' :
                    idx === 3 ? 'bg-emerald-500/10 text-emerald-400' :
                    'bg-pink-500/10 text-pink-400'
                  }`}
                >
                  {col}
                </span>
              ))}
            </div>

            {/* Miniature cells layout */}
            <div className="grid grid-cols-5 gap-0.5 text-center">
              {(selectedCards.length === 1 ? generateDeterministicBingoCard(selectedCards[0]) : previewCard).grid.map((row, rIdx) => (
                row.map((cell, cIdx) => {
                  const isFree = cell.value === 'FREE';
                  return (
                    <div
                      key={`${rIdx}-${cIdx}`}
                      className={`aspect-square flex items-center justify-center rounded text-[8px] font-bold border ${
                        isFree
                          ? 'bg-indigo-500/20 border-indigo-500/30 text-indigo-400'
                          : 'bg-slate-900 border-slate-850 text-slate-350'
                      }`}
                    >
                      {isFree ? '⭐' : cell.value}
                    </div>
                  );
                })
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 9. Grand Confirmation Button */}
      <button
        onClick={handleConfirm}
        disabled={selectedCards.length === 0 || !canAfford}
        className={`w-full py-3 px-6 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl flex items-center justify-center gap-2 ${
          selectedCards.length > 0 && canAfford
            ? 'bg-[#00e676] text-slate-950 font-black hover:bg-[#00c853] shadow-[0_0_20px_rgba(0,230,118,0.3)] hover:translate-y-[-1px] active:translate-y-0 scale-102'
            : 'bg-slate-900 border border-slate-800 text-slate-600 cursor-not-allowed shadow-none'
        }`}
      >
        <Play className="w-3.5 h-3.5" />
        {selectedCards.length === 0 
          ? t.selectCard 
          : !canAfford 
          ? t.insufficient 
          : `${t.confirmBuy} - ${totalCost} ETB (${selectedCards.length} ${language === 'AM' ? 'ካርታ' : 'Cards'})`
        }
      </button>

    </div>
  );
}

// Simple Helper to return realistic lottery draft jackpot depending on stake
function gameModeJackpot(stake: number): number {
  if (stake === 10) return 552.50;
  if (stake === 30) return 1650.00;
  if (stake === 50) return 2750.00;
  return 5500.00;
}
