/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Users, Coins, ChevronRight, Lock, Flame, Sparkles, User, Globe } from 'lucide-react';
import { GameRoom } from '../types.js';

interface BingoRoomListProps {
  rooms: { [id: string]: GameRoom };
  currentRoomId: string | null;
  onJoinRoom: (roomId: string) => void;
  playerCoins: number;
}

export default function BingoRoomList({ 
  rooms, 
  currentRoomId, 
  onJoinRoom, 
  playerCoins
}: BingoRoomListProps) {

  const roomList = Object.values(rooms).filter(r => !r.id.startsWith('secret_'));

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'lobby':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
            🟢 Open Lobby
          </span>
        );
      case 'countdown':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 animate-pulse">
            ⏳ Starting Soon
          </span>
        );
      case 'playing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-slate-950 border border-slate-800 text-slate-400">
            🎮 Playing (Locked)
          </span>
        );
      case 'ended':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-slate-950 border border-slate-800 text-slate-500">
            🏁 Ended
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="room_list_container">
      <div className="space-y-1.5">
        <h2 className="text-xl font-black text-slate-100 tracking-tight flex items-center gap-1.5 uppercase">
          <Flame className="w-5 h-5 text-indigo-400 animate-pulse" />
          Select Your Room Stake
        </h2>
        <p className="text-xs text-slate-400">
          Play in real-time with other online daubers. Standard stakes apply.
        </p>
      </div>

      <div className="grid gap-4" id="rooms_grid">
        {roomList.map((room) => {
          const playersCount = Object.keys(room.players).length;
          const isCurrent = currentRoomId === room.id;
          const canAfford = playerCoins >= room.cardPrice;
          const isLocked = room.status === 'playing';

          return (
            <div
              key={room.id}
              className={`p-5 rounded-2xl border transition-all relative overflow-hidden ${
                isCurrent
                  ? 'bg-indigo-500/10 border-indigo-500 ring-1 ring-indigo-500/40 shadow-xl shadow-indigo-500/5'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-750 hover:shadow-lg hover:shadow-indigo-500/5'
              }`}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="space-y-1">
                  <h3 className="text-base font-black text-slate-100 flex items-center gap-1.5">
                    {room.name}
                    {isCurrent && (
                      <span className="text-[9px] uppercase tracking-wider bg-indigo-500 text-white font-extrabold px-2 py-0.5 rounded">
                        Active Room
                      </span>
                    )}
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-slate-500" />
                      {playersCount} {playersCount === 1 ? 'Player' : 'Players'}
                    </span>
                    <span className="flex items-center gap-1 font-bold text-indigo-400">
                      <Coins className="w-3.5 h-3.5" />
                      {room.cardPrice} ETB / ticket
                    </span>
                  </div>
                </div>
                {getStatusBadge(room.status)}
              </div>

              {/* Action Button */}
              <div className="flex items-center justify-between pt-3.5 border-t border-slate-800">
                <span className="text-[11px] text-slate-500">
                  {isLocked 
                    ? 'ጨዋታው ላይ ነው (Game in Progress)'
                    : `Stake: ${room.cardPrice} Birr (ETB)`
                  }
                </span>

                {isLocked ? (
                  <button
                    onClick={() => onJoinRoom(room.id)}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-500/20 border border-indigo-500/30 hover:bg-indigo-500/30 text-indigo-300 font-bold text-xs rounded-xl transition-all"
                  >
                    <Users className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                    ታዘብ (Spectate)
                  </button>
                ) : (
                  <button
                    onClick={() => onJoinRoom(room.id)}
                    className={`flex items-center gap-1 px-4 py-2.5 font-black uppercase tracking-wider text-[10px] rounded-xl transition-all ${
                      isCurrent
                        ? 'bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30'
                        : canAfford
                        ? 'bg-indigo-500 hover:bg-indigo-400 active:bg-indigo-600 text-white shadow-md shadow-indigo-500/10 hover:translate-y-[-1px] active:translate-y-0'
                        : 'bg-slate-950 border border-slate-850 text-slate-600 cursor-not-allowed'
                    }`}
                  >
                    {isCurrent ? 'Play Now' : 'Select Stakes'}
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
