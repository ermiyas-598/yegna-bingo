/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Coins, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';

interface DailyRewardsProps {
  currentCoins: number;
  onClaim: () => void;
  socket: any;
}

interface Segment {
  reward: number;
  color: string;
  label: string;
}

const SEGMENTS: Segment[] = [
  { reward: 100, color: '#1e293b', label: '100' },
  { reward: 250, color: '#4f46e5', label: '250' },
  { reward: 50, color: '#334155', label: '50' },
  { reward: 500, color: '#10b981', label: '500' },
  { reward: 150, color: '#1e1b4b', label: '150' },
  { reward: 300, color: '#6366f1', label: '300' },
];

export default function DailyRewards({ currentCoins, onClaim, socket }: DailyRewardsProps) {
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinAngle, setSpinAngle] = useState(0);
  const [prize, setPrize] = useState<Segment | null>(null);
  const [cooldown, setCooldown] = useState<number>(0); // countdown in seconds

  useEffect(() => {
    // Check if there is an active cooldown in localstorage
    const savedTime = localStorage.getItem('bingo_last_spin');
    if (savedTime) {
      const elapsed = Date.now() - parseInt(savedTime, 10);
      const remaining = Math.max(0, 60 - Math.floor(elapsed / 1000)); // 60s cooldown for testing
      if (remaining > 0) {
        setCooldown(remaining);
      }
    }
  }, []);

  // Update countdown timer
  useEffect(() => {
    if (cooldown > 0) {
      const timer = setTimeout(() => setCooldown(cooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [cooldown]);

  const handleSpin = () => {
    if (isSpinning || cooldown > 0) return;

    setIsSpinning(true);
    setPrize(null);

    // Pick a random segment (e.g. 250 coins is the standard backend prize, segment index 1)
    // To make it look real, we can select a random segment index, let's always target segment 1 (250) or 3 (500)
    // and make sure we tell the server. For simplicity, we trigger the server event.
    // Let's make it land on 250 Coins segment (Segment Index 1) which matches the standard server reward (+250)!
    const targetSegmentIndex = 1; // index 1: 250 Coins
    const segmentDegrees = 360 / SEGMENTS.length;
    
    // Calculate final angle: multiple full rotations + offset to land on target segment
    // Segment 1 starts at 60 deg and ends at 120 deg. Let's land in the middle (90 deg).
    // In Canvas/CSS wheel rotation, 0 deg points to the right. The pointer is at the top (270 deg).
    // To land a segment under the top pointer, we calculate the negative offset.
    // Let's do a reliable random-looking spin formula:
    const randomRotations = 5 + Math.floor(Math.random() * 5); // 5 to 9 full spins
    const targetAngle = randomRotations * 360 + (360 - (targetSegmentIndex * segmentDegrees) - (segmentDegrees / 2));

    setSpinAngle(targetAngle);

    setTimeout(() => {
      setIsSpinning(false);
      const winSegment = SEGMENTS[targetSegmentIndex];
      setPrize(winSegment);
      onClaim(); // Triggers server event (claim 250 coins)

      // Set cooldown
      localStorage.setItem('bingo_last_spin', Date.now().toString());
      setCooldown(60); // 60 seconds cooldown for testing

      // Play haptic feedback if TMA is available
      const tg = (window as any).Telegram?.WebApp;
      if (tg?.HapticFeedback) {
        tg.HapticFeedback.notificationOccurred('success');
      }
    }, 4500); // Animation takes 4.5 seconds
  };

  const handleDevReset = () => {
    localStorage.removeItem('bingo_last_spin');
    setCooldown(0);
    setPrize(null);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-6 space-y-6 animate-fade-in text-slate-100" id="daily_rewards_container">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2">
          <Coins className="w-5 h-5 text-indigo-400 animate-bounce" />
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-200">Lucky Coin Wheel</h2>
        </div>
        <div className="px-3.5 py-1.5 bg-indigo-500/10 rounded-xl border border-indigo-500/30">
          <span className="text-sm font-bold text-indigo-300 font-mono">{currentCoins} 🪙</span>
        </div>
      </div>

      <div className="flex flex-col items-center justify-center py-4 space-y-6">
        {/* Wheel Physical Arena */}
        <div className="relative flex items-center justify-center w-60 h-60" id="wheel_arena">
          {/* Top Pointer Indicator */}
          <div className="absolute top-0 z-15 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-indigo-400 drop-shadow-[0_0_10px_rgba(99,102,241,0.5)]"></div>

          {/* Inner Spinning Canvas Wheel */}
          <div
            className="w-56 h-56 rounded-full border-4 border-slate-950 shadow-2xl overflow-hidden relative"
            style={{
              transform: `rotate(${spinAngle}deg)`,
              transition: isSpinning ? 'transform 4s cubic-bezier(0.15, 0.85, 0.25, 1)' : 'none',
              backgroundImage: `conic-gradient(
                ${SEGMENTS[0].color} 0deg 60deg,
                ${SEGMENTS[1].color} 60deg 120deg,
                ${SEGMENTS[2].color} 120deg 180deg,
                ${SEGMENTS[3].color} 180deg 240deg,
                ${SEGMENTS[4].color} 240deg 300deg,
                ${SEGMENTS[5].color} 300deg 360deg
              )`
            }}
          >
            {/* Center Pin */}
            <div className="absolute inset-0 m-auto w-10 h-10 bg-slate-950 border-2 border-indigo-500/50 rounded-full z-10 flex items-center justify-center shadow-md">
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </div>

            {/* Labels overlay */}
            {SEGMENTS.map((seg, idx) => {
              const rotation = idx * 60 + 30; // middle of segment
              return (
                <div
                  key={idx}
                  className="absolute text-center text-[10px] font-black text-white select-none whitespace-nowrap"
                  style={{
                    top: '50%',
                    left: '50%',
                    width: '100px',
                    height: '24px',
                    transform: `translate(-50%, -50%) rotate(${rotation}deg) translate(65px) rotate(90deg)`,
                    transformOrigin: 'center center',
                  }}
                >
                  {seg.reward}
                </div>
              );
            })}
          </div>
        </div>

        {/* Spin Controls */}
        <div className="text-center space-y-3 w-full">
          {prize ? (
            <div className="p-3 bg-indigo-950 border border-indigo-800/60 rounded-xl text-indigo-200 text-sm font-semibold animate-pulse">
              🎉 Congratulations! You won <span className="font-extrabold">{prize.reward} Coins</span>!
            </div>
          ) : (
            <p className="text-xs text-slate-400">
              Spin to win a free reload of up to 500 coins instantly!
            </p>
          )}

          <div className="flex gap-2">
            <button
              onClick={handleSpin}
              disabled={isSpinning || cooldown > 0}
              className={`flex-1 py-3.5 px-6 rounded-xl font-bold transition-all shadow-md flex items-center justify-center gap-2 uppercase tracking-wider text-xs ${
                isSpinning || cooldown > 0
                  ? 'bg-slate-950 border border-slate-800 text-slate-500 cursor-not-allowed shadow-none'
                  : 'bg-indigo-500 hover:bg-indigo-400 active:bg-indigo-600 text-white hover:translate-y-[-1px] active:translate-y-0 shadow-indigo-500/10'
              }`}
            >
              {isSpinning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Spinning...
                </>
              ) : cooldown > 0 ? (
                <>
                  <AlertCircle className="w-4 h-4 text-slate-500" />
                  Ready in {cooldown}s
                </>
              ) : (
                'Claim Free Coins'
              )}
            </button>

            {/* Developer Cheat Mode Toggle */}
            {cooldown > 0 && (
              <button
                onClick={handleDevReset}
                title="Bypass Cooldown (Dev Mode)"
                className="p-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 rounded-xl font-semibold text-xs flex items-center justify-center transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
