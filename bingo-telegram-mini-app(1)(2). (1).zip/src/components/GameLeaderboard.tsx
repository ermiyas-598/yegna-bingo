/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Trophy, ShieldAlert, Award, Compass, HelpCircle, Star, CircleDot } from 'lucide-react';

interface GameLeaderboardProps {
  playerCoins: number;
  playerUsername: string;
}

interface LeaderboardItem {
  name: string;
  avatar: string;
  score: number;
  badge: string;
  isPlayer?: boolean;
}

function getAvatarForUsername(username: string, selfUsername: string): string {
  if (username === selfUsername) return '🐯';
  
  const avatars = ['🦁', '🦊', '🦉', '🐙', '🦖', '🦄', '🦅', '🕊️', '🥑', '💎'];
  let sum = 0;
  for (let i = 0; i < username.length; i++) {
    sum += username.charCodeAt(i);
  }
  return avatars[sum % avatars.length];
}

function getBadgeForScore(score: number, isPlayer: boolean): string {
  if (isPlayer) return 'Champion (You)';
  if (score >= 12000) return 'Bingo Overlord 👑';
  if (score >= 8000) return 'Grand Master';
  if (score >= 4000) return 'Elite Dauber';
  if (score >= 1500) return 'Pro Player';
  return 'Rookie';
}

export default function GameLeaderboard({ playerCoins, playerUsername }: GameLeaderboardProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardItem[]>([]);

  useEffect(() => {
    let active = true;

    async function fetchLeaderboard() {
      try {
        const response = await fetch('/api/leaderboard');
        if (!response.ok) throw new Error('Failed to fetch');
        const data = await response.json();
        if (!active) return;

        if (data && Array.isArray(data.leaderboard)) {
          const mapped: LeaderboardItem[] = data.leaderboard.map((item: { username: string; coins: number }) => {
            const isSelf = item.username === playerUsername;
            return {
              name: item.username,
              avatar: getAvatarForUsername(item.username, playerUsername),
              score: item.coins,
              badge: getBadgeForScore(item.coins, isSelf),
              isPlayer: isSelf
            };
          });
          setLeaderboard(mapped);
        }
      } catch (error) {
        console.error('Error fetching leaderboard for game:', error);
        if (active) {
          const fallback: LeaderboardItem[] = playerUsername ? [
            { name: playerUsername, avatar: '🐯', score: playerCoins, badge: 'Champion (You)', isPlayer: true }
          ] : [];
          setLeaderboard(fallback);
        }
      }
    }

    fetchLeaderboard();
    const interval = setInterval(fetchLeaderboard, 12000);

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [playerCoins, playerUsername]);

  return (
    <div className="space-y-6 animate-fade-in text-slate-100" id="leaderboard_container">
      {/* 1. Rulebook Guide & Patterns */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-5 space-y-4">
        <h3 className="text-base font-black text-slate-100 flex items-center gap-2 uppercase tracking-wide">
          <HelpCircle className="w-5 h-5 text-indigo-400" />
          75-Ball Bingo Official Rulebook
        </h3>

        <div className="grid grid-cols-3 gap-2.5" id="rules_patterns_grid">
          {/* Pattern 1 */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center space-y-1">
            <span className="text-[9px] uppercase font-black tracking-wider text-slate-500">Pattern 1</span>
            <div className="text-xs font-black text-slate-200">Standard Line</div>
            <p className="text-[10px] text-slate-500 leading-normal">
              5 marked squares in any Horizontal, Vertical, or Diagonal line.
            </p>
          </div>

          {/* Pattern 2 */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center space-y-1">
            <span className="text-[9px] uppercase font-black tracking-wider text-slate-500">Pattern 2</span>
            <div className="text-xs font-black text-slate-200">Four Corners</div>
            <p className="text-[10px] text-slate-500 leading-normal">
              Mark top-left, top-right, bottom-left, and bottom-right.
            </p>
          </div>

          {/* Pattern 3 */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-center space-y-1">
            <span className="text-[9px] uppercase font-black tracking-wider text-slate-500">Pattern 3</span>
            <div className="text-xs font-black text-slate-200">Full House</div>
            <p className="text-[10px] text-slate-500 leading-normal">
              Blackout! Mark every single of the 24 cells on the card grid.
            </p>
          </div>
        </div>

        <div className="p-3 bg-indigo-950/40 border border-indigo-900 rounded-xl text-xs text-indigo-300 leading-normal flex gap-2">
          <ShieldAlert className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>
            <strong>The "Bingo!" Claim Law:</strong> Submit claims instantly when you finish a pattern. False claims freeze your cards for 10 seconds!
          </span>
        </div>
      </div>

      {/* 2. Global Leaderboard */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-5 space-y-4">
        <h3 className="text-base font-black text-slate-100 flex items-center gap-2 uppercase tracking-wide">
          <Trophy className="w-5 h-5 text-indigo-400 animate-pulse" />
          Global High Daubers
        </h3>

        <div className="divide-y divide-slate-800/60" id="leaderboard_list">
          {leaderboard.map((user, idx) => {
            const isTop3 = idx < 3;
            const rankColors = [
              'bg-amber-500/10 text-amber-400 border-amber-500/20',
              'bg-slate-400/10 text-slate-300 border-slate-400/20',
              'bg-orange-500/10 text-orange-400 border-orange-500/20',
            ];

            return (
              <div
                key={idx}
                className={`flex items-center justify-between py-3.5 first:pt-0 last:pb-0 ${
                  user.isPlayer ? 'bg-indigo-500/10 -mx-5 px-5 rounded-xl border-y border-indigo-500/20' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Rank Badge */}
                  <div className={`w-6 h-6 rounded-full border text-[10px] font-black flex items-center justify-center ${
                    isTop3 ? rankColors[idx] : 'bg-slate-950 text-slate-500 border-slate-850'
                  }`}>
                    {idx + 1}
                  </div>

                  <div className="space-y-0.5">
                    <span className="text-sm font-bold text-slate-200 flex items-center gap-1.5">
                      {user.name}
                      {user.isPlayer && (
                        <span className="text-[8px] bg-indigo-500 text-white px-1.5 py-0.5 rounded font-black uppercase tracking-wider">
                          You
                        </span>
                      )}
                    </span>
                    <span className="block text-[10px] text-slate-500 font-extrabold uppercase tracking-wider">
                      {user.badge}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-sm font-extrabold text-slate-200 font-mono">
                    {user.score.toLocaleString()}
                  </span>
                  <span className="block text-[9px] text-slate-500 uppercase tracking-widest font-extrabold">
                    Coins 🪙
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
