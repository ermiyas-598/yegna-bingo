/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Trophy, Medal, Crown, Star, TrendingUp, Flame, Users } from 'lucide-react';

interface RankItem {
  rank: number;
  username: string;
  avatar: string;
  winnings: number;
  winStreak: number;
}

interface BingoRankListProps {
  playerCoins: number;
  playerUsername: string;
  playerAvatar: string;
}

function getAvatarForUsername(username: string, selfUsername: string, selfAvatar: string): string {
  if (username === selfUsername) return selfAvatar || '🦁';
  
  const avatars = ['🦁', '🦅', '🕊️', '☕', '👑', '🦊', '💎', '🥑', '🐯', '🐙', '🦖', '🦄'];
  let sum = 0;
  for (let i = 0; i < username.length; i++) {
    sum += username.charCodeAt(i);
  }
  return avatars[sum % avatars.length];
}

export default function BingoRankList({ playerCoins, playerUsername, playerAvatar }: BingoRankListProps) {
  const [leaderboard, setLeaderboard] = useState<RankItem[]>([]);

  useEffect(() => {
    let active = true;

    async function fetchLeaderboard() {
      try {
        const response = await fetch('/api/leaderboard');
        if (!response.ok) throw new Error('Failed to fetch');
        const data = await response.json();
        if (!active) return;

        if (data && Array.isArray(data.leaderboard)) {
          // Map backend entries to RankItem schema
          const mapped: RankItem[] = data.leaderboard.map((item: { username: string; coins: number }, idx: number) => {
            // Assign some fun win streaks deterministically for flavor
            let winStreak = 0;
            if (idx === 0) winStreak = 5;
            else if (idx === 1) winStreak = 3;
            else if (idx === 2) winStreak = 2;
            else if (idx === 4) winStreak = 1;

            return {
              rank: idx + 1,
              username: item.username,
              avatar: getAvatarForUsername(item.username, playerUsername, playerAvatar),
              winnings: item.coins,
              winStreak
            };
          });
          setLeaderboard(mapped);
        }
      } catch (error) {
        console.error('Error fetching leaderboard:', error);
        // Fallback local list if server is unreachable
        if (active) {
          const fallback: RankItem[] = playerUsername ? [
            { rank: 1, username: playerUsername, avatar: playerAvatar || '🦁', winnings: playerCoins, winStreak: 0 }
          ] : [];
          setLeaderboard(fallback);
        }
      }
    }

    fetchLeaderboard();
    // Poll the leaderboard every 10 seconds to keep it fully real-time
    const interval = setInterval(fetchLeaderboard, 10000);

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [playerCoins, playerUsername, playerAvatar]);

  const topThree = leaderboard.slice(0, 3);
  const remaining = leaderboard.slice(3);

  return (
    <div className="space-y-6 animate-fade-in text-slate-100" id="bingo_rankings_dashboard">
      {/* 1. Header Banner */}
      <div className="bg-slate-900 border border-slate-850 p-5 rounded-3xl shadow-xl flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Trophy className="w-48 h-48 text-amber-500" />
        </div>
        <div className="space-y-1 z-10">
          <span className="text-[10px] uppercase tracking-widest font-extrabold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20 inline-block leading-none mb-1.5">
            የአሸናፊዎች ደረጃ (LEADERBOARD)
          </span>
          <h2 className="text-2xl font-black text-slate-100 flex items-center gap-2 justify-center md:justify-start">
            YEGNA BINGO CHAMPIONS <Crown className="w-5 h-5 text-amber-400 animate-pulse" />
          </h2>
          <p className="text-xs text-slate-400">
            Real-time leaderboard of the highest earners in the arena. Earn coins to climb!
          </p>
        </div>
        <div className="bg-slate-950 px-4 py-2.5 rounded-2xl border border-slate-850 text-center flex-shrink-0 z-10 shadow-inner">
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500 block">YOUR STANDINGS</span>
          <span className="text-base font-black text-amber-400 font-mono">
            #{leaderboard.find(item => item.username === playerUsername)?.rank || 6}
          </span>
        </div>
      </div>

      {/* 2. Top 3 Podium Visuals */}
      <div className="grid grid-cols-3 gap-3 pt-4 max-w-md mx-auto" id="rank_podium_row">
        {/* 2nd Place */}
        <div className="flex flex-col items-center justify-end">
          <div className="relative text-center pb-2">
            <span className="text-3xl block">🥈</span>
            <span className="text-xs font-black block truncate max-w-[80px] text-slate-300 mt-1">{topThree[1]?.username}</span>
            <span className="text-[10px] font-black text-cyan-400 font-mono block">{topThree[1]?.winnings.toLocaleString()} ETB</span>
          </div>
          <div className="w-full bg-slate-900 border-t-2 border-slate-700 h-20 rounded-t-xl flex flex-col items-center justify-center shadow-lg">
            <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center font-black text-slate-300 text-xs">
              2
            </div>
            <span className="text-[8px] text-slate-500 font-bold tracking-wider mt-1 uppercase">SILVER</span>
          </div>
        </div>

        {/* 1st Place - Crowned Leader */}
        <div className="flex flex-col items-center justify-end scale-105 z-10">
          <div className="relative text-center pb-2">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <Crown className="w-5 h-5 text-amber-400 animate-bounce" />
            </div>
            <span className="text-4xl block filter drop-shadow">🥇</span>
            <span className="text-xs font-black block truncate max-w-[90px] text-amber-400 mt-1">{topThree[0]?.username}</span>
            <span className="text-[10px] font-black text-amber-400 font-mono block">{topThree[0]?.winnings.toLocaleString()} ETB</span>
          </div>
          <div className="w-full bg-gradient-to-b from-amber-950/40 to-slate-900 border-t-2 border-amber-500 h-24 rounded-t-xl flex flex-col items-center justify-center shadow-xl">
            <div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center font-black text-slate-950 text-xs shadow-md shadow-amber-500/20">
              1
            </div>
            <span className="text-[8px] text-amber-400 font-bold tracking-wider mt-1 uppercase">CHAMP</span>
          </div>
        </div>

        {/* 3rd Place */}
        <div className="flex flex-col items-center justify-end">
          <div className="relative text-center pb-2">
            <span className="text-3xl block">🥉</span>
            <span className="text-xs font-black block truncate max-w-[80px] text-slate-300 mt-1">{topThree[2]?.username}</span>
            <span className="text-[10px] font-black text-orange-400 font-mono block">{topThree[2]?.winnings.toLocaleString()} ETB</span>
          </div>
          <div className="w-full bg-slate-900 border-t-2 border-orange-950/40 h-16 rounded-t-xl flex flex-col items-center justify-center shadow-lg">
            <div className="w-7 h-7 rounded-full bg-slate-800 border border-orange-900/30 flex items-center justify-center font-black text-orange-400 text-xs">
              3
            </div>
            <span className="text-[8px] text-slate-500 font-bold tracking-wider mt-1 uppercase">BRONZE</span>
          </div>
        </div>
      </div>

      {/* 3. Detailed Rankings List Table */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl shadow-xl overflow-hidden" id="rankings_table_card">
        <div className="px-5 py-4 border-b border-slate-850 bg-slate-900/80 flex justify-between items-center">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-400" />
            <span>Leaderboard Standings</span>
          </h3>
          <span className="text-[10px] font-bold text-slate-500">Showing active contenders</span>
        </div>

        <div className="divide-y divide-slate-850/50">
          {leaderboard.map((item) => {
            const isSelf = item.username === playerUsername;
            return (
              <div 
                key={item.username} 
                className={`px-5 py-3.5 flex items-center justify-between gap-4 transition-colors ${
                  isSelf 
                    ? 'bg-emerald-500/10 border-l-4 border-emerald-500' 
                    : 'hover:bg-slate-950/40'
                }`}
              >
                {/* Left side info */}
                <div className="flex items-center gap-3.5 min-w-0">
                  <span className={`w-6 text-center text-xs font-mono font-black ${
                    item.rank === 1 ? 'text-amber-400' :
                    item.rank === 2 ? 'text-slate-300' :
                    item.rank === 3 ? 'text-orange-400' :
                    'text-slate-500'
                  }`}>
                    #{item.rank}
                  </span>
                  
                  <div className="min-w-0">
                    <span className={`text-xs font-black block truncate ${isSelf ? 'text-emerald-400' : 'text-slate-200'}`}>
                      {item.username} {isSelf && <span className="text-[9px] uppercase font-extrabold text-emerald-500 ml-1">(You)</span>}
                    </span>
                    <div className="flex items-center gap-2">
                      {item.winStreak > 0 && (
                        <span className="inline-flex items-center text-[8px] font-black uppercase bg-red-500/10 text-red-400 px-1 py-0.5 rounded border border-red-500/10 gap-0.5 mt-0.5">
                          <Flame className="w-2.5 h-2.5 text-red-500 animate-pulse" /> {item.winStreak} Streak
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Winnings balance */}
                <div className="text-right flex-shrink-0">
                  <span className={`text-xs font-black font-mono block ${isSelf ? 'text-emerald-400' : 'text-slate-200'}`}>
                    {item.winnings.toLocaleString()} ETB
                  </span>
                  <span className="text-[8px] uppercase tracking-wider text-slate-500 font-extrabold block">TOTAL WON</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
