import React from 'react';

interface YegnaLogoProps {
  className?: string;
  size?: number;
}

export const YegnaLogo: React.FC<YegnaLogoProps> = ({ className = 'w-32 h-32', size = 200 }) => {
  return (
    <div className={`relative flex items-center justify-center select-none ${className}`} style={{ width: size, height: size }}>
      <svg
        viewBox="0 0 600 600"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-xl"
      >
        <defs>
          {/* Gold gradients for boundaries and crown */}
          <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFE082" />
            <stop offset="30%" stopColor="#FFD54F" />
            <stop offset="50%" stopColor="#FFB300" />
            <stop offset="70%" stopColor="#FF8F00" />
            <stop offset="100%" stopColor="#FFC107" />
          </linearGradient>

          <radialGradient id="goldRadial" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFF8E1" />
            <stop offset="40%" stopColor="#FFE082" />
            <stop offset="80%" stopColor="#FFB300" />
            <stop offset="100%" stopColor="#FF8F00" />
          </radialGradient>

          {/* Deep royal blue radial background */}
          <radialGradient id="blueRadial" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
            <stop offset="0%" stopColor="#1E88E5" />
            <stop offset="45%" stopColor="#1565C0" />
            <stop offset="75%" stopColor="#0D47A1" />
            <stop offset="100%" stopColor="#07224f" />
          </radialGradient>

          {/* Multi-color gradient for Central Ball #7 */}
          <linearGradient id="ball7Grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF1744" />
            <stop offset="25%" stopColor="#FF8F00" />
            <stop offset="50%" stopColor="#FFEB3B" />
            <stop offset="75%" stopColor="#4CAF50" />
            <stop offset="100%" stopColor="#00E5FF" />
          </linearGradient>

          {/* Individual ball gradients */}
          <radialGradient id="orangeBall" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#FFE082" />
            <stop offset="40%" stopColor="#FFB300" />
            <stop offset="100%" stopColor="#E65100" />
          </radialGradient>

          <radialGradient id="redBall" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#FF8A80" />
            <stop offset="40%" stopColor="#E53935" />
            <stop offset="100%" stopColor="#B71C1C" />
          </radialGradient>

          <radialGradient id="blueBall" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#80D8FF" />
            <stop offset="40%" stopColor="#00B0FF" />
            <stop offset="100%" stopColor="#0A2240" />
          </radialGradient>

          <radialGradient id="greenBall" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#B9F6CA" />
            <stop offset="40%" stopColor="#00E676" />
            <stop offset="100%" stopColor="#1B5E20" />
          </radialGradient>

          {/* Main Title text gold gradient with outline effect */}
          <linearGradient id="titleGold" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="20%" stopColor="#FFF3E0" />
            <stop offset="50%" stopColor="#FFA726" />
            <stop offset="80%" stopColor="#FB8C00" />
            <stop offset="100%" stopColor="#E65100" />
          </linearGradient>

          {/* Curved text paths */}
          <path id="numbersPath" d="M 80,300 A 220,220 0 1,1 520,300" />
          <path id="subNumbersPath" d="M 520,300 A 220,220 0 1,1 80,300" />
          <path id="innerHeaderPath" d="M 130,300 A 170,170 0 1,1 470,300" />
          
          {/* Dropshadow filter */}
          <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="8" stdDeviation="6" floodColor="#000000" floodOpacity="0.5" />
          </filter>
        </defs>

        {/* Outer Scalloped Decorative Gold Border */}
        <g filter="url(#shadow)">
          {/* Multiple overlapping rotated stars / scallops to form the emblem seal */}
          {Array.from({ length: 24 }).map((_, i) => {
            const angle = (i * 360) / 24;
            return (
              <rect
                key={i}
                x="60"
                y="60"
                width="480"
                height="480"
                rx="85"
                ry="85"
                fill="none"
                stroke="url(#goldGrad)"
                strokeWidth="7"
                transform={`rotate(${angle} 300 300)`}
                opacity="0.85"
              />
            );
          })}

          {/* Thick Solid Gold Outer Ring */}
          <circle cx="300" cy="300" r="248" fill="none" stroke="url(#goldGrad)" strokeWidth="8" />
          
          {/* Deep Royal Blue Main Background Circle */}
          <circle cx="300" cy="300" r="240" fill="url(#blueRadial)" />

          {/* Inner Golden Dotted Ring */}
          <circle cx="300" cy="300" r="236" fill="none" stroke="url(#goldGrad)" strokeWidth="3" strokeDasharray="6 8" />
          
          {/* Outer Track with Numbers and Stars */}
          <g>
            <text fill="url(#goldGrad)" fontSize="16" fontWeight="bold" letterSpacing="4">
              <textPath href="#numbersPath" startOffset="5%">
                ⭐ 1 ⭐ 5 ⭐ 12 ⭐ 15 ⭐ 20 ⭐ 31 ⭐ 42 ⭐ 43 ⭐ 54 ⭐ 55 ⭐ 66 ⭐ 65 ⭐ 70 ⭐ 75 ⭐
              </textPath>
            </text>
            <text fill="url(#goldGrad)" fontSize="16" fontWeight="bold" letterSpacing="4">
              <textPath href="#subNumbersPath" startOffset="5%">
                ⭐ 17 ⭐ 18 ⭐ 19 ⭐ 24 ⭐ 23 ⭐ 25 ⭐ 26 ⭐ 27 ⭐ 28 ⭐ 39 ⭐ 30 ⭐ 73 ⭐ 73 ⭐ 75 ⭐
              </textPath>
            </text>
          </g>

          {/* Golden Separator Ring */}
          <circle cx="300" cy="300" r="202" fill="none" stroke="url(#goldGrad)" strokeWidth="4" />
          
          {/* Inner Dark Blue Border and Track */}
          <circle cx="300" cy="300" r="198" fill="none" stroke="#0D47A1" strokeWidth="6" />

          {/* Top text "BINGO" in golden arch */}
          <path id="topBingoPath" d="M 180,210 A 130,130 0 0,1 420,210" fill="none" />
          <text fill="url(#goldGrad)" fontSize="16" fontWeight="900" letterSpacing="18">
            <textPath href="#topBingoPath" startOffset="27%">BINGO</textPath>
          </text>

          {/* "አንድነት እና ደስታ" curved light blue ribbon and white text */}
          <path id="unityPath" d="M 160,250 A 142,142 0 0,1 440,250" fill="none" />
          {/* Light Blue Ribbon highlight path */}
          <path d="M 165,212 A 140,140 0 0,1 435,212" fill="none" stroke="#42A5F5" strokeWidth="24" strokeLinecap="round" opacity="0.85" />
          <text fill="#FFFFFF" fontSize="17" fontWeight="bold" letterSpacing="2">
            <textPath href="#unityPath" startOffset="24%">አንድነት እና ደስታ</textPath>
          </text>

          {/* Flanking Small Stars */}
          <g fill="url(#goldGrad)">
            {Array.from({ length: 12 }).map((_, i) => {
              const angle = 120 + i * 20;
              const rad = (angle * Math.PI) / 180;
              const x = 300 + 172 * Math.cos(rad);
              const y = 300 + 172 * Math.sin(rad);
              return (
                <path
                  key={i}
                  d="M0,-5 L1.5,-1.5 L5,0 L1.5,1.5 L0,5 L-1.5,1.5 L-5,0 L-1.5,-1.5 Z"
                  transform={`translate(${x}, ${y}) scale(1.2)`}
                />
              );
            })}
          </g>

          {/* Side Bingo Cards (Underneath balls) */}
          {/* Left Bingo Card */}
          <g transform="translate(150, 310) rotate(-22) scale(0.65)">
            <rect x="0" y="0" width="100" height="120" rx="6" fill="#FFCDD2" stroke="#B71C1C" strokeWidth="3" />
            <rect x="0" y="0" width="100" height="30" rx="6" fill="#D32F2F" />
            <text x="50" y="21" fill="white" fontSize="18" fontWeight="bold" textAnchor="middle">BIN</text>
            <line x1="0" y1="30" x2="100" y2="30" stroke="#B71C1C" strokeWidth="3" />
            {/* Grid Lines */}
            <line x1="33" y1="30" x2="33" y2="120" stroke="#B71C1C" strokeWidth="2" />
            <line x1="66" y1="30" x2="66" y2="120" stroke="#B71C1C" strokeWidth="2" />
            <line x1="0" y1="60" x2="100" y2="60" stroke="#B71C1C" strokeWidth="2" />
            <line x1="0" y1="90" x2="100" y2="90" stroke="#B71C1C" strokeWidth="2" />
            {/* Some marked cells */}
            <circle cx="16" cy="45" r="8" fill="#D32F2F" />
            <circle cx="83" cy="75" r="8" fill="#D32F2F" />
            <circle cx="50" cy="105" r="8" fill="#D32F2F" />
          </g>

          {/* Right Bingo Card */}
          <g transform="translate(380, 275) rotate(22) scale(0.65)">
            <rect x="0" y="0" width="100" height="120" rx="6" fill="#C8E6C9" stroke="#1B5E20" strokeWidth="3" />
            <rect x="0" y="0" width="100" height="30" rx="6" fill="#388E3C" />
            <text x="50" y="21" fill="white" fontSize="18" fontWeight="bold" textAnchor="middle">GO</text>
            <line x1="0" y1="30" x2="100" y2="30" stroke="#1B5E20" strokeWidth="3" />
            {/* Grid Lines */}
            <line x1="33" y1="30" x2="33" y2="120" stroke="#1B5E20" strokeWidth="2" />
            <line x1="66" y1="30" x2="66" y2="120" stroke="#1B5E20" strokeWidth="2" />
            <line x1="0" y1="60" x2="100" y2="60" stroke="#1B5E20" strokeWidth="2" />
            <line x1="0" y1="90" x2="100" y2="90" stroke="#1B5E20" strokeWidth="2" />
            {/* Some marked cells */}
            <circle cx="50" cy="45" r="8" fill="#388E3C" />
            <circle cx="16" cy="75" r="8" fill="#388E3C" />
            <circle cx="83" cy="105" r="8" fill="#388E3C" />
          </g>

          {/* Flanking mini bingo balls */}
          {/* Ball 15: Orange, top left */}
          <g transform="translate(225, 215)">
            <circle cx="0" cy="0" r="23" fill="url(#orangeBall)" stroke="url(#goldGrad)" strokeWidth="2" />
            <circle cx="0" cy="0" r="13" fill="#FFFFFF" />
            <text x="0" y="5" fill="#1A1A1A" fontSize="13" fontWeight="900" textAnchor="middle">15</text>
          </g>

          {/* Ball 42: Red, top right */}
          <g transform="translate(375, 215)">
            <circle cx="0" cy="0" r="23" fill="url(#redBall)" stroke="url(#goldGrad)" strokeWidth="2" />
            <circle cx="0" cy="0" r="13" fill="#FFFFFF" />
            <text x="0" y="5" fill="#1A1A1A" fontSize="13" fontWeight="900" textAnchor="middle">42</text>
          </g>

          {/* Ball 24: Blue, middle left */}
          <g transform="translate(220, 275)">
            <circle cx="0" cy="0" r="23" fill="url(#blueBall)" stroke="url(#goldGrad)" strokeWidth="2" />
            <circle cx="0" cy="0" r="13" fill="#FFFFFF" />
            <text x="0" y="5" fill="#1A1A1A" fontSize="13" fontWeight="900" textAnchor="middle">24</text>
          </g>

          {/* Ball 68: Green, middle right */}
          <g transform="translate(380, 275)">
            <circle cx="0" cy="0" r="23" fill="url(#greenBall)" stroke="url(#goldGrad)" strokeWidth="2" />
            <circle cx="0" cy="0" r="13" fill="#FFFFFF" />
            <text x="0" y="5" fill="#1A1A1A" fontSize="13" fontWeight="900" textAnchor="middle">68</text>
          </g>

          {/* Central Lucky Ball #7 with the Crown */}
          {/* 1. Golden Crown on top of Central Ball */}
          <g transform="translate(300, 185) scale(0.9)">
            {/* Crown Base */}
            <path d="M-35,15 L35,15 L25,35 L-25,35 Z" fill="url(#goldGrad)" stroke="#FF8F00" strokeWidth="1" />
            {/* Crown Spikes */}
            <path d="M-30,15 L-40,-15 L-10,5 L0,-25 L10,5 L40,-15 L30,15 Z" fill="url(#goldGrad)" stroke="#FF8F00" strokeWidth="1" />
            {/* Jewels on Peaks */}
            <circle cx="-40" cy="-15" r="4" fill="#FFFFFF" />
            <circle cx="0" cy="-25" r="5" fill="#E53935" />
            <circle cx="40" cy="-15" r="4" fill="#FFFFFF" />
            <circle cx="-20" cy="5" r="3" fill="#1E88E5" />
            <circle cx="20" cy="5" r="3" fill="#4CAF50" />
            {/* Velvet Arch insert */}
            <path d="M-25,15 C-25,5 25,5 25,15 Z" fill="#D32F2F" opacity="0.8" />
          </g>

          {/* 2. Central Ball #7 Sphere */}
          <circle cx="300" cy="255" r="52" fill="url(#ball7Grad)" stroke="url(#goldGrad)" strokeWidth="3" />
          <circle cx="300" cy="255" r="51" fill="none" stroke="#FFFFFF" strokeWidth="1.5" opacity="0.6" />
          {/* Inner White Ring */}
          <circle cx="300" cy="255" r="30" fill="#FFFFFF" />
          {/* Lucky 7 */}
          <text x="300" y="267" fill="#1A1A1A" fontSize="36" fontWeight="950" fontFamily="sans-serif" textAnchor="middle">7</text>

          {/* Beautiful Curved Amharic Title "የኛ ቢንጎ" */}
          <g transform="translate(300, 395)" filter="drop-shadow(0px 4px 6px rgba(0,0,0,0.8))">
            {/* Dark back outlines for 3D/Pop look */}
            <text x="0" y="0" fill="#2E0C00" fontSize="76" fontWeight="900" textAnchor="middle" stroke="#150500" strokeWidth="18" strokeLinejoin="round">
              የኛ ቢንጎ
            </text>
            <text x="0" y="0" fill="#FB8C00" fontSize="76" fontWeight="900" textAnchor="middle" stroke="#FFD54F" strokeWidth="4" strokeLinejoin="round">
              የኛ ቢንጎ
            </text>
            {/* Golden Gradient fill */}
            <text x="0" y="0" fill="url(#titleGold)" fontSize="76" fontWeight="900" textAnchor="middle">
              የኛ ቢንጎ
            </text>
          </g>

          {/* Bottom Banner with "yegna bingo" */}
          <g transform="translate(300, 460)">
            {/* Dark curved ribbon/badge */}
            <path d="M-150,-15 L150,-15 C170,-15 170,18 150,18 L-150,18 C-170,18 -170,-15 -150,-15 Z" fill="#0A1E3F" stroke="url(#goldGrad)" strokeWidth="2" />
            <text x="0" y="8" fill="#FFFFFF" fontSize="24" fontWeight="800" letterSpacing="2" textAnchor="middle" fontFamily="sans-serif">
              yegna bingo
            </text>
            {/* Tiny stars under the text */}
            <polygon points="0,-16 3,-10 9,-9 5,-4 6,2 0,-1 -6,2 -5,-4 -9,-9 -3,-10" fill="url(#goldGrad)" transform="translate(0, 24) scale(0.6)" />
            <polygon points="0,-16 3,-10 9,-9 5,-4 6,2 0,-1 -6,2 -5,-4 -9,-9 -3,-10" fill="url(#goldGrad)" transform="translate(-40, 24) scale(0.5)" />
            <polygon points="0,-16 3,-10 9,-9 5,-4 6,2 0,-1 -6,2 -5,-4 -9,-9 -3,-10" fill="url(#goldGrad)" transform="translate(40, 24) scale(0.5)" />
            {/* Crescent moon under the text */}
            <path d="M-12,32 A12,12 0 0,0 12,32 A10,10 0 0,1 -8,28" fill="url(#goldGrad)" transform="translate(0, 5)" />
          </g>
        </g>
      </svg>
    </div>
  );
};
