/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, User, Phone, CheckCircle, Shield, Smartphone, ExternalLink, Lock } from 'lucide-react';
import { YegnaLogo } from './YegnaLogo';

interface WelcomeScreenProps {
  onJoin: (data: { username: string; firstName: string; avatarUrl: string; customCoins?: number }) => void;
}

const PRESET_AVATARS = [
  '🦊', '🦁', '🦉', '🐨', '🐼', '🐯', '🐸', '🐙', '🦖', '🦄', '🐝', '🎨'
];

export default function WelcomeScreen({ onJoin }: WelcomeScreenProps) {
  const [username, setUsername] = useState('');
  const [firstName, setFirstName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('🦁');
  
  // Telegram status state
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifiedContact, setVerifiedContact] = useState<{ phone: string; name: string } | null>(null);
  const [isInTelegram, setIsInTelegram] = useState(false);

  // Load default usernames and detect environment
  useEffect(() => {
    const tg = (window as any).Telegram?.WebApp;
    if (tg && tg.initDataUnsafe && tg.initDataUnsafe.user) {
      setIsInTelegram(true);
      const user = tg.initDataUnsafe.user;
      const tgUsername = user.username || `player_${user.id}`;
      setUsername(tgUsername);
      setFirstName(user.first_name || 'Telegram Player');
      
      // Query server to check if this user has already registered via real bot contact-share!
      setIsVerifying(true);
      fetch(`/api/telegram/user/${user.id}`)
        .then(res => res.json())
        .then(data => {
          if (data.registered && data.contact) {
            setVerifiedContact({
              phone: data.contact.phone,
              name: data.contact.name
            });
            // Automatically log them in with their 10 Birr welcome registration bonus!
            setTimeout(() => {
              onJoin({
                username: tgUsername.toLowerCase(),
                firstName: `${data.contact.name} 🇪🇹`,
                avatarUrl: selectedAvatar || '🦁',
                customCoins: 10
              });
            }, 1000);
          } else {
            // Check by username as a fallback if user.username is available
            if (user.username) {
              fetch(`/api/telegram/user/${user.username}`)
                .then(r => r.json())
                .then(d => {
                  if (d.registered && d.contact) {
                    setVerifiedContact({
                      phone: d.contact.phone,
                      name: d.contact.name
                    });
                    setTimeout(() => {
                      onJoin({
                        username: tgUsername.toLowerCase(),
                        firstName: `${d.contact.name} 🇪🇹`,
                        avatarUrl: selectedAvatar || '🦁',
                        customCoins: 10
                      });
                    }, 1000);
                  } else {
                    // Automatically join as guest so they only register 1 time!
                    setTimeout(() => {
                      onJoin({
                        username: tgUsername.toLowerCase(),
                        firstName: user.first_name || 'Telegram Player',
                        avatarUrl: selectedAvatar || '🦁',
                        customCoins: 10
                      });
                    }, 1000);
                  }
                })
                .catch(() => {
                  setTimeout(() => {
                    onJoin({
                      username: tgUsername.toLowerCase(),
                      firstName: user.first_name || 'Telegram Player',
                      avatarUrl: selectedAvatar || '🦁',
                      customCoins: 10
                    });
                  }, 1000);
                });
            } else {
              setTimeout(() => {
                onJoin({
                  username: tgUsername.toLowerCase(),
                  firstName: user.first_name || 'Telegram Player',
                  avatarUrl: selectedAvatar || '🦁',
                  customCoins: 10
                });
              }, 1000);
            }
          }
        })
        .catch(() => {
          setTimeout(() => {
            onJoin({
              username: tgUsername.toLowerCase(),
              firstName: user.first_name || 'Telegram Player',
              avatarUrl: selectedAvatar || '🦁',
              customCoins: 10
            });
          }, 1000);
        });
    } else {
      setIsInTelegram(false);
      const names = ['LuckyDauber', 'GoldRunner', 'HabeshaPro', 'BingoKing', 'CoinMaster'];
      const randName = names[Math.floor(Math.random() * names.length)];
      setFirstName(randName);
      setUsername(randName.toLowerCase());
    }
  }, []);

  const handleSubmitCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim()) return;

    onJoin({
      username: username.trim() || firstName.toLowerCase().replace(/\s+/g, '_'),
      firstName: firstName.trim(),
      avatarUrl: selectedAvatar,
      customCoins: 10 // Standard starting coins for web guest/testing
    });
  };

  const handleStartGameVerified = () => {
    if (verifiedContact) {
      onJoin({
        username: username.toLowerCase(),
        firstName: `${verifiedContact.name} 🇪🇹`,
        avatarUrl: selectedAvatar,
        customCoins: 10
      });
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] p-4 text-slate-100 relative" id="welcome_container">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-fade-in" id="welcome_card">
        
        {/* Top Header Section */}
        <div className="bg-slate-950 p-6 text-center border-b border-b-slate-850/80 space-y-2 flex flex-col items-center justify-center">
          <YegnaLogo size={180} className="mb-2 animate-bounce-slow" />
          <h1 className="text-2xl font-black tracking-wider text-slate-100 uppercase">
            YEGNA BINGO<span className="text-indigo-400 text-sm ml-1">TMA</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-[280px] mx-auto leading-relaxed">
            ኢትዮጵያ የመጀመሪያው እና ትልቁ የሁለገብ ተጫዋቾች (Multiplayer) የቢንጎ ጨዋታ።
          </p>
        </div>

        {/* Dynamic Display based on context */}
        <div className="p-6 space-y-6">
          
          {isInTelegram ? (
            <div className="space-y-5 animate-fade-in" id="telegram_webapp_panel">
              {isVerifying ? (
                <div className="bg-slate-950/60 rounded-xl border border-slate-850 p-6 text-center space-y-4 shadow-inner">
                  <div className="flex items-center justify-center">
                    <div className="w-8 h-8 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-indigo-400">ምዝገባዎን በማረጋገጥ ላይ...</h3>
                    <p className="text-[11px] text-slate-400">Verifying Telegram registration status...</p>
                  </div>
                </div>
              ) : verifiedContact ? (
                <div className="space-y-5">
                  <div className="bg-emerald-950/40 rounded-xl border border-emerald-500/20 p-5 text-center space-y-3 shadow-inner">
                    <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-400">
                      <CheckCircle className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-base font-black text-emerald-400">በተሳካ ሁኔታ ተመዝግበዋል!</h3>
                      <p className="text-xs text-slate-300">Welcome, <b>{verifiedContact.name}</b> 🇪🇹</p>
                      <p className="text-[11px] text-slate-400 font-mono mt-1">📱 Phone: {verifiedContact.phone}</p>
                    </div>
                  </div>

                  <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-850 text-left">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400">የምዝገባ ጉርሻ (Bonus):</span>
                      <span className="text-emerald-400 font-bold">+10 Birr/ሳንቲም 🎁</span>
                    </div>
                  </div>

                  <button
                    onClick={handleStartGameVerified}
                    className="w-full flex items-center justify-center gap-2 py-4 bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-emerald-500/10 transition-all hover:scale-[1.01]"
                  >
                    <span>🎮 መጫወት ጀምር (Start Playing)</span>
                    <ArrowRight className="w-4 h-4 text-slate-950" />
                  </button>
                </div>
              ) : (
                <div className="space-y-5 text-center">
                  <div className="bg-amber-950/20 rounded-xl border border-amber-500/20 p-5 space-y-3 shadow-inner">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-500/10 text-amber-500">
                      <Lock className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-sm font-black text-amber-400 uppercase tracking-wider">⚠️ ምዝገባ ያስፈልጋል (Registration Required)</h3>
                      <p className="text-xs text-slate-300 leading-relaxed pt-1">
                        በየኛ ቢንጎ ለመጫወት እና የ <b>10 Birr/ሳንቲም</b> ነፃ የምዝገባ ጉርሻ ለመቀበል እባክዎ መጀመሪያ በቴሌግራም ቦቱ ይመዝገቡ።
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-950/50 p-5 rounded-xl border border-slate-850 text-left space-y-3 text-xs leading-relaxed">
                    <p className="font-bold text-indigo-400 text-center border-b border-slate-850 pb-2">እንዴት መመዝገብ እችላለሁ?</p>
                    <ol className="list-decimal list-inside space-y-2.5 text-slate-300 pl-1">
                      <li>ይህንን ዌብ አፕሊኬሽን ከላይ ባለው <b>✕</b> ይዝጉት።</li>
                      <li>በቦቱ ቻት መነሻ ገጽ ላይ የሚመጣውን <b>📱 ስልክ ቁጥርዎን ያጋሩ (Share Contact)</b> የሚለውን አረንጓዴ ቁልፍ ይጫኑ።</li>
                      <li>በተሳካ ሁኔታ ከተመዘገቡ በኋላ መልሰው <b>🎮 ይጫወቱ</b> የሚለውን ቁልፍ በመንካት ጨዋታውን መጫወት ይችላሉ!</li>
                    </ol>
                  </div>

                  <div className="p-3 bg-indigo-950/10 rounded-lg border border-indigo-500/10 text-[10px] text-slate-400 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-indigo-500 shrink-0" />
                    <span>የእርስዎ ስልክ ቁጥር በጥብቅ የተጠበቀ ሲሆን ለጨዋታው ማንነት ማረጋገጫ ብቻ ያገለግላል።</span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-5 animate-fade-in" id="web_guest_panel">
              
              {/* Informative Telegram Bot Banner */}
              <div className="bg-indigo-950/30 rounded-xl border border-indigo-500/20 p-4 text-center space-y-2">
                <div className="flex items-center justify-center gap-2 text-indigo-400 font-black text-xs uppercase tracking-wider">
                  <Smartphone className="w-4 h-4" />
                  <span>Yegna Bingo Telegram Bot</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  በቴሌግራም ቦት ላይ በመጫወት እና ስልክዎን በማጋራት የ <b>10 Birr/ሳንቲም</b> ነፃ የምዝገባ ቦነስ ያግኙ!
                </p>
                <a
                  href="https://t.me/yegna_bingo_bot"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] uppercase tracking-wider rounded-lg transition-colors mt-1"
                >
                  <span>ወደ ቴሌግራም ቦት ይሂዱ</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Guest Login Form for Testing in Preview */}
              <form onSubmit={handleSubmitCustom} className="space-y-5 text-left" id="custom_reg_form">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-wider text-center border-b border-slate-850 pb-2">
                  🧪 Tester Guest Access (የሙከራ መግቢያ)
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                      የቅጽል ስም (Dauber Nickname)
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        value={firstName}
                        onChange={(e) => {
                          setFirstName(e.target.value);
                          setUsername(e.target.value.toLowerCase().replace(/\s+/g, '_'));
                        }}
                        placeholder="የእርስዎን ስም ያስገቡ"
                        maxLength={18}
                        className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-850 rounded-xl focus:outline-none focus:border-indigo-500 text-slate-100 font-semibold text-sm transition-colors"
                      />
                      <User className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-6 bg-indigo-500 hover:bg-indigo-400 active:bg-indigo-600 text-white font-black uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-500/20 transition-all"
                >
                  <span>ወደ ጨዋታው ግባ (Enter Game)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}

          <div className="text-center pt-2">
            <div className="inline-flex items-center gap-1.5 text-[10px] text-slate-500 bg-slate-950 border border-slate-850/60 px-3 py-1.5 rounded-full">
              <Sparkles className="w-3 h-3 text-indigo-400 animate-pulse" />
              <span>Yegna Server State: Live 🟢</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
