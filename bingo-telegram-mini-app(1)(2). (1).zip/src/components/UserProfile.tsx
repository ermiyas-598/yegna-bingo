/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Award, Check, Save, ShieldCheck, Flame, Calendar } from 'lucide-react';
import { Player } from '../types';

interface UserProfileProps {
  player: Player | null;
  onUpdateProfile: (firstName: string, avatarUrl: string) => void;
}

const AVATAR_POOL = [
  { char: '🦁', label: 'Ethiopian Lion' },
  { char: '🦅', label: 'Abyssinian Eagle' },
  { char: '🕊️', label: 'Selam Dove' },
  { char: '☕', label: 'Buna Cup' },
  { char: '👑', label: 'Negus Crown' },
  { char: '🦊', label: 'Simien Fox' },
  { char: '💎', label: 'Almaz Diamond' },
  { char: '🥑', label: 'Mahlet Avocado' },
];

export default function UserProfile({ player, onUpdateProfile }: UserProfileProps) {
  const [firstName, setFirstName] = useState(player?.firstName || '');
  const [selectedAvatar, setSelectedAvatar] = useState(player?.avatarUrl || '🦁');
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (player) {
      setFirstName(player.firstName);
      setSelectedAvatar(player.avatarUrl);
    }
  }, [player]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim()) return;
    onUpdateProfile(firstName.trim(), selectedAvatar);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  // Calculate user Rank/Title based on wallet balance
  const getRankTitle = (coins: number) => {
    if (coins >= 1000) return '🏆 Platinum Negus';
    if (coins >= 500) return '🥇 Golden Emperor';
    if (coins >= 200) return '🥈 Silver Noble';
    return '🥉 Bronze Dauber';
  };

  // Real stats tracked locally from gameplay!
  const [stats, setStats] = useState({
    gamesPlayed: 0,
    gamesWon: 0,
    bestWinningStreak: 0,
    joinDate: 'July 2026',
  });

  useEffect(() => {
    const localStats = localStorage.getItem('habesha_bingo_stats');
    if (localStats) {
      try {
        setStats(JSON.parse(localStats));
      } catch (e) {}
    } else {
      const initialStats = {
        gamesPlayed: 0,
        gamesWon: 0,
        bestWinningStreak: 0,
        joinDate: 'July 2026',
      };
      localStorage.setItem('habesha_bingo_stats', JSON.stringify(initialStats));
      setStats(initialStats);
    }
  }, []);

  return (
    <div className="space-y-6 animate-fade-in" id="profile_page_section">
      {/* Upper Badge Banner */}
      <div className="bg-gradient-to-r from-indigo-950 to-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl flex flex-col sm:flex-row items-center gap-5">
        <div className="relative">
          <div className="w-20 h-20 bg-indigo-500/10 border-2 border-indigo-500 rounded-full flex items-center justify-center shadow-inner shadow-indigo-500/10">
            <User className="w-8 h-8 text-indigo-400" />
          </div>
          <span className="absolute -bottom-1 -right-1 bg-emerald-500 border-2 border-slate-950 w-5 h-5 rounded-full flex items-center justify-center text-[10px] text-white">
            ✓
          </span>
        </div>

        <div className="text-center sm:text-left space-y-1 flex-1">
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full inline-block">
            {getRankTitle(player?.coins || 0)}
          </span>
          <h2 className="text-xl font-black text-slate-100">
            {player?.firstName || 'Anonymous'}
          </h2>
          <p className="text-xs text-slate-400 flex items-center justify-center sm:justify-start gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            Verified Yegna Bingo account • ID: @{player?.username}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Settings Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-5 space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <User className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-200">
              Edit Dauber Identity
            </h3>
          </div>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
                Display Name
              </label>
              <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                maxLength={18}
                required
                className="w-full py-2.5 px-4 bg-slate-950 border border-slate-850 rounded-xl focus:outline-none focus:border-indigo-500 text-xs text-slate-100 font-bold"
                placeholder="Enter your name"
              />
            </div>

            <button
              type="submit"
              className={`w-full py-3 px-5 rounded-xl font-black uppercase tracking-wider text-xs transition-all flex items-center justify-center gap-2 ${
                isSaved
                  ? 'bg-emerald-500 text-white shadow-emerald-500/10'
                  : 'bg-indigo-500 hover:bg-indigo-400 text-white shadow-indigo-500/10'
              }`}
            >
              {isSaved ? (
                <>
                  <Check className="w-4 h-4 animate-ping" />
                  Profile Saved Successfully!
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Save Identity
                </>
              )}
            </button>
          </form>
        </div>

        {/* Daubing Performance Statistics */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Award className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-200">
              Live Daubing Records
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Stat 1 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 text-center space-y-1">
              <span className="text-[9px] uppercase tracking-wider text-slate-500 font-extrabold block">
                Total Games
              </span>
              <span className="text-xl font-black text-slate-200 font-mono">
                {stats.gamesPlayed}
              </span>
            </div>

            {/* Stat 2 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 text-center space-y-1">
              <span className="text-[9px] uppercase tracking-wider text-slate-500 font-extrabold block">
                Bingo Wins
              </span>
              <span className="text-xl font-black text-emerald-400 font-mono">
                {stats.gamesWon}
              </span>
            </div>

            {/* Stat 3 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 text-center space-y-1">
              <span className="text-[9px] uppercase tracking-wider text-slate-500 font-extrabold block">
                Win Rate
              </span>
              <span className="text-xl font-black text-indigo-300 font-mono">
                {Math.round((stats.gamesWon / stats.gamesPlayed) * 100)}%
              </span>
            </div>

            {/* Stat 4 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 text-center space-y-1">
              <span className="text-[9px] uppercase tracking-wider text-slate-500 font-extrabold block">
                Best Streak
              </span>
              <span className="text-xl font-black text-pink-400 font-mono flex items-center justify-center gap-1">
                <Flame className="w-4 h-4 text-pink-500 animate-pulse" />
                {stats.bestWinningStreak}
              </span>
            </div>
          </div>

          <div className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5 font-semibold">
              <Calendar className="w-3.5 h-3.5 text-slate-500" />
              Member Since
            </span>
            <span className="font-extrabold text-slate-300">{stats.joinDate}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
