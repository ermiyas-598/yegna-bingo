/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Coins, CreditCard, ArrowUpRight, ArrowDownLeft, 
  Smartphone, Building, CheckCircle, RefreshCw, X, AlertCircle
} from 'lucide-react';

interface UserWalletProps {
  currentBalance: number;
  onUpdateCoins: (newCoins: number) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'winnings' | 'ticket';
  amount: number;
  method?: string;
  status: 'completed' | 'pending' | 'failed';
  timestamp: number;
  description: string;
}

const POPULAR_PAYMENTS = [
  { id: 'telebirr', name: 'Telebirr 📱', desc: 'Instant mobile money transfer', color: 'bg-[#009ee0]/10 border-[#009ee0]/30 text-[#009ee0]' },
  { id: 'cbe', name: 'CBE Birr 🏦', desc: 'Commercial Bank of Ethiopia', color: 'bg-[#5e1914]/10 border-[#5e1914]/30 text-[#eeb317]' },
  { id: 'chapa', name: 'Chapa 💳', desc: 'Card and mobile banking', color: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' },
];

export default function UserWallet({ currentBalance, onUpdateCoins, showToast }: UserWalletProps) {
  const [activeSubTab, setActiveSubTab] = useState<'deposit' | 'withdraw' | 'history'>('deposit');
  const [depositAmount, setDepositAmount] = useState('200');
  const [withdrawAmount, setWithdrawAmount] = useState('500');
  const [paymentMethod, setPaymentMethod] = useState('telebirr');
  const [accountNumber, setAccountNumber] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // Load transaction ledger from localstorage
  useEffect(() => {
    const saved = localStorage.getItem('habesha_bingo_tx');
    if (saved) {
      try {
        setTransactions(JSON.parse(saved));
      } catch (e) {}
    } else {
      const defaultTx: Transaction[] = [
        {
          id: 'tx_init',
          type: 'deposit',
          amount: 1000,
          method: 'Welcome Gift 🎁',
          status: 'completed',
          timestamp: Date.now() - 3600000 * 2,
          description: 'Amanuel Welcome Bonus',
        }
      ];
      setTransactions(defaultTx);
      localStorage.setItem('habesha_bingo_tx', JSON.stringify(defaultTx));
    }
  }, []);

  const saveTransactions = (newTx: Transaction[]) => {
    setTransactions(newTx);
    localStorage.setItem('habesha_bingo_tx', JSON.stringify(newTx));
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      showToast('Please enter a valid deposit amount', 'error');
      return;
    }

    setIsLoading(true);

    // Simulate transfer check time
    setTimeout(() => {
      const methodLabel = POPULAR_PAYMENTS.find(p => p.id === paymentMethod)?.name || 'Direct Transfer';
      const updatedBalance = currentBalance + amount;
      onUpdateCoins(updatedBalance);

      const newTx: Transaction = {
        id: `tx_${Math.random().toString(36).substring(2, 9)}`,
        type: 'deposit',
        amount,
        method: methodLabel,
        status: 'completed',
        timestamp: Date.now(),
        description: `Deposited via ${methodLabel}`,
      };

      saveTransactions([newTx, ...transactions]);
      setIsLoading(false);
      setDepositAmount('200');
      showToast(`Deposited ${amount} Birr successfully! 🇪🇹`, 'success');
    }, 1500);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      showToast('Please enter a valid withdrawal amount', 'error');
      return;
    }

    if (amount > currentBalance) {
      showToast('Insufficient balance for this withdrawal amount!', 'error');
      return;
    }

    if (!accountNumber.trim()) {
      showToast('Please enter a transfer account phone or number', 'error');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const methodLabel = POPULAR_PAYMENTS.find(p => p.id === paymentMethod)?.name || 'Direct Transfer';
      const updatedBalance = currentBalance - amount;
      onUpdateCoins(updatedBalance);

      const newTx: Transaction = {
        id: `tx_${Math.random().toString(36).substring(2, 9)}`,
        type: 'withdrawal',
        amount,
        method: methodLabel,
        status: 'completed',
        timestamp: Date.now(),
        description: `Withdrawn to ${accountNumber}`,
      };

      saveTransactions([newTx, ...transactions]);
      setIsLoading(false);
      setWithdrawAmount('500');
      setAccountNumber('');
      showToast(`Withdrew ${amount} Birr successfully to ${accountNumber}!`, 'success');
    }, 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="wallet_page_section">
      {/* Visual Balance Card */}
      <div className="bg-slate-900 border border-slate-850 p-6 rounded-2xl shadow-xl flex justify-between items-center relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none text-9xl">
          🪙
        </div>
        <div className="space-y-2 z-10">
          <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500 flex items-center gap-1">
            <Coins className="w-3.5 h-3.5 text-indigo-400" />
            Active Balance
          </span>
          <div className="space-y-0.5">
            <h2 className="text-3xl font-black text-indigo-300 font-mono leading-none">
              {currentBalance.toLocaleString()} <span className="text-sm font-black text-slate-400">ETB</span>
            </h2>
            <p className="text-[10px] text-slate-400">
              Safe & Secure Ethiopian Birr Gateway
            </p>
          </div>
        </div>
      </div>

      {/* Sub Tabs: Deposit / Withdraw / History */}
      <div className="bg-slate-900 border border-slate-800 p-1.5 rounded-2xl flex" id="wallet_tab_bar">
        {['deposit', 'withdraw', 'history'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveSubTab(tab as any)}
            className={`flex-1 py-3 px-3 rounded-xl font-black uppercase tracking-wider text-[10px] transition-all ${
              activeSubTab === tab
                ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab === 'deposit' && '💳 Deposit'}
            {tab === 'withdraw' && '📤 Withdraw'}
            {tab === 'history' && '📜 Ledger'}
          </button>
        ))}
      </div>

      {/* Forms Area */}
      {activeSubTab === 'deposit' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl animate-fade-in">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-200">
              Deposit Funds Instantly
            </h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Refill your account coins using leading instant transfer options in Ethiopia.
            </p>
          </div>

          <form onSubmit={handleDepositSubmit} className="space-y-4">
            {/* Amount input */}
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
                Amount (ETB / Birr)
              </label>
              <div className="grid grid-cols-4 gap-2">
                {['100', '200', '500', '1000'].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setDepositAmount(val)}
                    className={`py-2 px-3 border rounded-xl font-mono text-xs font-extrabold transition-all ${
                      depositAmount === val
                        ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300 ring-1 ring-indigo-500/30'
                        : 'bg-slate-950 border-slate-850 text-slate-400 hover:bg-slate-900'
                    }`}
                  >
                    {val} ETB
                  </button>
                ))}
              </div>
              <input
                type="number"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                required
                min={10}
                max={50000}
                className="w-full mt-2 py-2.5 px-4 bg-slate-950 border border-slate-850 rounded-xl focus:outline-none focus:border-indigo-500 text-xs text-slate-100 font-bold"
                placeholder="Custom Amount"
              />
            </div>

            {/* Provider Grid */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block">
                Choose Payment Gateway
              </label>
              <div className="grid gap-2">
                {POPULAR_PAYMENTS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPaymentMethod(p.id)}
                    className={`p-4 border rounded-2xl text-left transition-all flex items-center justify-between ${
                      paymentMethod === p.id
                        ? 'bg-indigo-500/10 border-indigo-500 ring-1 ring-indigo-500/30'
                        : 'bg-slate-950 border-slate-850 hover:bg-slate-900'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <span className="font-black text-xs text-slate-100">{p.name}</span>
                      <span className="block text-[10px] text-slate-400">{p.desc}</span>
                    </div>
                    <span className={`text-[10px] px-2.5 py-1 rounded-full font-extrabold uppercase ${p.color}`}>
                      {paymentMethod === p.id ? 'Active' : 'Select'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 px-5 bg-indigo-500 hover:bg-indigo-400 disabled:bg-slate-950 disabled:text-slate-600 disabled:cursor-not-allowed text-white font-black uppercase tracking-wider text-xs rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/10"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Authorizing Gateway Connection...
                </>
              ) : (
                <>
                  <ArrowUpRight className="w-4 h-4" />
                  Simulate Deposit ({depositAmount} Birr)
                </>
              )}
            </button>
          </form>
        </div>
      )}

      {activeSubTab === 'withdraw' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl animate-fade-in">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-200">
              Withdraw Earnings Safely
            </h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Transfer your prize Birr back to your local mobile wallet or bank account instantly.
            </p>
          </div>

          <form onSubmit={handleWithdrawSubmit} className="space-y-4">
            {/* Amount input */}
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
                Amount (ETB / Birr)
              </label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                required
                min={50}
                max={currentBalance}
                className="w-full py-2.5 px-4 bg-slate-950 border border-slate-850 rounded-xl focus:outline-none focus:border-indigo-500 text-xs text-slate-100 font-bold"
                placeholder="Withdraw Amount"
              />
              <span className="block text-[10px] text-slate-500 font-bold text-right">
                Max withdrawable: {currentBalance.toLocaleString()} ETB
              </span>
            </div>

            {/* Provider Grid */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block">
                Withdrawal Destination
              </label>
              <div className="grid gap-2">
                {POPULAR_PAYMENTS.slice(0, 2).map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPaymentMethod(p.id)}
                    className={`p-4 border rounded-2xl text-left transition-all flex items-center justify-between ${
                      paymentMethod === p.id
                        ? 'bg-indigo-500/10 border-indigo-500 ring-1 ring-indigo-500/30'
                        : 'bg-slate-950 border-slate-850 hover:bg-slate-900'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <span className="font-black text-xs text-slate-100">{p.name}</span>
                      <span className="block text-[10px] text-slate-400">{p.desc}</span>
                    </div>
                    <span className={`text-[10px] px-2.5 py-1 rounded-full font-extrabold uppercase ${p.color}`}>
                      {paymentMethod === p.id ? 'Selected' : 'Select'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Phone/Account Number input */}
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
                {paymentMethod === 'telebirr' ? 'Mobile Phone Number (+251...)' : 'CBE Account Number (1000...)'}
              </label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                required
                className="w-full py-2.5 px-4 bg-slate-950 border border-slate-850 rounded-xl focus:outline-none focus:border-indigo-500 text-xs text-slate-100 font-bold"
                placeholder={paymentMethod === 'telebirr' ? 'e.g., 0912345678' : 'e.g., 1000123456789'}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || currentBalance < 50}
              className="w-full py-3.5 px-5 bg-indigo-500 hover:bg-indigo-400 disabled:bg-slate-950 disabled:text-slate-600 disabled:cursor-not-allowed text-white font-black uppercase tracking-wider text-xs rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/10"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Processing Safe Settlement...
                </>
              ) : (
                <>
                  <ArrowDownLeft className="w-4 h-4" />
                  Initiate Secure Withdrawal
                </>
              )}
            </button>
          </form>
        </div>
      )}

      {activeSubTab === 'history' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl animate-fade-in">
          <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-200">
              Simulated Ledger History
            </h3>
            <span className="text-[9px] font-extrabold bg-slate-950 px-2 py-0.5 rounded text-slate-500">
              Total {transactions.length} items
            </span>
          </div>

          <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
            {transactions.length === 0 ? (
              <p className="text-center text-slate-500 italic text-xs py-8">
                No transactions recorded yet.
              </p>
            ) : (
              transactions.map((tx) => (
                <div 
                  key={tx.id}
                  className="flex items-center justify-between p-3.5 bg-slate-950 border border-slate-850 rounded-xl transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl border ${
                      tx.type === 'deposit' || tx.type === 'winnings'
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                    }`}>
                      {tx.type === 'deposit' || tx.type === 'winnings' ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <ArrowDownLeft className="w-4 h-4" />
                      )}
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-xs font-black text-slate-100 block">
                        {tx.description}
                      </span>
                      <span className="text-[9px] text-slate-500 font-mono block">
                        {new Date(tx.timestamp).toLocaleString()}
                      </span>
                    </div>
                  </div>
                  <div className="text-right space-y-0.5">
                    <span className={`text-xs font-black font-mono block ${
                      tx.type === 'deposit' || tx.type === 'winnings' ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {tx.type === 'deposit' || tx.type === 'winnings' ? '+' : '-'}{tx.amount} Birr
                    </span>
                    <span className="text-[8px] uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-extrabold">
                      Success
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
