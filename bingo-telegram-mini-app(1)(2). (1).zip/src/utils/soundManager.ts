/**
 * Habesha Bingo Sound Manager Utility
 * Web Audio API based Synthesizer
 * 
 * Supports:
 * - Persistent BGM & SFX settings in localStorage
 * - Soft, beautiful lofi ambient background music loop
 * - High-fidelity retro sound effects (Daub, Win Fanfare, Loss, Ball Draw, Button Click)
 * - Lazy initialisation to comply with browser audio policies
 */

class SoundManager {
  private bgmEnabled: boolean = true;
  private sfxEnabled: boolean = true;
  private audioCtx: AudioContext | null = null;
  private bgmIntervalId: any = null;
  private bgmTick: number = 0;
  private currentBgmGainNode: GainNode | null = null;

  constructor() {
    // Load persisted configurations from localStorage
    if (typeof window !== 'undefined') {
      const savedBgm = localStorage.getItem('habesha_bingo_bgm');
      const savedSfx = localStorage.getItem('habesha_bingo_sfx');
      this.bgmEnabled = savedBgm !== null ? savedBgm === 'true' : true;
      this.sfxEnabled = savedSfx !== null ? savedSfx === 'true' : true;
    }
  }

  private initCtx(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        this.audioCtx = new AudioContextClass();
      } catch (e) {
        console.error('Web Audio API not supported', e);
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  public getBgmEnabled(): boolean {
    return this.bgmEnabled;
  }

  public getSfxEnabled(): boolean {
    return this.sfxEnabled;
  }

  public initialize(): void {
    this.initCtx();
    if (this.bgmEnabled) {
      this.startBGM();
    }
  }

  public toggleBGM(): boolean {
    this.bgmEnabled = !this.bgmEnabled;
    localStorage.setItem('habesha_bingo_bgm', String(this.bgmEnabled));
    this.initCtx();
    
    if (this.bgmEnabled) {
      this.startBGM();
    } else {
      this.stopBGM();
    }
    return this.bgmEnabled;
  }

  public toggleSFX(): boolean {
    this.sfxEnabled = !this.sfxEnabled;
    localStorage.setItem('habesha_bingo_sfx', String(this.sfxEnabled));
    this.initCtx();
    return this.sfxEnabled;
  }

  // --- BACKGROUND MUSIC ENGINE (የጀርባ ሙዚቃ) ---
  // Loops a cozy, lofi pentatonic chord/melody sequence
  public startBGM(): void {
    this.stopBGM();
    const ctx = this.initCtx();
    if (!ctx || !this.bgmEnabled) return;

    this.bgmTick = 0;
    
    // Create an overall master volume gain for the music
    try {
      this.currentBgmGainNode = ctx.createGain();
      this.currentBgmGainNode.gain.setValueAtTime(0.005, ctx.currentTime); // Low volume ambient
      this.currentBgmGainNode.connect(ctx.destination);
    } catch (e) {
      console.error(e);
      return;
    }

    // Progression: C Maj9 -> Am7 -> F Maj9 -> G6 (C, Am, F, G but cute)
    const chords = [
      [130.81, 164.81, 196.00, 246.94], // C3, E3, G3, B3 (Cmaj7)
      [110.00, 146.83, 174.61, 220.00], // A2, D3, F3, A3 (Dm7/A)
      [87.31, 130.81, 174.61, 218.27],  // F2, C3, F3, A3 (Fmaj7)
      [98.00, 146.83, 196.00, 246.94]   // G2, D3, G3, B3 (G)
    ];

    const melodyNotes = [
      [261.63, 293.66, 329.63, 392.00], // C4, D4, E4, G4
      [220.00, 261.63, 293.66, 349.23], // A3, C4, D4, F4
      [349.23, 392.00, 440.00, 523.25], // F4, G4, A4, C5
      [293.66, 329.63, 392.00, 493.88]  // D4, E4, G4, B4
    ];

    // Tick every 600ms for a gentle lofi tempo (100 BPM)
    this.bgmIntervalId = setInterval(() => {
      const currentCtx = this.initCtx();
      if (!currentCtx || currentCtx.state === 'suspended' || !this.bgmEnabled) return;

      const chordIndex = Math.floor(this.bgmTick / 4) % chords.length;
      const subTick = this.bgmTick % 4; // 0, 1, 2, 3 inside the bar

      // Play chord pad on beat 0
      if (subTick === 0) {
        const chord = chords[chordIndex];
        chord.forEach((freq) => {
          this.playBgmNode(freq, 0.005, 2.2, 'triangle');
        });
      }

      // Play a cute ambient melody note on beats 1 and 3
      if (subTick === 1 || subTick === 3) {
        const notes = melodyNotes[chordIndex];
        const randomNote = notes[Math.floor(Math.random() * notes.length)];
        this.playBgmNode(randomNote, 0.008, 0.8, 'sine');
      }

      // Add a tiny bass accent on beat 2
      if (subTick === 2) {
        const rootFreq = chords[chordIndex][0] / 2; // Octave lower root
        this.playBgmNode(rootFreq, 0.012, 1.2, 'triangle');
      }

      this.bgmTick++;
    }, 600);
  }

  private playBgmNode(freq: number, volume: number, duration: number, type: 'sine' | 'triangle' | 'sawtooth' | 'square'): void {
    const ctx = this.audioCtx;
    const dest = this.currentBgmGainNode;
    if (!ctx || !dest || !this.bgmEnabled) return;

    try {
      const osc = ctx.createOscillator();
      const nodeGain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      nodeGain.gain.setValueAtTime(0, ctx.currentTime);
      nodeGain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.1); // Attack
      nodeGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration); // Release

      osc.connect(nodeGain);
      nodeGain.connect(dest);
      
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {}
  }

  public stopBGM(): void {
    if (this.bgmIntervalId) {
      clearInterval(this.bgmIntervalId);
      this.bgmIntervalId = null;
    }
    if (this.currentBgmGainNode) {
      try {
        this.currentBgmGainNode.disconnect();
      } catch (e) {}
      this.currentBgmGainNode = null;
    }
  }

  // --- SOUND EFFECTS ENGINE (የጨዋታ ድምፆች) ---

  // Satisfying rapid blip when daubing a valid tile
  public playDaub(): void {
    if (!this.sfxEnabled) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      // Fast upward chirp
      osc.frequency.setValueAtTime(350, now);
      osc.frequency.exponentialRampToValueAtTime(950, now + 0.08);

      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(now + 0.12);
    } catch (e) {}
  }

  // Melodic, fast triple-blip click
  public playClick(): void {
    if (!this.sfxEnabled) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      gain.gain.setValueAtTime(0.03, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(now + 0.06);
    } catch (e) {}
  }

  // Retro sci-fi sweep when a new ball is drawn + Amharic vocal number caller!
  public playBall(num?: number): void {
    if (!this.sfxEnabled) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.linearRampToValueAtTime(220, now + 0.15); // Drop slide

      gain.gain.setValueAtTime(0.02, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(now + 0.2);
    } catch (e) {}

    // Synthesize Amharic speech call for the drawn number!
    if (num !== undefined) {
      const prefix = this.getBallPrefix(num);
      const amhPrefix = this.getAmharicPrefix(prefix);
      const amhNum = this.getAmharicNumberWords(num);
      const spokenText = `${amhPrefix} ${amhNum}`;
      this.speakAmharic(spokenText);
    }
  }

  private getBallPrefix(num: number): string {
    if (num >= 1 && num <= 15) return 'B';
    if (num >= 16 && num <= 30) return 'I';
    if (num >= 31 && num <= 45) return 'N';
    if (num >= 46 && num <= 60) return 'G';
    if (num >= 61 && num <= 75) return 'O';
    return '';
  }

  private getAmharicPrefix(prefix: string): string {
    switch (prefix.toUpperCase()) {
      case 'B': return 'ቢ';
      case 'I': return 'አይ';
      case 'N': return 'ኤን';
      case 'G': return 'ጂ';
      case 'O': return 'ኦ';
      default: return '';
    }
  }

  private getAmharicNumberWords(num: number): string {
    if (num === 0) return '';
    if (num <= 10) {
      const ones = ['', 'አንድ', 'ሁለት', 'ሶስት', 'አራት', 'አምስት', 'ስድስት', 'ሰባት', 'ስምንት', 'ዘጠኝ', 'አስር'];
      return ones[num];
    }
    if (num < 20) {
      const ones = ['', 'አንድ', 'ሁለት', 'ሶስት', 'አራት', 'አምስት', 'ስድስት', 'ሰባት', 'ስምንት', 'ዘጠኝ'];
      return 'አስራ ' + ones[num - 10];
    }
    
    const tensVal = Math.floor(num / 10);
    const onesVal = num % 10;
    
    const tensNames = ['', '', 'ሃያ', 'ሰላሳ', 'አርባ', 'ሃምሳ', 'ስድሳ', 'ሰባ'];
    const onesNames = ['', 'አንድ', 'ሁለት', 'ሶስት', 'አራት', 'አምስት', 'ስድስት', 'ሰባት', 'ስምንት', 'ዘጠኝ'];
    
    const prefix = tensNames[tensVal] || '';
    const suffix = onesNames[onesVal] || '';
    
    return prefix + (suffix ? ' ' + suffix : '');
  }

  public speakAmharic(text: string): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      // Cancel any ongoing speech to avoid overlay or pileup
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'am-ET';
      utterance.rate = 0.85; // Slightly slower for natural call pacing
      utterance.volume = 1.0;

      // Try to find a voice that supports Amharic
      const voices = window.speechSynthesis.getVoices();
      const amVoice = voices.find(v => v.lang.startsWith('am') || v.lang.startsWith('am-ET'));
      if (amVoice) {
        utterance.voice = amVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error('Speech synthesis error', e);
    }
  }

  // Triumphant multi-note ascending major fanfare on Bingo Win!
  public playWin(): void {
    if (!this.sfxEnabled) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const notes = [
        { f: 261.63, t: 0.0 }, // C4
        { f: 329.63, t: 0.1 }, // E4
        { f: 392.00, t: 0.2 }, // G4
        { f: 523.25, t: 0.3 }, // C5
        { f: 659.25, t: 0.4 }, // E5
        { f: 783.99, t: 0.5 }, // G5
        { f: 1046.50, t: 0.6 } // C6
      ];

      notes.forEach((note) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(note.f, now + note.t);
        
        gain.gain.setValueAtTime(0, now);
        gain.gain.setValueAtTime(0, now + note.t);
        gain.gain.linearRampToValueAtTime(0.04, now + note.t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + note.t + 0.4);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + note.t);
        osc.stop(now + note.t + 0.4);
      });
    } catch (e) {}
  }

  // Melancholic sliding minor chord downward on Defeat/Loss
  public playLoss(): void {
    if (!this.sfxEnabled) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      // Low melancholic drone slide down
      const freqs = [196.00, 233.08, 293.66]; // G3, Bb3, D4 (G minor chord)

      freqs.forEach((freq) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        osc.frequency.linearRampToValueAtTime(freq * 0.75, now + 0.6); // sliding flat!

        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        osc.stop(now + 0.7);
      });
    } catch (e) {}
  }

  // Buzz sound for errors or penalties
  public playPenalty(): void {
    if (!this.sfxEnabled) return;
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.linearRampToValueAtTime(80, now + 0.25);

      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(now + 0.3);
    } catch (e) {}
  }
}

export const soundManager = new SoundManager();
